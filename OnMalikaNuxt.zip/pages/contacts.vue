<template>
    <div class="container">
        <h1>Contacts</h1>
       
    </div>
</template>


<script setup>

</script>