<template>
    <div>
        <h1>About</h1>
    </div>
</template>

<script setup>
const route = useRoute()
console.log(route)
</script>