<template>
    <MainLayoutHeader />
    <main class="site-main">
        <NuxtPage />
    </main>
    <MainLayoutFooter />
</template>