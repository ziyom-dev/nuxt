import{u as o,c as t,o as s,a}from"./entry.416876c5.js";const c=a("h1",null,"About",-1),n=[c],p={__name:"about",setup(u){const e=o();return(_,r)=>(s(),t("div",null,n))}};export{p as default};
