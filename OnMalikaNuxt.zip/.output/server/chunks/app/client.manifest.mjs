const client_manifest = {
  "_Card.68f91266.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Card.68f91266.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_CategoryCard.dae46d85.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CategoryCard.dae46d85.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_DashboardList.d4c3d137.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DashboardList.d4c3d137.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.bc111b12.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.bc111b12.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.555501d8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "middleware/auth.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth.998b4904.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/auth.ts"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [
      "middleware/auth.ts",
      "layouts/default.vue"
    ],
    "file": "entry.416876c5.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "pages/about.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "about.5163e9d1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/about.vue"
  },
  "pages/brands/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.9ed9a0d2.js",
    "imports": [
      "_Card.68f91266.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.bc111b12.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/brands/[slug].vue"
  },
  "pages/cart.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "cart.70d5c1d8.css",
    "src": "pages/cart.css"
  },
  "pages/cart.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "cart.e42952f3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.bc111b12.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/cart.vue"
  },
  "cart.70d5c1d8.css": {
    "file": "cart.70d5c1d8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/checkout.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkout.9ba0a181.css",
    "src": "pages/checkout.css"
  },
  "pages/checkout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "checkout.4b302acd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/checkout.vue"
  },
  "checkout.9ba0a181.css": {
    "file": "checkout.9ba0a181.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/contacts.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contacts.784672c1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/contacts.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.20b0b54d.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.3b2f51b7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Card.68f91266.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.20b0b54d.css": {
    "file": "index.20b0b54d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/news/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.6d6f08c3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/news/[id].vue"
  },
  "pages/news/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.f546bc3d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/news/index.vue"
  },
  "pages/search.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "search.772e798f.js",
    "imports": [
      "_Card.68f91266.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/search.vue"
  },
  "pages/shop/[category]/[subCategory]/[id].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_id_.e69c3ec1.css",
    "src": "pages/shop/[category]/[subCategory]/[id].css"
  },
  "pages/shop/[category]/[subCategory]/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_id_.d7e0a719.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.bc111b12.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/shop/[category]/[subCategory]/[id].vue"
  },
  "_id_.e69c3ec1.css": {
    "file": "_id_.e69c3ec1.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/shop/[category]/[subCategory]/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.bbe680be.css",
    "src": "pages/shop/[category]/[subCategory]/index.css"
  },
  "pages/shop/[category]/[subCategory]/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.06c24933.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Card.68f91266.js",
      "_index.bc111b12.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/shop/[category]/[subCategory]/index.vue"
  },
  "index.bbe680be.css": {
    "file": "index.bbe680be.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/shop/[category]/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.090d4087.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_CategoryCard.dae46d85.js",
      "_index.bc111b12.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/shop/[category]/index.vue"
  },
  "pages/shop/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.6e40dd17.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_CategoryCard.dae46d85.js",
      "_index.bc111b12.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/shop/index.vue"
  },
  "pages/success.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "success.6edb3287.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/success.vue"
  },
  "pages/user/favorite.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "favorite.e1f32ac1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_DashboardList.d4c3d137.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/favorite.vue"
  },
  "pages/user/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.5a2b5e92.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_DashboardList.d4c3d137.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/index.vue"
  },
  "pages/user/login.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "login.086a8631.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.bc111b12.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/login.vue"
  },
  "pages/user/orders/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.cfdc1047.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/orders/[id].vue"
  },
  "pages/user/orders/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.7308e693.css",
    "src": "pages/user/orders/index.css"
  },
  "pages/user/orders/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.42cc4494.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_DashboardList.d4c3d137.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/orders/index.vue"
  },
  "index.7308e693.css": {
    "file": "index.7308e693.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/settings.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "settings.98fbfeb2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_DashboardList.d4c3d137.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/settings.vue"
  },
  "public/img/choosen.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "choosen.76f749f6.svg",
    "src": "public/img/choosen.svg"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
