const index_vue_vue_type_style_index_0_lang = ".page-enter-active,.page-leave-active{transition:all .3s}.page-enter-from,.page-leave-to{filter:blur(1rem);opacity:0}";

const indexStyles_2d8bff20 = [index_vue_vue_type_style_index_0_lang, index_vue_vue_type_style_index_0_lang];

export { indexStyles_2d8bff20 as default };
//# sourceMappingURL=index-styles.2d8bff20.mjs.map
