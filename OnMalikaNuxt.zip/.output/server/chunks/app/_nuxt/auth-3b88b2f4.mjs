import { j as defineNuxtRouteMiddleware, e as useAuthStore, h as useCookie, n as navigateTo, k as executeAsync, a as useJsonPlaceholderData } from '../server.mjs';
import 'vue';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'vue-router';
import 'vue/server-renderer';
import 'lodash';

const auth = /* @__PURE__ */ defineNuxtRouteMiddleware(async (to, from) => {
  let __temp, __restore;
  const authStore = useAuthStore();
  const token_access = useCookie("token_access");
  const token_refresh = useCookie("token_refresh");
  function parseJwt(token2) {
    const base64Url = token2.split(".")[1];
    const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
    const jsonPayload = decodeURIComponent(atob(base64).split("").map(function(c) {
      return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(""));
    return JSON.parse(jsonPayload);
  }
  token_access.value;
  function isTokenExpired(token2) {
    if (!token2)
      return true;
    const decoded = parseJwt(token2);
    const currentTime = Date.now().valueOf() / 1e3;
    return decoded.exp <= currentTime;
  }
  function isValidToken(token2) {
    if (!token2)
      return false;
    const decoded = parseJwt(token2);
    const currentTime = Date.now().valueOf() / 1e3;
    return decoded.exp > currentTime;
  }
  async function refreshToken() {
    if (isTokenExpired(token_refresh.value)) {
      return false;
    }
    try {
      const response = await useJsonPlaceholderData("/token/refresh/", {
        method: "POST",
        body: {
          refresh: token_refresh.value
        }
      });
      if (response.data && response.data.value && response.data.value.access) {
        token_access.value = response.data.value.access;
        return true;
      } else {
        return false;
      }
    } catch (error) {
      return false;
    }
  }
  async function verifyToken(token2) {
    try {
      const response = await useJsonPlaceholderData("/token/verify/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ token: token2 })
      });
      if (response.data.value === null) {
        return false;
      }
      return true;
    } catch (error) {
      return false;
    }
  }
  if (to.path === "/user/login") {
    if (authStore.isAuthenticated || token_access.value && isValidToken(token_access.value)) {
      return navigateTo("/user");
    }
    return;
  }
  if (!authStore.isAuthenticated) {
    const tokenIsValid = ([__temp, __restore] = executeAsync(() => verifyToken(token_access.value)), __temp = await __temp, __restore(), __temp);
    if (!tokenIsValid) {
      const isRefreshed = ([__temp, __restore] = executeAsync(() => refreshToken()), __temp = await __temp, __restore(), __temp);
      if (!isRefreshed) {
        try {
          ;
          [__temp, __restore] = executeAsync(() => $fetch("/api/logout")), await __temp, __restore();
          ;
        } catch (error) {
        }
        authStore.logout();
        return navigateTo("/user/login");
      }
    }
  }
});

export { auth as default };
//# sourceMappingURL=auth-3b88b2f4.mjs.map
