import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { b as useRouter, u as useRoute, e as useAuthStore, g as __nuxt_component_0$4 } from '../server.mjs';
import * as vue$1 from 'vue';
import { ref, withCtx, createTextVNode, unref, isRef, useSSRContext } from 'vue';
import { u as useSeoMeta } from './index-6fec30d9.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderClass, ssrRenderStyle } from 'vue/server-renderer';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'lodash';

function getDefaultExportFromCjs (x) {
	return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
}

function getDefaultExportFromNamespaceIfNotNamed (n) {
	return n && Object.prototype.hasOwnProperty.call(n, 'default') && Object.keys(n).length === 1 ? n['default'] : n;
}

const require$$0 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(vue$1);

var vue=require$$0;function _iterableToArrayLimit(arr, i) {
  var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
  if (null != _i) {
    var _s,
      _e,
      _x,
      _r,
      _arr = [],
      _n = !0,
      _d = !1;
    try {
      if (_x = (_i = _i.call(arr)).next, 0 === i) {
        if (Object(_i) !== _i) return;
        _n = !1;
      } else for (; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
    } catch (err) {
      _d = !0, _e = err;
    } finally {
      try {
        if (!_n && null != _i.return && (_r = _i.return(), Object(_r) !== _r)) return;
      } finally {
        if (_d) throw _e;
      }
    }
    return _arr;
  }
}
function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}
function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;
  for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
  return arr2;
}
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}var script$1 = vue.defineComponent({
  name: "SingleOtpInput",
  props: {
    inputType: {
      type: String,
      validator: function validator(value) {
        return ["number", "tel", "letter-numeric", "password"].includes(value);
      },
      default: "tel"
    },
    inputmode: {
      type: String,
      default: "numeric"
    },
    value: {
      type: [String, Number]
    },
    separator: {
      type: String
    },
    focus: {
      type: Boolean
    },
    inputClasses: {
      type: [String, Array]
    },
    conditionalClass: {
      type: String
    },
    shouldAutoFocus: {
      type: Boolean
    },
    isLastChild: {
      type: Boolean
    },
    placeholder: {
      type: String
    },
    isDisabled: {
      type: Boolean
    }
  },
  emits: ["on-change", "on-keydown", "on-paste", "on-focus", "on-blur"],
  setup: function setup(props, _ref) {
    var emit = _ref.emit;
    var model = vue.ref(props.value || "");
    var input = vue.ref(null);
    var handleOnChange = function handleOnChange() {
      model.value = model.value.toString();
      if (model.value.length > 1) {
        model.value = model.value.slice(0, 1);
      }
      return emit("on-change", model.value);
    };
    var isCodeLetter = function isCodeLetter(charCode) {
      return charCode >= 65 && charCode <= 90;
    };
    var isCodeNumeric = function isCodeNumeric(charCode) {
      return charCode >= 48 && charCode <= 57 || charCode >= 96 && charCode <= 105;
    };
    // numeric keys and numpad keys

    var handleOnKeyDown = function handleOnKeyDown(event) {
      if (props.isDisabled) {
        event.preventDefault();
      }
      // Only allow characters 0-9, DEL, Backspace, Enter, Right and Left Arrows, and Pasting
      var keyEvent = event || window.event;
      var charCode = keyEvent.which ? keyEvent.which : keyEvent.keyCode;
      if (isCodeNumeric(charCode) || props.inputType === "letter-numeric" && isCodeLetter(charCode) || [8, 9, 13, 37, 39, 46, 86].includes(charCode)) {
        emit("on-keydown", event);
      } else {
        keyEvent.preventDefault();
      }
    };
    var handleOnPaste = function handleOnPaste(event) {
      return emit("on-paste", event);
    };
    var handleOnFocus = function handleOnFocus() {
      input.value.select();
      return emit("on-focus");
    };
    var handleOnBlur = function handleOnBlur() {
      return emit("on-blur");
    };
    vue.watch(function () {
      return props.value;
    }, function (newValue, oldValue) {
      if (newValue !== oldValue) {
        model.value = newValue;
      }
    });
    vue.watch(function () {
      return props.focus;
    }, function (newFocusValue, oldFocusValue) {
      // Check if focusedInput changed
      // Prevent calling function if input already in focus
      if (oldFocusValue !== newFocusValue && input.value && props.focus) {
        input.value.focus();
        input.value.select();
      }
    });
    vue.onMounted(function () {
      if (input.value && props.focus && props.shouldAutoFocus) {
        input.value.focus();
        input.value.select();
      }
    });
    return {
      handleOnChange: handleOnChange,
      handleOnKeyDown: handleOnKeyDown,
      handleOnPaste: handleOnPaste,
      handleOnFocus: handleOnFocus,
      handleOnBlur: handleOnBlur,
      input: input,
      model: model,
      inputTypeValue: props.inputType === "letter-numeric" ? "text" : props.inputType
    };
  }
});var _hoisted_1$1 = {
  style: {
    "display": "flex",
    "align-items": "center"
  }
};
var _hoisted_2$1 = ["type", "inputmode", "placeholder", "disabled"];
var _hoisted_3 = {
  key: 0
};
var _hoisted_4 = ["innerHTML"];
function render$1(_ctx, _cache, $props, $setup, $data, $options) {
  return vue.openBlock(), vue.createElementBlock("div", _hoisted_1$1, [vue.withDirectives(vue.createElementVNode("input", {
    "data-test": "single-input",
    type: _ctx.inputTypeValue,
    inputmode: _ctx.inputmode,
    placeholder: _ctx.placeholder,
    disabled: _ctx.isDisabled,
    ref: "input",
    min: "0",
    max: "9",
    maxlength: "1",
    pattern: "[0-9]",
    "onUpdate:modelValue": _cache[0] || (_cache[0] = function ($event) {
      return _ctx.model = $event;
    }),
    class: vue.normalizeClass([_ctx.inputClasses, _ctx.conditionalClass, {
      'is-complete': _ctx.model
    }]),
    onInput: _cache[1] || (_cache[1] = function () {
      return _ctx.handleOnChange && _ctx.handleOnChange.apply(_ctx, arguments);
    }),
    onKeydown: _cache[2] || (_cache[2] = function () {
      return _ctx.handleOnKeyDown && _ctx.handleOnKeyDown.apply(_ctx, arguments);
    }),
    onPaste: _cache[3] || (_cache[3] = function () {
      return _ctx.handleOnPaste && _ctx.handleOnPaste.apply(_ctx, arguments);
    }),
    onFocus: _cache[4] || (_cache[4] = function () {
      return _ctx.handleOnFocus && _ctx.handleOnFocus.apply(_ctx, arguments);
    }),
    onBlur: _cache[5] || (_cache[5] = function () {
      return _ctx.handleOnBlur && _ctx.handleOnBlur.apply(_ctx, arguments);
    })
  }, null, 42, _hoisted_2$1), [[vue.vModelDynamic, _ctx.model]]), !_ctx.isLastChild && _ctx.separator ? (vue.openBlock(), vue.createElementBlock("span", _hoisted_3, [vue.createElementVNode("span", {
    innerHTML: _ctx.separator
  }, null, 8, _hoisted_4)])) : vue.createCommentVNode("", true)]);
}script$1.render = render$1;// keyCode constants
var BACKSPACE = 8;
var LEFT_ARROW = 37;
var RIGHT_ARROW = 39;
var DELETE = 46;
var script = /* #__PURE__ */vue.defineComponent({
  name: "Vue3OtpInput",
  // vue component name
  components: {
    SingleOtpInput: script$1
  },
  props: {
    value: {
      type: String,
      default: "",
      required: true
    },
    numInputs: {
      default: 4
    },
    separator: {
      type: String,
      default: "**"
    },
    inputClasses: {
      type: [String, Array]
    },
    conditionalClass: {
      type: Array,
      default: []
    },
    inputType: {
      type: String,
      validator: function validator(value) {
        return ["number", "tel", "letter-numeric", "password"].includes(value);
      }
    },
    inputmode: {
      type: String,
      validator: function validator(value) {
        return ["numeric", "text", "tel", "none"].includes(value);
      },
      default: "numeric"
    },
    shouldAutoFocus: {
      type: Boolean,
      default: false
    },
    placeholder: {
      type: Array,
      default: []
    },
    isDisabled: {
      type: Boolean,
      default: false
    }
  },
  setup: function setup(props, _ref) {
    var emit = _ref.emit;
    var activeInput = vue.ref(0);
    var otp = vue.ref([]);
    var oldOtp = vue.ref([]);
    vue.watch(function () {
      return props.value;
    }, function (val) {
      var fill = vue.unref(val).split("");
      otp.value = fill;
    }, {
      immediate: true
    });
    var handleOnFocus = function handleOnFocus(index) {
      activeInput.value = index;
    };
    var handleOnBlur = function handleOnBlur() {
      activeInput.value = -1;
    };

    // Helper to return OTP from input
    var checkFilledAllInputs = function checkFilledAllInputs() {
      if (otp.value.join("").length === props.numInputs) {
        emit("update:value", otp.value.join(""));
        return emit("on-complete", otp.value.join(""));
      }
      return "Wait until the user enters the required number of characters";
    };

    // Focus on input by index
    var focusInput = function focusInput(input) {
      activeInput.value = Math.max(Math.min(props.numInputs - 1, input), 0);
    };
    // Focus on next input
    var focusNextInput = function focusNextInput() {
      focusInput(activeInput.value + 1);
    };
    // Focus on previous input
    var focusPrevInput = function focusPrevInput() {
      focusInput(activeInput.value - 1);
    };

    // Change OTP value at focused input
    var changeCodeAtFocus = function changeCodeAtFocus(value) {
      oldOtp.value = Object.assign([], otp.value);

      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      otp.value[activeInput.value] = value;
      if (oldOtp.value.join("") !== otp.value.join("")) {
        emit("update:value", otp.value.join(""));
        emit("on-change", otp.value.join(""));
        checkFilledAllInputs();
      }
    };

    // Handle pasted OTP
    var handleOnPaste = function handleOnPaste(event) {
      event.preventDefault();
      var pastedData = event.clipboardData.getData("text/plain").slice(0, props.numInputs - activeInput.value).split("");
      if (props.inputType === "number" && !pastedData.join("").match(/^\d+$/)) {
        return "Invalid pasted data";
      }
      if (props.inputType === "letter-numeric" && !pastedData.join("").match(/^\w+$/)) {
        return "Invalid pasted data";
      }
      // Paste data from focused input onwards
      var currentCharsInOtp = otp.value.slice(0, activeInput.value);
      var combinedWithPastedData = currentCharsInOtp.concat(pastedData);
      combinedWithPastedData.slice(0, props.numInputs).forEach(function (value, i) {
        otp.value[i] = value;
      });
      focusInput(combinedWithPastedData.slice(0, props.numInputs).length);
      return checkFilledAllInputs();
    };
    var handleOnChange = function handleOnChange(value) {
      changeCodeAtFocus(value);
      focusNextInput();
    };
    var clearInput = function clearInput() {
      if (otp.value.length > 0) {
        emit("update:value", "");
        emit("on-change", "");
      }
      otp.value = [];
      activeInput.value = 0;
    };
    var fillInput = function fillInput(value) {
      var fill = value.split("");
      if (fill.length === props.numInputs) {
        otp.value = fill;
        emit("update:value", otp.value.join(""));
        emit("on-complete", otp.value.join(""));
      }
    };

    // Handle cases of backspace, delete, left arrow, right arrow
    var handleOnKeyDown = function handleOnKeyDown(event) {
      switch (event.keyCode) {
        case BACKSPACE:
          event.preventDefault();
          changeCodeAtFocus("");
          focusPrevInput();
          break;
        case DELETE:
          event.preventDefault();
          changeCodeAtFocus("");
          break;
        case LEFT_ARROW:
          event.preventDefault();
          focusPrevInput();
          break;
        case RIGHT_ARROW:
          event.preventDefault();
          focusNextInput();
          break;
      }
    };
    return {
      activeInput: activeInput,
      otp: otp,
      oldOtp: oldOtp,
      clearInput: clearInput,
      handleOnPaste: handleOnPaste,
      handleOnKeyDown: handleOnKeyDown,
      handleOnBlur: handleOnBlur,
      changeCodeAtFocus: changeCodeAtFocus,
      focusInput: focusInput,
      focusNextInput: focusNextInput,
      focusPrevInput: focusPrevInput,
      handleOnFocus: handleOnFocus,
      checkFilledAllInputs: checkFilledAllInputs,
      handleOnChange: handleOnChange,
      fillInput: fillInput
    };
  }
});var _hoisted_1 = {
  style: {
    "display": "flex"
  }
};
var _hoisted_2 = {
  key: 0,
  autocomplete: "off",
  name: "hidden",
  type: "text",
  style: {
    "display": "none"
  }
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_SingleOtpInput = vue.resolveComponent("SingleOtpInput");
  return vue.openBlock(), vue.createElementBlock("div", _hoisted_1, [_ctx.inputType === 'password' ? (vue.openBlock(), vue.createElementBlock("input", _hoisted_2)) : vue.createCommentVNode("", true), (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(_ctx.numInputs, function (_, i) {
    return vue.openBlock(), vue.createBlock(_component_SingleOtpInput, {
      key: i,
      focus: _ctx.activeInput === i,
      value: _ctx.otp[i],
      separator: _ctx.separator,
      "input-type": _ctx.inputType,
      inputmode: _ctx.inputmode,
      "input-classes": _ctx.inputClasses,
      conditionalClass: _ctx.conditionalClass[i],
      "is-last-child": i === _ctx.numInputs - 1,
      "should-auto-focus": _ctx.shouldAutoFocus,
      placeholder: _ctx.placeholder[i],
      "is-disabled": _ctx.isDisabled,
      onOnChange: _ctx.handleOnChange,
      onOnKeydown: _ctx.handleOnKeyDown,
      onOnPaste: _ctx.handleOnPaste,
      onOnFocus: function onOnFocus($event) {
        return _ctx.handleOnFocus(i);
      },
      onOnBlur: _ctx.handleOnBlur
    }, null, 8, ["focus", "value", "separator", "input-type", "inputmode", "input-classes", "conditionalClass", "is-last-child", "should-auto-focus", "placeholder", "is-disabled", "onOnChange", "onOnKeydown", "onOnPaste", "onOnFocus", "onOnBlur"]);
  }), 128))]);
}script.render = render;// Import vue component

// Define typescript interfaces for installable component

// Default export is installable instance of component.
// IIFE injects install function into component, allowing component
// to be registered via Vue.use() as well as Vue.component(),
var component = /*#__PURE__*/(function () {
  // Assign InstallableComponent type
  var installable = script;

  // Attach install function executed by Vue.use()
  installable.install = function (app) {
    app.component("Vue3OtpInput", installable);
  };
  return installable;
})();

// It's possible to expose named exports when writing components that can
// also be used as directives, etc. - eg. import { RollupDemoDirective } from 'rollup-demo';
// export const RollupDemoDirective = directive;
var namedExports=/*#__PURE__*/Object.freeze({__proto__:null,'default':component});// Attach named exports directly to component. IIFE/CJS will
// only expose one global var, with named exports exposed as properties of
// that global var (eg. plugin.namedExport)
Object.entries(namedExports).forEach(function (_ref) {
  var _ref2 = _slicedToArray(_ref, 2),
    exportName = _ref2[0],
    exported = _ref2[1];
  if (exportName !== 'default') component[exportName] = exported;
});var vue3OtpInput_ssr=component;

const VOtpInput = /*@__PURE__*/getDefaultExportFromCjs(vue3OtpInput_ssr);

const _imports_0 = "" + publicAssetsURL("img/mini-logo.svg");
const _sfc_main = {
  __name: "login",
  __ssrInlineRender: true,
  setup(__props) {
    useRouter();
    useRoute();
    const errorMessage = ref("");
    useAuthStore();
    const number = ref("");
    const timer = ref(60);
    const canResend = ref(false);
    ref();
    const isSend = ref(false);
    const otpInput = ref(null);
    const bindModal = ref("");
    const otpValue = ref("");
    ref();
    const handleOnComplete = (value) => {
      otpValue.value = value;
    };
    useSeoMeta({
      title: "\u0410\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u044F"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$4;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="container"><nav aria-label="breadcrumb"><ol class="breadcrumb onmalika-breadcrumb"><li class="breadcrumb-item">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0413\u043B\u0430\u0432\u043D\u0430\u044F`);
          } else {
            return [
              createTextVNode("\u0413\u043B\u0430\u0432\u043D\u0430\u044F")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item active" aria-current="page">\u0410\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u044F</li></ol></nav></div><section><div class="container"><div class="onmalika-auth">`);
      if (unref(errorMessage)) {
        _push(`<div class="alert text-center alert-danger">${ssrInterpolate(unref(errorMessage))}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="user-form"><div class="text-center mb-5"><img${ssrRenderAttr("src", _imports_0)} alt=""></div><form class="${ssrRenderClass({ "d-none": unref(isSend) })}"><div class="mb-3"><input autocomplete="username" placeholder="\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0432\u0430\u0448 \u043D\u043E\u043C\u0435\u0440" type="tel" class="form-control"${ssrRenderAttr("value", unref(number))} id="userLogin" aria-describedby="userHelp" required></div><button type="submit" class="btn dark-cover justify-content-center w-100">\u041F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043A\u043E\u0434</button></form><div class="${ssrRenderClass({ "d-none": !unref(isSend) })}"><form><div class="mb-4" style="${ssrRenderStyle({ "display": "flex", "flex-direction": "row", "justify-content": "center" })}">`);
      _push(ssrRenderComponent(unref(VOtpInput), {
        ref_key: "otpInput",
        ref: otpInput,
        modelValue: unref(bindModal),
        "onUpdate:modelValue": ($event) => isRef(bindModal) ? bindModal.value = $event : null,
        "input-classes": "otp-input",
        separator: "",
        "num-inputs": 6,
        value: "",
        "should-auto-focus": true,
        "input-type": "letter-numeric",
        conditionalClass: ["one", "two", "three", "four"],
        placeholder: ["*", "*", "*", "*", "*", "*"],
        onOnComplete: handleOnComplete
      }, null, _parent));
      _push(`</div><button type="submit" class="btn dark-cover justify-content-center mb-3 w-100">\u0412\u043E\u0439\u0442\u0438</button>`);
      if (!unref(canResend)) {
        _push(`<div class="text-center">\u041F\u043E\u0432\u0442\u043E\u0440\u043D\u0430\u044F \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u043A\u043E\u0434\u0430 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u0430 \u0447\u0435\u0440\u0435\u0437: ${ssrInterpolate(unref(timer))} \u0441\u0435\u043A\u0443\u043D\u0434</div>`);
      } else {
        _push(`<button class="btn dark-cover justify-content-center w-100">\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u043A\u043E\u0434 \u0435\u0449\u0435 \u0440\u0430\u0437</button>`);
      }
      _push(`</form></div></div></div></div></section></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=login-44b2b26f.mjs.map
