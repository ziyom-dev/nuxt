import { u as useRoute, b as useRouter, a as useJsonPlaceholderData, c as createError, g as __nuxt_component_0$4 } from '../server.mjs';
import { _ as __nuxt_component_1 } from './CategoryCard-c8c7b157.mjs';
import { withAsyncContext, computed, withCtx, createTextVNode, unref, useSSRContext } from 'vue';
import { u as useSeoMeta } from './index-6fec30d9.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'vue-router';
import 'lodash';
import 'unhead';
import '@unhead/shared';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const route = useRoute();
    const page_slug = route.params.category;
    useRouter().options.history.state.back;
    const { data: category } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/categories/?parent_slug=" + page_slug)), __temp = await __temp, __restore(), __temp);
    if (!category.value || !category.value) {
      throw createError({ statusCode: 404, message: "\u0422\u0430\u043A\u043E\u0439 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438 \u043D\u0435\u0442\u0443" });
    }
    const { data: solo_category } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/categories/" + page_slug)), __temp = await __temp, __restore(), __temp);
    computed(() => category.value);
    computed(() => solo_category.value);
    useSeoMeta({
      title: solo_category.value.name,
      ogTitle: solo_category.value.name
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$4;
      const _component_CategoryCard = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="container"><nav aria-label="breadcrumb"><ol class="breadcrumb onmalika-breadcrumb"><li class="breadcrumb-item">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0413\u043B\u0430\u0432\u043D\u0430\u044F`);
          } else {
            return [
              createTextVNode("\u0413\u043B\u0430\u0432\u043D\u0430\u044F")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/shop" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u041C\u0430\u0433\u0430\u0437\u0438\u043D\u0447\u0438\u043A`);
          } else {
            return [
              createTextVNode("\u041C\u0430\u0433\u0430\u0437\u0438\u043D\u0447\u0438\u043A")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item active" aria-current="page">${ssrInterpolate(unref(solo_category).name)}</li></ol></nav></div><section class="padding-y"><div class="container"><div class="row row-cols-5"><!--[-->`);
      ssrRenderList(unref(category).results, (cat) => {
        _push(`<div class="col">`);
        _push(ssrRenderComponent(_component_CategoryCard, { category_info: cat }, null, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div></div></section></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/shop/[category]/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-7c0154fd.mjs.map
