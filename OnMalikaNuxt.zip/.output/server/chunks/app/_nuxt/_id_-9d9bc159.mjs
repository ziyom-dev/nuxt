import { _ as _export_sfc, e as useAuthStore, d as useCartStore, u as useRoute, b as useRouter, a as useJsonPlaceholderData, c as createError, f as useCurrencyStore, g as __nuxt_component_0$4 } from '../server.mjs';
import { withAsyncContext, ref, withCtx, createTextVNode, unref, toDisplayString, useSSRContext } from 'vue';
import { u as useSeoMeta } from './index-6fec30d9.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'vue-router';
import 'lodash';
import 'unhead';
import '@unhead/shared';

const urlOfMedia = "http://64.23.130.79:8000";
const _sfc_main = {
  __name: "[id]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useAuthStore();
    useCartStore();
    const route = useRoute();
    const router = useRouter();
    const { data: product } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/products/" + route.params.id)), __temp = await __temp, __restore(), __temp);
    if (!product.value || !product.value.category) {
      throw createError({ statusCode: 404, message: "\u0422\u0430\u043A\u043E\u0433\u043E \u0442\u043E\u0432\u0430\u0440\u0430 \u043D\u0435\u0442\u0443" });
    }
    ref(5);
    ref(null);
    const quantity = ref(1);
    const goToBrand = async (slug) => {
      await router.push("/brands/" + slug);
    };
    const currencyStore = useCurrencyStore();
    const getPriceText = () => {
      const currency = currencyStore.selectedCurrency;
      const priceInfo = product.value.prices_in_currencies[currency];
      if (!priceInfo) {
        return "\u0426\u0435\u043D\u0430 \u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u0430";
      }
      return `${priceInfo.price} ${priceInfo.symbol}`;
    };
    useSeoMeta({
      title: product.value.name,
      ogTitle: product.value.name
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$4;
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-279feee3><div class="container" data-v-279feee3><nav aria-label="breadcrumb" data-v-279feee3><ol class="breadcrumb onmalika-breadcrumb" data-v-279feee3><li class="breadcrumb-item" data-v-279feee3>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0413\u043B\u0430\u0432\u043D\u0430\u044F`);
          } else {
            return [
              createTextVNode("\u0413\u043B\u0430\u0432\u043D\u0430\u044F")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item" data-v-279feee3>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/shop" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u041C\u0430\u0433\u0430\u0437\u0438\u043D\u0447\u0438\u043A`);
          } else {
            return [
              createTextVNode("\u041C\u0430\u0433\u0430\u0437\u0438\u043D\u0447\u0438\u043A")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item" data-v-279feee3>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/shop/" + unref(product).category.parent.slug
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(unref(product).category.parent.name)}`);
          } else {
            return [
              createTextVNode(toDisplayString(unref(product).category.parent.name), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item" data-v-279feee3>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/shop/" + unref(product).category.slug + "/" + unref(product).category.slug
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(unref(product).category.name)}`);
          } else {
            return [
              createTextVNode(toDisplayString(unref(product).category.name), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item active" aria-current="page" data-v-279feee3>${ssrInterpolate(unref(product).name)}</li></ol></nav></div><section data-v-279feee3><div class="container" data-v-279feee3><div class="row justify-content-between onmalika-product" data-v-279feee3><div class="col-6" data-v-279feee3><div class="row" data-v-279feee3><div class="col-2" data-v-279feee3><div class="onmalika-product-gallery" data-v-279feee3>`);
      if (unref(product).images && unref(product).images.length > 1) {
        _push(`<div class="onmalika-product-gallery-item active" data-v-279feee3><!--[-->`);
        ssrRenderList(unref(product).images, (progall, index) => {
          _push(`<div data-v-279feee3><img${ssrRenderAttr("src", urlOfMedia + progall.url)} class="w-100" alt="" data-v-279feee3></div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="col-10" data-v-279feee3><!--[-->`);
      ssrRenderList(unref(product).images, (progall) => {
        _push(`<div class="onmalika-product-main-img" data-v-279feee3><img${ssrRenderAttr("src", urlOfMedia + progall.url)} class="w-100" alt="" data-v-279feee3><div class="onmalika-product-rating" data-v-279feee3><button type="button" class="onmalika-product-favorite" data-v-279feee3><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-279feee3><path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-279feee3></path></svg></button><p data-v-279feee3><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-279feee3><path d="M13.5639 4.3011L15.1502 7.49508C15.364 7.93681 15.9378 8.35588 16.4216 8.44649L19.2905 8.92219C21.1244 9.22799 21.5519 10.5645 20.2356 11.901L17.9967 14.1549C17.6254 14.5286 17.4116 15.2649 17.5354 15.7972L18.1767 18.5834C18.683 20.7807 17.5129 21.6415 15.589 20.4862L12.9001 18.8779C12.4163 18.5834 11.6062 18.5834 11.1224 18.8779L8.43351 20.4862C6.50963 21.6302 5.33955 20.7807 5.84583 18.5834L6.48712 15.7972C6.58838 15.2535 6.37462 14.5173 6.00334 14.1436L3.76444 11.8896C2.4481 10.5645 2.87563 9.22799 4.7095 8.91086L7.57845 8.43516C8.06223 8.35588 8.63602 7.92548 8.84979 7.48376L10.4361 4.28977C11.3025 2.56819 12.6975 2.56819 13.5639 4.3011Z" fill="#FFB800" data-v-279feee3></path></svg> 5.0 </p></div></div>`);
      });
      _push(`<!--]--></div></div><div data-v-279feee3></div></div><div class="col-6" data-v-279feee3><h1 class="onmalika-product-title" data-v-279feee3>${ssrInterpolate(unref(product).name)}</h1><h4 class="onmalika-product-short-title" data-v-279feee3> \u041A\u0440\u0430\u0442\u043A\u043E\u0435 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435: </h4><p class="onmalika-product-short" data-v-279feee3>${ssrInterpolate(unref(product).short_description)}</p><p class="onmalika-product-short" data-v-279feee3>${ssrInterpolate(unref(product).sku)}</p><div class="onmalika-product-reviews-stock" data-v-279feee3><p data-v-279feee3><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-279feee3><path d="M12 22C17.5 22 22 17.5 22 12C22 6.5 17.5 2 12 2C6.5 2 2 6.5 2 12C2 17.5 6.5 22 12 22Z" stroke="#46AC36" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-279feee3></path><path d="M7.75 11.9999L10.58 14.8299L16.25 9.16992" stroke="#46AC36" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-279feee3></path></svg> \u0415\u0441\u0442\u044C \u0432 \u043D\u0430\u043B\u0438\u0447\u0438\u0438 </p><button type="button" class="onmalika-product-reviews" data-bs-toggle="modal" data-bs-target="#reviewsModal" data-v-279feee3><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-279feee3><path d="M8.5 19H8C4 19 2 18 2 13V8C2 4 4 2 8 2H16C20 2 22 4 22 8V13C22 17 20 19 16 19H15.5C15.19 19 14.89 19.15 14.7 19.4L13.2 21.4C12.54 22.28 11.46 22.28 10.8 21.4L9.3 19.4C9.14 19.18 8.77 19 8.5 19Z" stroke="black" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" data-v-279feee3></path><path d="M15.9965 11H16.0054" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-v-279feee3></path><path d="M11.9945 11H12.0035" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-v-279feee3></path><path d="M7.99451 11H8.00349" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-v-279feee3></path></svg><span data-v-279feee3> \u041E\u0442\u0437\u044B\u0432\u044B </span></button></div><h4 class="onmalika-product-price" data-v-279feee3>${ssrInterpolate(getPriceText())}</h4><p class="mb-3" data-v-279feee3>Brand: `);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/brands/" + unref(product).brand.slug,
        onClick: ($event) => goToBrand(unref(product).brand.slug)
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(unref(product).brand.name)}`);
          } else {
            return [
              createTextVNode(toDisplayString(unref(product).brand.name), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</p><div class="onmalika-product-btns" data-v-279feee3><button class="btn dark-cover" type="button" data-v-279feee3> \u0412 \u043A\u043E\u0440\u0437\u0438\u043D\u0443 </button><div class="product-counter" data-v-279feee3><button type="button" data-v-279feee3><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="#999" viewBox="0 0 24 24" data-v-279feee3><path d="M19 13H5v-2h14v2z" data-v-279feee3></path></svg></button><input class="text-center" type="text"${ssrRenderAttr("value", unref(quantity))} disabled data-v-279feee3><button type="button" data-v-279feee3><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="#999" viewBox="0 0 24 24" data-v-279feee3><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" data-v-279feee3></path></svg></button></div></div></div></div></div></section><section data-v-279feee3><div class="container" data-v-279feee3><div class="row" data-v-279feee3><div class="col-6" data-v-279feee3><div class="accordion onmalika-accardion" id="accordionExample" data-v-279feee3>`);
      if (unref(product).description) {
        _push(`<div class="accordion-item" data-v-279feee3><h2 class="accordion-header" data-v-279feee3><button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne" data-v-279feee3> \u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 </button></h2><div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample" data-v-279feee3><div class="accordion-body" data-v-279feee3>${ssrInterpolate(unref(product).description)}</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="accordion-item" data-v-279feee3><h2 class="accordion-header" data-v-279feee3><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" data-v-279feee3> \u0425\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u0438\u0441\u0442\u0438\u043A\u0438 </button></h2><div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample" data-v-279feee3><div class="accordion-body" data-v-279feee3><!--[-->`);
      ssrRenderList(unref(product).product_attrs, (atrs) => {
        _push(`<ul data-v-279feee3><li data-v-279feee3>${ssrInterpolate(atrs.attribute.name)} <span data-v-279feee3>${ssrInterpolate(atrs.attribute_value.value)}</span></li></ul>`);
      });
      _push(`<!--]--></div></div></div></div></div><div class="col-6" data-v-279feee3><div data-v-279feee3>${unref(product).content}</div></div></div></div></section></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/shop/[category]/[subCategory]/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _id_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-279feee3"]]);

export { _id_ as default };
//# sourceMappingURL=_id_-9d9bc159.mjs.map
