import { _ as __nuxt_component_1 } from './Card-9f638715.mjs';
import { computed, ref, watch, unref, useSSRContext } from 'vue';
import { u as useRoute, b as useRouter, a as useJsonPlaceholderData } from '../server.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderList, ssrRenderComponent, ssrRenderClass, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'vue-router';
import 'lodash';

const pageSize = 3;
const _sfc_main = {
  __name: "search",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    useRouter();
    const query = computed(() => route.query.search);
    const products = ref({ results: [], next: null, previous: null, count: 0 });
    const nextUrl = ref(null);
    const prevUrl = ref(null);
    const currentPage = ref(1);
    const totalCount = ref(0);
    const totalPages = computed(() => Math.ceil(totalCount.value / pageSize));
    const fetchProducts = async (url) => {
      try {
        const res = await useJsonPlaceholderData(url);
        if (res && res.data && res.data.value) {
          const data = res.data.value;
          products.value = data;
          nextUrl.value = data.next;
          prevUrl.value = data.previous;
          totalCount.value = data.count;
        } else {
          /* @__PURE__ */ console.error("\u041E\u0442\u0432\u0435\u0442 \u043E\u0442 \u0441\u0435\u0440\u0432\u0435\u0440\u0430 \u043F\u0443\u0441\u0442\u043E\u0439 \u0438\u043B\u0438 \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u043E\u0436\u0438\u0434\u0430\u0435\u043C\u043E\u043C\u0443 \u0444\u043E\u0440\u043C\u0430\u0442\u0443", res);
        }
      } catch (error) {
      }
    };
    fetchProducts("/products/?search=" + query.value + "&limit=" + pageSize);
    const updateProductsByPage = (page) => {
      const offset = (page - 1) * pageSize;
      fetchProducts(`/products/?search=${query.value}&limit=${pageSize}&offset=${offset}`);
    };
    watch(() => route.query.page, (newPage) => {
      const page = parseInt(newPage, 10) || 1;
      if (page !== currentPage.value) {
        currentPage.value = page;
        updateProductsByPage(page);
      }
    }, { immediate: true });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Card = __nuxt_component_1;
      _push(`<section${ssrRenderAttrs(_attrs)}><div class="container"><h1>\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B \u043F\u043E\u0438\u0441\u043A\u0430 : ${ssrInterpolate(unref(query))}</h1><div class="row row-cols-4"><!--[-->`);
      ssrRenderList(unref(products).results, (product) => {
        _push(`<div class="col mb-4">`);
        _push(ssrRenderComponent(_component_Card, { product_info: product }, null, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div>`);
      if (unref(totalPages) > 1) {
        _push(`<nav aria-label="Page navigation example"><ul class="pagination justify-content-center"><li class="page-item"><button class="${ssrRenderClass([{ "disabled": !unref(prevUrl) }, "page-link"])}"${ssrIncludeBooleanAttr(!unref(prevUrl)) ? " disabled" : ""}>\u041F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0430\u044F \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430</button></li><!--[-->`);
        ssrRenderList(unref(totalPages), (page) => {
          _push(`<li class="page-item"><button class="${ssrRenderClass([{ active: page === unref(currentPage) }, "page-link"])}">${ssrInterpolate(page)}</button></li>`);
        });
        _push(`<!--]--><li class="page-item"><button class="${ssrRenderClass([{ "disabled": !unref(nextUrl) }, "page-link"])}"${ssrIncludeBooleanAttr(!unref(nextUrl)) ? " disabled" : ""}>\u0421\u043B\u0435\u0434\u0443\u044E\u0449\u0430\u044F \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430</button></li></ul></nav>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/search.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=search-3bfa9fe1.mjs.map
