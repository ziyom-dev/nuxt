import { _ as __nuxt_component_1 } from './Card-9f638715.mjs';
import { withAsyncContext, mergeProps, unref, useSSRContext } from 'vue';
import { u as useSeoMeta } from './index-6fec30d9.mjs';
import { u as useRoute, a as useJsonPlaceholderData, c as createError } from '../server.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderList, ssrRenderComponent } from 'vue/server-renderer';
import 'unhead';
import '@unhead/shared';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'vue-router';
import 'lodash';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const route = useRoute();
    const query = route.params.slug;
    const { data: brand } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData(`/brands/${query}`)), __temp = await __temp, __restore(), __temp);
    if (!brand.value) {
      throw createError({ statusCode: 404, message: "\u0422\u0430\u043A\u043E\u0433\u043E \u0431\u0440\u044D\u043D\u0434\u0430 \u0443 \u043D\u0430\u0441 \u043D\u0435\u0442" });
    }
    const { data: prods_search } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData(`/products/?brand_slug=${query}`)), __temp = await __temp, __restore(), __temp);
    useSeoMeta({
      title: brand.value.name,
      ogTitle: brand.value.name
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Card = __nuxt_component_1;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "padding-y" }, _attrs))}><div class="container"><h1>\u041F\u0440\u043E\u0434\u0443\u043A\u0446\u0438\u044F \u0431\u0440\u044D\u043D\u0434\u0430: ${ssrInterpolate(unref(brand).name)}</h1><div class="row row-cols-4"><!--[-->`);
      ssrRenderList(unref(prods_search).results, (product) => {
        _push(`<div class="col mb-4">`);
        _push(ssrRenderComponent(_component_Card, { product_info: product }, null, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div></div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/brands/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-40ebc8d8.mjs.map
