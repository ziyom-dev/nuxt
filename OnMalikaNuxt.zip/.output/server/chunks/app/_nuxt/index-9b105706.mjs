import { e as useAuthStore, h as useCookie, g as __nuxt_component_0$4 } from '../server.mjs';
import { _ as __nuxt_component_1 } from './DashboardList-9ea80a24.mjs';
import { ref, unref, withCtx, createTextVNode, useSSRContext } from 'vue';
import { a as useHead } from './index-6fec30d9.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'vue-router';
import 'lodash';
import 'unhead';
import '@unhead/shared';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const authStore = useAuthStore();
    useCookie("token_access");
    const name = ref(authStore.user.first_name);
    const surname = ref(authStore.user.last_name);
    const number = ref(authStore.user.phone_number);
    const email = ref(authStore.user.email);
    useHead({
      title: "\u041A\u0430\u0431\u0438\u043D\u0435\u0442",
      meta: []
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$4;
      const _component_UserComponentsDashboardList = __nuxt_component_1;
      if (unref(authStore).user) {
        _push(`<div${ssrRenderAttrs(_attrs)}><div class="container"><nav aria-label="breadcrumb"><ol class="breadcrumb onmalika-breadcrumb"><li class="breadcrumb-item">`);
        _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u0413\u043B\u0430\u0432\u043D\u0430\u044F`);
            } else {
              return [
                createTextVNode("\u0413\u043B\u0430\u0432\u043D\u0430\u044F")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</li><li class="breadcrumb-item active" aria-current="page">\u041F\u0440\u043E\u0444\u0438\u043B\u044C</li></ol></nav></div><section><div class="container"><h1>\u041F\u0440\u043E\u0444\u0438\u043B\u044C</h1><div class="row">`);
        _push(ssrRenderComponent(_component_UserComponentsDashboardList, null, null, _parent));
        _push(`<div class="col-lg-10 col-xl-10"><div class="onmalika-user-settings"><form><div class="row"><div class="col-6 mb-3"><label for="userChangeName" class="form-label">\u0412\u0430\u0448\u0435 \u0438\u043C\u044F</label><input${ssrRenderAttr("value", unref(name))} type="text" class="form-control" id="userChangeName"></div><div class="col-6 mb-3"><label for="userChangeSurName" class="form-label">\u0412\u0430\u0448\u0430 \u0444\u0430\u043C\u0438\u043B\u0438\u044F</label><input${ssrRenderAttr("value", unref(surname))} type="text" class="form-control" id="userChangeSurName"></div><div class="col-6 mb-3"><label for="userChangeNumber" class="form-label">\u0412\u0430\u0448 \u043D\u043E\u043C\u0435\u0440</label><input${ssrRenderAttr("value", unref(number))} type="text" class="form-control" id="userChangeNumber"></div><div class="col-6 mb-3"><label for="userChangeNumber" class="form-label">\u0412\u0430\u0448 email</label><input${ssrRenderAttr("value", unref(email))} type="email" class="form-control" id="userChangeNumber"></div></div><div class="btn-group" role="group" aria-label="Basic example"><button type="submit" class="btn dark-cover"> \u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F</button></div></form></div></div></div></div></section></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-9b105706.mjs.map
