import { h as useCookie, u as useRoute, a as useJsonPlaceholderData, c as createError, f as useCurrencyStore, g as __nuxt_component_0$4 } from '../server.mjs';
import { withAsyncContext, withCtx, createTextVNode, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'vue-router';
import 'lodash';

const _sfc_main = {
  __name: "[id]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const token_access = useCookie("token_access");
    const route = useRoute();
    const { data: order } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/user/orders/" + route.params.id, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token_access.value}`
      }
    })), __temp = await __temp, __restore(), __temp);
    if (!order.value || !order.value.id || !order.value.items) {
      throw createError({ statusCode: 404, message: "\u0422\u0430\u043A\u043E\u0433\u043E \u0437\u0430\u043A\u0430\u0437\u0430 \u043D\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442" });
    }
    const currencyStore = useCurrencyStore();
    const getPriceInSelectedCurrency = (product) => {
      const selectedCurrency = currencyStore.selectedCurrency;
      const priceInfo = product.prices_in_currencies[selectedCurrency];
      if (!priceInfo) {
        return "\u0426\u0435\u043D\u0430 \u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u0430";
      }
      return `${priceInfo.price} ${priceInfo.symbol}`;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$4;
      _push(`<div${ssrRenderAttrs(_attrs)}><section class="bg-primary padding-y-sm"><div class="container"><ol class="breadcrumb ondark mb-0"><li class="breadcrumb-item">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0413\u043B\u0430\u0432\u043D\u0430\u044F`);
          } else {
            return [
              createTextVNode("\u0413\u043B\u0430\u0432\u043D\u0430\u044F")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/user" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u041A\u0430\u0431\u0438\u043D\u0435\u0442`);
          } else {
            return [
              createTextVNode("\u041A\u0430\u0431\u0438\u043D\u0435\u0442")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/user/orders" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0417\u0430\u043A\u0430\u0437\u044B`);
          } else {
            return [
              createTextVNode("\u0417\u0430\u043A\u0430\u0437\u044B")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item active" aria-current="page">\u0417\u0430\u043A\u0430\u0437 #${ssrInterpolate(unref(order).id)}</li></ol></div></section><section class="padding-y"><div class="container"><h2>\u0417\u0430\u043A\u0430\u0437 #${ssrInterpolate(unref(order).id)}</h2><h3>\u041E\u0431\u0449\u0430\u044F \u0441\u0443\u043C\u043C\u0430 ${ssrInterpolate(unref(order).total_price)}$</h3><h4 class="mb-3">\u0422\u043E\u0432\u0430\u0440\u044B \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0432\u044B \u0437\u0430\u043A\u0430\u0437\u043B\u0438</h4><!--[-->`);
      ssrRenderList(unref(order).items, (item) => {
        _push(`<div class="row align-items-center mb-3"><div class="col-2"><img${ssrRenderAttr("src", "http://64.23.130.79:8000" + item.product.image.url)} class="w-100" alt=""></div><div class="col-3"><h6>${ssrInterpolate(item.product.name)}</h6></div><div class="col-2"><h6> \u041A\u043E\u043B-\u0432\u043E: ${ssrInterpolate(item.quantity)}</h6></div><div class="col-2"><h6> \u0426\u0435\u043D\u0430 \u0442\u043E\u0432\u0430\u0440\u0430: <br> ${ssrInterpolate(getPriceInSelectedCurrency(item.product))}</h6></div><div class="col-3"><h6>\u041E\u0431\u0449\u0430\u044F \u0441\u0443\u043C\u043C\u0430 \u044D\u0442\u043E\u0433\u043E \u0442\u043E\u0432\u0430\u0440\u0430 <br> ${ssrInterpolate(item.total_price)}$ </h6></div></div>`);
      });
      _push(`<!--]--></div></section></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/orders/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_id_-667b8edf.mjs.map
