import { u as useRoute, b as useRouter, a as useJsonPlaceholderData, c as createError, _ as _export_sfc, g as __nuxt_component_0$4 } from '../server.mjs';
import { _ as __nuxt_component_1 } from './Card-9f638715.mjs';
import { ref, withAsyncContext, computed, watch, withCtx, createTextVNode, unref, toDisplayString, useSSRContext, mergeProps } from 'vue';
import { u as useSeoMeta } from './index-6fec30d9.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr, ssrRenderClass, ssrIncludeBooleanAttr, ssrRenderStyle } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'vue-router';
import 'lodash';
import 'unhead';
import '@unhead/shared';

const _sfc_main$1 = {
  name: "MultiRangeSlider",
  props: {
    baseClassName: {
      type: String,
      default: "multi-range-slider"
    },
    min: { type: Number },
    max: { type: Number },
    minValue: { type: Number },
    maxValue: { type: Number },
    step: { type: Number, default: 1 },
    preventWheel: { type: Boolean, default: false },
    ruler: { type: Boolean, default: true },
    label: { type: Boolean, default: true },
    labels: { type: Array },
    minCaption: { type: String },
    maxCaption: { type: String },
    rangeMargin: { type: Number }
  },
  data() {
    let _labels = this.labels || [];
    let _minimum = this.min === void 0 ? 0 : this.min;
    let max = _labels.length ? _labels.length - 1 : 100;
    let _maximum = this.max === void 0 ? max : this.max;
    let _minValue = this.minValue === void 0 ? 25 : this.minValue;
    if (_labels.length && this.minValue === void 0) {
      _minValue = 1;
    }
    let _maxValue = this.maxValue || 75;
    if (_labels.length && this.maxValue === void 0) {
      _maxValue = _labels.length - 2;
    }
    if (_maximum <= _minimum) {
      throw new Error("Invalid props min or max");
    }
    if (_minValue > _maxValue) {
      throw new Error("Invalid props minValue or maxValue");
    }
    let _rangeMargin = this.rangeMargin === void 0 ? this.step : this.rangeMargin;
    let m = _rangeMargin % this.step;
    m && (_rangeMargin = _rangeMargin + this.step - m);
    return {
      valueMin: _minValue < _minimum ? _minimum : _minValue,
      valueMax: _maxValue > _maximum ? _maximum : _maxValue,
      interVal: null,
      startX: null,
      mouseMoveCounter: null,
      barBox: null,
      barValue: 0,
      rangeMarginValue: _rangeMargin
    };
  },
  methods: {
    onBarLeftClick() {
      if (this.valueMin - this.step >= this.minimum) {
        this.valueMin -= this.step;
      } else {
        this.valueMin = this.minimum;
      }
    },
    onInnerBarLeftClick() {
      if (this.valueMin + this.rangeMarginValue < this.valueMax) {
        this.valueMin += this.step;
      }
    },
    onBarRightClick() {
      if (this.valueMax + this.step <= this.maximum) {
        this.valueMax += this.step;
      } else {
        this.valueMax = this.maximum;
      }
    },
    onInnerBarRightClick() {
      if (this.valueMax - this.rangeMarginValue > this.valueMin) {
        this.valueMax -= this.step;
      }
    },
    onInputMinChange(e) {
      let val = parseFloat(e.target.value);
      if (val <= this.valueMax - this.rangeMarginValue && val >= this.minimum) {
        this.valueMin = val;
      } else {
        e.target.value = this.valueMin;
      }
    },
    onInputMaxChange(e) {
      let val = parseFloat(e.target.value);
      if (val >= this.valueMin + this.rangeMarginValue && val <= this.maximum) {
        this.valueMax = val;
      } else {
        e.target.value = this.valueMax;
      }
    },
    onLeftThumbMousedown(e) {
      e.preventDefault();
      this.startX = e.clientX;
      if (e.type === "touchstart") {
        if (e.touches.length === 1) {
          this.startX = e.touches[0].clientX;
        } else {
          return;
        }
      }
      this.mouseMoveCounter = 0;
      this.barValue = this.valueMin;
      this.barBox = e.target.parentNode.getBoundingClientRect();
      document.addEventListener("mousemove", this.onLeftThumbMousemove);
      document.addEventListener("mouseup", this.onLeftThumbMouseup);
      document.addEventListener("touchmove", this.onLeftThumbMousemove);
      document.addEventListener("touchend", this.onLeftThumbMouseup);
    },
    onLeftThumbMousemove(e) {
      this.mouseMoveCounter++;
      let clientX = e.clientX;
      if (e.type === "touchmove") {
        clientX = e.touches[0].clientX;
      }
      let dx = clientX - this.startX;
      let per = dx / this.barBox.width;
      let val = this.barValue + (this.maximum - this.minimum) * per;
      let mod = val % this.step;
      val -= mod;
      if (val < this.minimum) {
        val = this.minimum;
      } else if (val > this.valueMax - this.rangeMarginValue) {
        val = this.valueMax - this.rangeMarginValue;
      }
      this.valueMin = val;
    },
    onLeftThumbMouseup() {
      document.removeEventListener("mousemove", this.onLeftThumbMousemove);
      document.removeEventListener("mouseup", this.onLeftThumbMouseup);
      document.removeEventListener("touchmove", this.onLeftThumbMousemove);
      document.removeEventListener("touchend", this.onLeftThumbMouseup);
    },
    onRightThumbMousedown(e) {
      e.preventDefault();
      this.startX = e.clientX;
      if (e.type === "touchstart") {
        if (e.touches.length === 1) {
          this.startX = e.touches[0].clientX;
        } else {
          return;
        }
      }
      this.mouseMoveCounter = 0;
      this.barValue = this.valueMax;
      this.barBox = e.target.parentNode.getBoundingClientRect();
      document.addEventListener("mousemove", this.onRightThumbMousemove);
      document.addEventListener("mouseup", this.onRightThumbMouseup);
      document.addEventListener("touchmove", this.onRightThumbMousemove);
      document.addEventListener("touchend", this.onRightThumbMouseup);
    },
    onRightThumbMousemove(e) {
      this.mouseMoveCounter++;
      let clientX = e.clientX;
      if (e.type === "touchmove") {
        clientX = e.touches[0].clientX;
      }
      let dx = clientX - this.startX;
      let per = dx / this.barBox.width;
      let val = this.barValue + (this.maximum - this.minimum) * per;
      let mod = val % this.step;
      val -= mod;
      if (val < this.valueMin + this.rangeMarginValue) {
        val = this.valueMin + this.rangeMarginValue;
      } else if (val > this.maximum) {
        val = this.maximum;
      }
      this.valueMax = val;
    },
    onRightThumbMouseup() {
      document.removeEventListener("mousemove", this.onRightThumbMousemove);
      document.removeEventListener("mouseup", this.onRightThumbMouseup);
      document.removeEventListener("touchmove", this.onRightThumbMousemove);
      document.removeEventListener("touchend", this.onRightThumbMouseup);
    },
    onMouseWheel(e) {
      if (this.preventWheel === true) {
        return;
      }
      if (!e.shiftKey && !e.ctrlKey) {
        return;
      }
      let val = this.step;
      if (e.deltaY < 0) {
        val = -val;
      }
      if (e.shiftKey && e.ctrlKey) {
        if (this.valueMin + val >= this.minimum && this.valueMax + val <= this.maximum) {
          this.valueMin = this.valueMin + val;
          this.valueMax = this.valueMax + val;
        }
      } else if (e.ctrlKey) {
        val = this.valueMax + val;
        if (val < this.valueMin + this.rangeMarginValue) {
          val = this.valueMin + this.rangeMarginValue;
        } else if (val > this.maximum) {
          val = this.maximum;
        }
        this.valueMax = val;
      } else if (e.shiftKey) {
        val = this.valueMin + val;
        if (val < this.minimum) {
          val = this.minimum;
        } else if (val > this.valueMax - this.rangeMarginValue) {
          val = this.valueMax - this.rangeMarginValue;
        }
        this.valueMin = val;
      }
    },
    triggerInput() {
      let fixed = 0;
      if (this.step.toString().includes(".")) {
        fixed = 2;
      }
      let retObj = {
        min: this.minimum,
        max: this.maximum,
        minValue: parseFloat(this.valueMin.toFixed(fixed)),
        maxValue: parseFloat(this.valueMax.toFixed(fixed))
      };
      this.$emit("input", retObj);
    }
  },
  computed: {
    minimum() {
      return this.min === void 0 ? 0 : this.min;
    },
    maximum() {
      let _labels = this.labels || [];
      let max = _labels.length ? _labels.length - 1 : 100;
      return this.max === void 0 ? max : this.max;
    },
    stepCount() {
      let _labels = this.labels || [];
      if (_labels.length) {
        return _labels.length - 1;
      }
      return Math.floor((this.maximum - this.minimum) / this.step);
    },
    subStepCount() {
      let _labels = this.labels || [];
      if (_labels.length && this.step > 1) {
        return (this.maximum - this.minimum) / this.step;
      }
      return 0;
    },
    barMin() {
      let per = (this.valueMin - this.minimum) / (this.maximum - this.minimum) * 100;
      return per;
    },
    barMax() {
      let per = 100 - (this.valueMax - this.minimum) / (this.maximum - this.minimum) * 100;
      return per;
    },
    barMinVal() {
      let fixed = 0;
      if (this.step.toString().includes(".")) {
        fixed = 2;
      }
      return (this.valueMin || 0).toFixed(fixed);
    },
    barMaxVal() {
      let fixed = 0;
      if (this.step.toString().includes(".")) {
        fixed = 2;
      }
      return (this.valueMax || 100).toFixed(fixed);
    },
    scaleLabels() {
      let _labels = this.labels || [];
      if (_labels.length === 0) {
        _labels = [];
        _labels.push(this.minimum);
        _labels.push(this.maximum);
      }
      return _labels;
    }
  },
  watch: {
    valueMin() {
      this.triggerInput();
    },
    valueMax() {
      this.triggerInput();
    },
    minValue(newValue) {
      this.valueMin = newValue < this.minimum ? this.minimum : newValue;
    },
    maxValue(newValue) {
      this.valueMax = newValue > this.maximum ? this.maximum : newValue;
    }
  },
  mounted() {
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({
    class: [$props.baseClassName, $data.rangeMarginValue === 0 ? "zero-ranage-margin" : ""]
  }, _attrs))}><div class="bar"><div class="bar-left" style="${ssrRenderStyle({ width: $options.barMin + "%" })}"></div><input class="input-type-range input-type-range-min" type="range"${ssrRenderAttr("min", $options.minimum)}${ssrRenderAttr("max", $options.maximum)}${ssrRenderAttr("step", $props.step)}${ssrRenderAttr("value", $data.valueMin)}><div class="thumb thumb-left"><div class="caption"><span class="min-caption">${ssrInterpolate($props.minCaption || $options.barMinVal)}</span></div></div><div class="bar-inner"><div class="bar-inner-left"></div><div class="bar-inner-right"></div></div><input class="input-type-range input-type-range-max" type="range"${ssrRenderAttr("min", $options.minimum)}${ssrRenderAttr("max", $options.maximum)}${ssrRenderAttr("step", $props.step)}${ssrRenderAttr("value", $data.valueMax)}><div class="thumb thumb-right"><div class="caption"><span class="max-caption">${ssrInterpolate($props.maxCaption || $options.barMaxVal)}</span></div></div><div class="bar-right" style="${ssrRenderStyle({ width: $options.barMax + "%" })}"></div></div>`);
  if ($props.ruler) {
    _push(`<div class="ruler"><!--[-->`);
    ssrRenderList($options.stepCount, (n) => {
      _push(`<div class="ruler-rule"></div>`);
    });
    _push(`<!--]--></div>`);
  } else {
    _push(`<!---->`);
  }
  if ($options.subStepCount) {
    _push(`<div class="sub-ruler"><!--[-->`);
    ssrRenderList($options.subStepCount, (n) => {
      _push(`<div class="ruler-sub-rule"></div>`);
    });
    _push(`<!--]--></div>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.label) {
    _push(`<div class="labels"><!--[-->`);
    ssrRenderList($options.scaleLabels, (label) => {
      _push(`<div class="label">${ssrInterpolate(label)}</div>`);
    });
    _push(`<!--]--></div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/multi-range-slider-vue/MultiRangeSlider.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const MultiRangeSlider = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const pageSize = 9;
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const route = useRoute();
    const router = useRouter();
    const attrList = ref();
    const { data: category } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/categories/")), __temp = await __temp, __restore(), __temp);
    const { data: solo_category } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/categories/" + route.params.subCategory)), __temp = await __temp, __restore(), __temp);
    const { data: attr_list } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData(`/products/?category=${solo_category.value.id}`)), __temp = await __temp, __restore(), __temp);
    attrList.value = attr_list.value.attr_filters;
    if (!solo_category.value) {
      throw createError({ statusCode: 404, message: "\u0422\u0430\u043A\u043E\u0439 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438 \u043D\u0435\u0442\u0443" });
    }
    const { data: previous_category } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/categories/" + route.params.category)), __temp = await __temp, __restore(), __temp);
    computed(() => category.value);
    const hierarchicalCategories = ref([]);
    const isSubcategorySelected = (cats) => {
      return cats.subcategories.some((subcat) => route.params.subCategory === subcat.slug);
    };
    const products = ref([]);
    const nextUrl = ref(null);
    const prevUrl = ref(null);
    const currentPage = ref(1);
    const totalCount = ref(0);
    const selectedAttributes = ref([]);
    const totalPages = computed(() => Math.ceil(totalCount.value / pageSize));
    const selectFilterOfProducts = ref("");
    const selectedFilterText = ref("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u043A\u0443");
    const sortFilter = ref("");
    const barMinValue = ref(0);
    const barMaxValue = ref(1e3);
    const priceFilterTimeout = ref(null);
    const UpdateValues = (e) => {
      barMinValue.value = e.minValue;
      barMaxValue.value = e.maxValue;
      if (priceFilterTimeout.value) {
        clearTimeout(priceFilterTimeout.value);
      }
      debounceFetchProducts();
    };
    const debounceFetchProducts = () => {
      if (priceFilterTimeout.value)
        clearTimeout(priceFilterTimeout.value);
      priceFilterTimeout.value = setTimeout(() => {
        if (route.query.attr) {
          fetchProducts(`/products/?category=${solo_category.value.id}&limit=${pageSize}&attr=${route.query.attr}&price_from=${barMinValue.value}&price_to=${barMaxValue.value}`);
        } else {
          fetchProducts(`/products/?category=${solo_category.value.id}&limit=${pageSize}&price_from=${barMinValue.value}&price_to=${barMaxValue.value}`);
        }
      }, 1e3);
    };
    watch([barMinValue, barMaxValue], () => {
      if (priceFilterTimeout.value) {
        clearTimeout(priceFilterTimeout.value);
      }
      priceFilterTimeout.value = setTimeout(() => {
        if (route.query.attr) {
          fetchProducts(`/products/?category=${solo_category.value.id}&limit=${pageSize}&attr=${route.query.attr}&price_from=${barMinValue.value}&price_to=${barMaxValue.value}`);
        } else {
          fetchProducts(`/products/?category=${solo_category.value.id}&limit=${pageSize}&price_from=${barMinValue.value}&price_to=${barMaxValue.value}`);
        }
      }, 1e3);
    });
    const fetchProducts = async (url) => {
      try {
        const res = await useJsonPlaceholderData(url + "&ordering=" + sortFilter.value, {
          cache: false
        });
        const data = res.data;
        products.value = data.value.results;
        nextUrl.value = data.value.next;
        prevUrl.value = data.value.previous;
        totalCount.value = data.value.count;
      } catch (error) {
      }
    };
    fetchProducts("/products/?category=" + solo_category.value.id + "&limit=" + pageSize);
    const updateProductsByPage = (page) => {
      const offset = (page - 1) * pageSize;
      if (route.query.attr) {
        fetchProducts(`/products/?category=${solo_category.value.id}&limit=${pageSize}&attr=${route.query.attr}&offset=${offset}`);
      } else {
        fetchProducts(`/products/?category=${solo_category.value.id}&limit=${pageSize}&offset=${offset}`);
      }
    };
    watch(selectedAttributes, () => {
      const { path, query } = router.currentRoute.value;
      const newQuery = { ...query };
      if (selectedAttributes.value.length === 0) {
        delete newQuery.attr;
      } else {
        newQuery.attr = selectedAttributes.value.join(",");
      }
      router.replace({
        path,
        query: newQuery
      });
    });
    watch(selectFilterOfProducts, () => {
      sortFilter.value = selectFilterOfProducts.value;
      updateProductsByPage(currentPage.value);
    });
    ref([]);
    const isSelected = (id) => {
      const queryParams = route.query.attr ? route.query.attr.split(",").map((value) => parseInt(value, 10)) : [];
      const isSelected2 = queryParams.includes(id);
      return isSelected2;
    };
    useSeoMeta({
      title: solo_category.value.name,
      ogTitle: solo_category.value.name
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$4;
      const _component_Card = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="container"><nav aria-label="breadcrumb"><ol class="breadcrumb onmalika-breadcrumb"><li class="breadcrumb-item">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0413\u043B\u0430\u0432\u043D\u0430\u044F`);
          } else {
            return [
              createTextVNode("\u0413\u043B\u0430\u0432\u043D\u0430\u044F")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/shop" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u041C\u0430\u0433\u0430\u0437\u0438\u043D\u0447\u0438\u043A`);
          } else {
            return [
              createTextVNode("\u041C\u0430\u0433\u0430\u0437\u0438\u043D\u0447\u0438\u043A")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/shop/" + unref(previous_category).slug
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(unref(previous_category).name)}`);
          } else {
            return [
              createTextVNode(toDisplayString(unref(previous_category).name), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item active" aria-current="page">${ssrInterpolate(unref(solo_category).name)}</li></ol></nav></div><section class="padding-y"><div class="container"><div class="row mb-4"><div class="col-3"><div class="accordion onmalika-accardion mb-5" id="accordionCategories"><!--[-->`);
      ssrRenderList(unref(hierarchicalCategories), (cats, index) => {
        _push(`<div class="accordion-item"><h2 class="accordion-header"${ssrRenderAttr("id", "headingOne-" + cats.slug)}><button class="${ssrRenderClass([{ "collapsed": !isSubcategorySelected(cats) }, "accordion-button"])}" type="button" data-bs-toggle="collapse"${ssrRenderAttr("data-bs-target", "#collapseOne-" + cats.slug)} aria-expanded="true"${ssrRenderAttr("aria-controls", "collapseOne-" + cats.slug)}>${ssrInterpolate(cats.name)}</button></h2><div${ssrRenderAttr("id", "collapseOne-" + cats.slug)} class="${ssrRenderClass([{ "show": isSubcategorySelected(cats) }, "accordion-collapse collapse"])}"${ssrRenderAttr("aria-labelledby", "headingOne" + cats.slug)} data-bs-parent="#accordionCategories"><div class="accordion-body"><!--[-->`);
        ssrRenderList(cats.subcategories, (subcat) => {
          _push(`<div class="form-check"><input class="form-check-input"${ssrIncludeBooleanAttr(unref(route).params.subCategory === subcat.slug) ? " checked" : ""} type="radio" name="categoryRadio"${ssrRenderAttr("id", "category" + subcat.id)}${ssrRenderAttr("value", subcat.slug)}><label class="form-check-label"${ssrRenderAttr("for", "category" + subcat.id)}>${ssrInterpolate(subcat.name)}</label></div>`);
        });
        _push(`<!--]--></div></div></div>`);
      });
      _push(`<!--]--></div><div class="multi-range mb-5"><div class="multi-range-inputs"><input type="number"${ssrRenderAttr("value", unref(barMinValue))} class="form-control gray-conrol w-100"><input type="number"${ssrRenderAttr("value", unref(barMaxValue))} class="form-control gray-conrol w-100"></div>`);
      _push(ssrRenderComponent(unref(MultiRangeSlider), {
        min: 0,
        step: 100,
        max: 1e3,
        ruler: false,
        label: false,
        minValue: unref(barMinValue),
        maxValue: unref(barMaxValue),
        onInput: UpdateValues
      }, null, _parent));
      _push(`</div><div class="accordion onmalika-accardion mb-5" id="accordionFilters"><!--[-->`);
      ssrRenderList(unref(attrList), (atrs, index) => {
        _push(`<div class="accordion-item"><h2 class="accordion-header"><button type="button" class="accordion-button" data-bs-toggle="collapse"${ssrRenderAttr("data-bs-target", "#collapseOne" + index)}><i class="icon-control fa fa-chevron-down"></i> ${ssrInterpolate(atrs.attribute.name)}</button></h2><div class="accordion-collapse show"${ssrRenderAttr("id", "collapseOne" + index)}><div class="accordion-body"><!--[-->`);
        ssrRenderList(atrs.attribute_values, (atr_val) => {
          _push(`<label class="form-check mb-2"><input class="form-check-input" type="checkbox"${ssrIncludeBooleanAttr(isSelected(atr_val.id)) ? " checked" : ""}${ssrRenderAttr("value", atr_val.id)}><span class="form-check-label">${ssrInterpolate(atr_val.value)}</span></label>`);
        });
        _push(`<!--]--></div></div></div>`);
      });
      _push(`<!--]--></div></div><div class="col-9"><div class="row mb-3"><div class="col-3"><div class="dropdown onmalika-dropdown"><button class="btn onmalika-dropdown-toggle dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">${ssrInterpolate(unref(selectedFilterText))} <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.2807 5.9668L8.93404 10.3135C8.4207 10.8268 7.5807 10.8268 7.06737 10.3135L2.7207 5.9668" stroke="black" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path></svg></button><ul class="dropdown-menu onmalika-dropdown-menu"><li><div class="form-check dropdown-item"><input class="form-check-input" type="radio" name="categoryRadio" id="price-up"><label class="form-check-label" for="price-up"> \u041F\u043E \u0432\u043E\u0437\u0440\u0430\u0441\u0442\u0430\u043D\u0438\u044E \u0446\u0435\u043D\u044B </label></div></li><li><div class="form-check dropdown-item"><input class="form-check-input" type="radio" name="categoryRadio" id="price-down"><label class="form-check-label" for="price-down"> \u041F\u043E \u0443\u0431\u044B\u0432\u0430\u043D\u0438\u044E \u0446\u0435\u043D\u044B </label></div></li><li><div class="form-check dropdown-item"><input class="form-check-input" type="radio" name="categoryRadio" id="ASC"><label class="form-check-label" for="ASC"> \u0412 \u0430\u043B\u0444\u0430\u0432\u0438\u0442\u043D\u043E\u043C \u043F\u043E\u0440\u044F\u0434\u043A\u0435 </label></div></li><li><div class="form-check dropdown-item"><input class="form-check-input" type="radio" name="categoryRadio" id="DESC"><label class="form-check-label" for="DESC"> \u0421 \u043A\u043E\u043D\u0446\u0430 \u0430\u043B\u0444\u0430\u0432\u0438\u0442\u043D\u043E\u0433\u043E \u043F\u043E\u0440\u044F\u0434\u043A\u0430 </label></div></li></ul></div></div></div><div class="row row-cols-3"><!--[-->`);
      ssrRenderList(unref(products), (product) => {
        _push(`<div class="col mb-4">`);
        _push(ssrRenderComponent(_component_Card, { product_info: product }, null, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div></div></div>`);
      if (unref(totalPages) > 1) {
        _push(`<nav aria-label="Page navigation example"><ul class="pagination justify-content-center"><li class="page-item"><button class="${ssrRenderClass([{ "disabled": unref(currentPage) === 1 }, "page-link"])}"${ssrIncludeBooleanAttr(unref(currentPage) === 1) ? " disabled" : ""}>\u041F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0430\u044F \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430</button></li><!--[-->`);
        ssrRenderList(unref(totalPages), (page) => {
          _push(`<li class="page-item"><button class="${ssrRenderClass([{ active: page === unref(currentPage) }, "page-link"])}">${ssrInterpolate(page)}</button></li>`);
        });
        _push(`<!--]--><li class="page-item"><button class="${ssrRenderClass([{ "disabled": unref(currentPage) === unref(totalPages) }, "page-link"])}"${ssrIncludeBooleanAttr(unref(currentPage) === unref(totalPages)) ? " disabled" : ""}>\u0421\u043B\u0435\u0434\u0443\u044E\u0449\u0430\u044F \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430</button></li></ul></nav>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></section></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/shop/[category]/[subCategory]/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-9ebde1b2.mjs.map
