import { u as useRoute, h as useCookie, e as useAuthStore, a as useJsonPlaceholderData, g as __nuxt_component_0$4, d as useCartStore, f as useCurrencyStore } from '../server.mjs';
import { _ as __nuxt_component_1 } from './DashboardList-9ea80a24.mjs';
import { withAsyncContext, watch, withCtx, createTextVNode, unref, useSSRContext, mergeProps, openBlock, createBlock } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate, ssrRenderClass } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'vue-router';
import 'lodash';

const baseurl = "http://64.23.130.79:8000";
const _sfc_main$1 = {
  __name: "FavoritesCard",
  __ssrInlineRender: true,
  props: {
    product_info: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    useCartStore();
    useCookie("token_access");
    const { product_info } = props;
    const currencyStore = useCurrencyStore();
    const getPriceText = () => {
      const currency = currencyStore.selectedCurrency;
      const priceInfo = product_info.product.prices_in_currencies[currency];
      if (!priceInfo) {
        return "\u0426\u0435\u043D\u0430 \u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u0430";
      }
      return `${priceInfo.price} ${priceInfo.symbol}`;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "col" }, _attrs))}><div class="card onmalika-card h-100"><div class="onmalika-card-badges"><span class="badge onmalika-card-badges-new">new</span><span class="badge onmalika-card-badges-sales">-20%</span></div><button class="onmalika-card-favorite active"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></button>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/shop/" + unref(product_info).product.category.parent.slug + "/" + unref(product_info).product.category.slug + "/" + unref(product_info).product.slug
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (unref(product_info).product && unref(product_info).product.image && unref(product_info).product.image.card) {
              _push2(`<img${ssrRenderAttr("src", baseurl + unref(product_info).product.image.card)} class="card-img-top" alt="..."${_scopeId}>`);
            } else {
              _push2(`<img src="https://placehold.co/250x250" class="w-100" alt=""${_scopeId}>`);
            }
          } else {
            return [
              unref(product_info).product && unref(product_info).product.image && unref(product_info).product.image.card ? (openBlock(), createBlock("img", {
                key: 0,
                src: baseurl + unref(product_info).product.image.card,
                class: "card-img-top",
                alt: "..."
              }, null, 8, ["src"])) : (openBlock(), createBlock("img", {
                key: 1,
                src: "https://placehold.co/250x250",
                class: "w-100",
                alt: ""
              }))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="card-body onmalika-card-body"><h5 class="onmalika-card-title">${ssrInterpolate(unref(product_info).product.name)}</h5><div class="onmalika-card-stock"><div class="stock in-stock"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 22C17.5 22 22 17.5 22 12C22 6.5 17.5 2 12 2C6.5 2 2 6.5 2 12C2 17.5 6.5 22 12 22Z" stroke="#46AC36" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M7.75 11.9999L10.58 14.8299L16.25 9.16992" stroke="#46AC36" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg><p> \u0415\u0441\u0442\u044C \u0432 \u043D\u0430\u043B\u0438\u0447\u0438\u0438</p></div></div><div class="onmalika-card-price"><span class="${ssrRenderClass({ "active": unref(product_info).product.sales_price })}">${ssrInterpolate(getPriceText())}</span><p class="${ssrRenderClass({ "d-none": !unref(product_info).product.sales_price })}">${ssrInterpolate(unref(product_info).product.sales_price)}</p></div><div class="onmalika-card-body-orderbtn"><button type="button" class="btn dark-cover w-50 justify-content-center"> \u0412 \u043A\u043E\u0440\u0437\u0438\u043D\u0443</button><p><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.5639 4.3011L15.1502 7.49508C15.364 7.93681 15.9378 8.35588 16.4216 8.44649L19.2905 8.92219C21.1244 9.22799 21.5519 10.5645 20.2356 11.901L17.9967 14.1549C17.6254 14.5286 17.4116 15.2649 17.5354 15.7972L18.1767 18.5834C18.683 20.7807 17.5129 21.6415 15.589 20.4862L12.9001 18.8779C12.4163 18.5834 11.6062 18.5834 11.1224 18.8779L8.43351 20.4862C6.50963 21.6302 5.33955 20.7807 5.84583 18.5834L6.48712 15.7972C6.58838 15.2535 6.37462 14.5173 6.00334 14.1436L3.76444 11.8896C2.4481 10.5645 2.87563 9.22799 4.7095 8.91086L7.57845 8.43516C8.06223 8.35588 8.63602 7.92548 8.84979 7.48376L10.4361 4.28977C11.3025 2.56819 12.6975 2.56819 13.5639 4.3011Z" fill="#FFB800"></path></svg> 5.0 </p></div></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UserComponents/FavoritesCard.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$1;
const _sfc_main = {
  __name: "favorite",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const route = useRoute();
    const token_access = useCookie("token_access");
    const authStore = useAuthStore();
    const { data: favorite_products } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/user/favorites/", {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token_access.value}`
      }
    })), __temp = await __temp, __restore(), __temp);
    watch(() => route.path, (newPath) => {
      if (newPath === "/user/favorite" && !localStorage.getItem("reloaded")) {
        localStorage.setItem("reloaded", "true");
        window.location.reload();
      }
    });
    watch(() => route.path, (newPath) => {
      if (newPath !== "/user/favorite") {
        localStorage.removeItem("reloaded");
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$4;
      const _component_UserComponentsDashboardList = __nuxt_component_1;
      const _component_UserComponentsFavoritesCard = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="container"><nav aria-label="breadcrumb"><ol class="breadcrumb onmalika-breadcrumb"><li class="breadcrumb-item">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0413\u043B\u0430\u0432\u043D\u0430\u044F`);
          } else {
            return [
              createTextVNode("\u0413\u043B\u0430\u0432\u043D\u0430\u044F")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/user" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u041F\u0440\u043E\u0444\u0438\u043B\u044C`);
          } else {
            return [
              createTextVNode("\u041F\u0440\u043E\u0444\u0438\u043B\u044C")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item active" aria-current="page">\u0418\u0437\u0431\u0440\u0430\u043D\u043D\u044B\u0435</li></ol></nav></div><section class="padding-y">`);
      if (unref(authStore).user) {
        _push(`<div class="container"><h1>\u0418\u0437\u0431\u0440\u0430\u043D\u043D\u044B\u0435</h1><div class="row">`);
        _push(ssrRenderComponent(_component_UserComponentsDashboardList, null, null, _parent));
        _push(`<div class="col-10">`);
        if (unref(favorite_products) && unref(favorite_products).lenght > 0) {
          _push(`<div class="row row-cols-3"><!--[-->`);
          ssrRenderList(unref(favorite_products), (userFav) => {
            _push(ssrRenderComponent(_component_UserComponentsFavoritesCard, {
              key: userFav.product.id,
              product_info: userFav,
              userFav: true
            }, null, _parent));
          });
          _push(`<!--]--></div>`);
        } else {
          _push(`<div class="empty-cart"><h4> \u0412 \u0438\u0437\u0431\u0440\u0430\u043D\u043D\u043E\u043C \u043F\u043E\u043A\u0430 \u043D\u0435\u0442 \u0442\u043E\u0432\u0430\u0440\u043E\u0432</h4><p>\u0422\u043E\u0432\u0430\u0440\u044B \u043C\u043E\u0436\u043D\u043E \u0434\u043E\u0431\u0430\u0432\u0438\u0442\u044C,\xA0\u043D\u0430\u0436\u0430\u0432 \u043D\u0430 <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></p></div>`);
        }
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</section></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/favorite.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=favorite-f4c82d1c.mjs.map
