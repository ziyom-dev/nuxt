import { e as useAuthStore, b as useRouter, d as useCartStore, h as useCookie, f as useCurrencyStore, g as __nuxt_component_0$4 } from '../server.mjs';
import { computed, ref, withCtx, createTextVNode, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'vue-router';
import 'lodash';

const baseurl = "http://64.23.130.79:8000";
const _sfc_main = {
  __name: "checkout",
  __ssrInlineRender: true,
  setup(__props) {
    useAuthStore();
    useRouter();
    const cartStore = useCartStore();
    const totalPrice = computed(() => {
      return cartStore.items.reduce((total, item) => {
        return total + item.quantity * item.product.price;
      }, 0);
    });
    useCookie("token_access");
    const currencyStore = useCurrencyStore();
    const getPriceInSelectedCurrency = (product) => {
      const selectedCurrency = currencyStore.selectedCurrency;
      const priceInfo = product.prices_in_currencies[selectedCurrency];
      if (!priceInfo) {
        return "\u0426\u0435\u043D\u0430 \u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u0430";
      }
      return `${priceInfo.price} ${priceInfo.symbol}`;
    };
    ref("");
    ref("");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$4;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="container"><nav aria-label="breadcrumb"><ol class="breadcrumb onmalika-breadcrumb"><li class="breadcrumb-item">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0413\u043B\u0430\u0432\u043D\u0430\u044F`);
          } else {
            return [
              createTextVNode("\u0413\u043B\u0430\u0432\u043D\u0430\u044F")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item active" aria-current="page">\u041E\u0444\u043E\u0440\u043C\u043B\u0435\u043D\u0438\u0435 \u0437\u0430\u043A\u0430\u0437\u0430</li></ol></nav></div><section><div class="container">`);
      if (unref(cartStore).items.length > 0) {
        _push(`<div><div class="row justify-content-between"><div class="col-6"><h1> \u041E\u0444\u043E\u0440\u043C\u043B\u0435\u043D\u0438\u0435 \u0437\u0430\u043A\u0430\u0437\u0430 </h1><ul class="nav nav-pills onmalika-checkout-tabs" id="pills-tab" role="tablist"><li class="nav-item" role="presentation"><button class="nav-link active" id="pills-delivery-tab" data-bs-toggle="pill" data-bs-target="#pills-delivery" type="button" role="tab" aria-controls="pills-delivery" aria-selected="true">\u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430</button></li><li class="nav-item" role="presentation"><button class="nav-link" id="pills-takeout-tab" data-bs-toggle="pill" data-bs-target="#pills-takeout" type="button" role="tab" aria-controls="pills-takeout" aria-selected="false">\u0421\u0430\u043C\u043E\u0432\u044B\u0432\u043E\u0437</button></li></ul><div class="tab-content" id="pills-tabContent"><div class="tab-pane fade show active" id="pills-delivery" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0"><div class="gray-cover"><h5 class="mb-3">\u0412\u0430\u0448\u0438 \u0434\u0430\u043D\u043D\u044B\u0435</h5><div class="d-flex column-gap-3"><div class="form-floating w-100"><input type="email" class="form-control" id="deliverynameInput" placeholder="\u0424\u0418\u041E"><label for="floatingInput">\u0424\u0418\u041E</label></div><div class="form-floating w-100"><input type="email" class="form-control" id="deliverynumberInput" placeholder=""><label for="floatingInput">\u041D\u043E\u043C\u0435\u0440</label></div></div></div><div class="gray-cover"><h5 class="mb-3">\u0412\u0430\u0448\u0438 \u0430\u0434\u0440\u0435\u0441\u0430</h5><div class="onmalika-address"><ul><li><div class="form-check p-0 m-0"><input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1"><label class="form-check-label" for="flexRadioDefault1"> \u0428\u0430\u0439\u0445\u0430\u043D\u0442\u0430\u0445\u0443\u0440 \u0440\u0430\u0439\u043E\u043D, \u0416\u0430\u043D\u0433\u043E\u0445 \u0426 15 \u043C\u0430\u0441\u0441\u0438\u0432 33\u0430 </label></div><button type="button"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.832 18.3334V9.16669" stroke="black" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path><path d="M15.832 5.83335V1.66669" stroke="black" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10 18.3334V14.1667" stroke="black" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10 10.8334V1.66669" stroke="black" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path><path d="M4.16797 18.3334V9.16669" stroke="black" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path><path d="M4.16797 5.83335V1.66669" stroke="black" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path><path d="M2.5 9.16669H5.83333" stroke="black" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path><path d="M14.168 9.16669H17.5013" stroke="black" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path><path d="M8.33203 10.8333H11.6654" stroke="black" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path></svg></button></li><li><button type="button" class="onmalika-address-add"><div class="form-check p-0 m-0"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.9989 13.43C13.722 13.43 15.1189 12.0331 15.1189 10.31C15.1189 8.58687 13.722 7.19 11.9989 7.19C10.2758 7.19 8.87891 8.58687 8.87891 10.31C8.87891 12.0331 10.2758 13.43 11.9989 13.43Z" stroke="black" stroke-width="1.5"></path><path d="M3.62166 8.49C5.59166 -0.169998 18.4217 -0.159997 20.3817 8.5C21.5317 13.58 18.3717 17.88 15.6017 20.54C13.5917 22.48 10.4117 22.48 8.39166 20.54C5.63166 17.88 2.47166 13.57 3.62166 8.49Z" stroke="black" stroke-width="1.5"></path></svg> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043D\u043E\u0432\u044B\u0439 \u0430\u0434\u0440\u0435\u0441 </div><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 8H14" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M8 14V2" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></button></li></ul></div></div><div class="gray-cover"><h5 class="mb-3">\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043F\u043E\u0441\u043E\u0431 \u043E\u043F\u043B\u0430\u0442\u044B</h5><div class="d-flex column-gap-5"><div class="form-check p-0 m-0"><input class="form-check-input" type="radio" name="payment" id="deliverypayment1"><label class="form-check-label" for="payment1"> Click </label></div><div class="form-check p-0 m-0"><input class="form-check-input" type="radio" name="payment" id="deliverypayment2"><label class="form-check-label" for="payment2"> Payme </label></div><div class="form-check p-0 m-0"><input class="form-check-input" type="radio" name="payment" id="deliverypayment3"><label class="form-check-label" for="payment3"> \u041D\u0430\u043B\u0438\u0447\u043D\u044B\u0435 </label></div></div></div><div class="gray-cover"><h5 class="mb-3">\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043F\u043E\u0441\u043E\u0431 \u043E\u043F\u043B\u0430\u0442\u044B</h5><textarea name="" placeholder="\u0412\u0432\u0435\u0434\u0438\u0442\u0435"></textarea></div></div><div class="tab-pane fade" id="pills-takeout" role="tabpanel" aria-labelledby="pills-takeout-tab" tabindex="0"><div class="gray-cover"><h5 class="mb-3">\u0412\u0430\u0448\u0438 \u0434\u0430\u043D\u043D\u044B\u0435</h5><div class="d-flex column-gap-3"><div class="form-floating w-100"><input type="email" class="form-control" id="nameInput" placeholder="\u0424\u0418\u041E"><label for="floatingInput">\u0424\u0418\u041E</label></div><div class="form-floating w-100"><input type="email" class="form-control" id="numberInput" placeholder=""><label for="floatingInput">\u041D\u043E\u043C\u0435\u0440</label></div></div></div><div class="gray-cover"><h5 class="mb-3">\u041F\u0443\u043D\u043A\u0442 \u0432\u044B\u0434\u0430\u0447\u0438</h5><div class="onmalika-take-address d-flex align-items-center column-gap-2"><svg height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.25 22.5C17.2165 22.5 18 21.7165 18 20.75C18 19.7835 17.2165 19 16.25 19C15.2835 19 14.5 19.7835 14.5 20.75C14.5 21.7165 15.2835 22.5 16.25 22.5Z" fill="black"></path><path d="M8.25 22.5C9.2165 22.5 10 21.7165 10 20.75C10 19.7835 9.2165 19 8.25 19C7.2835 19 6.5 19.7835 6.5 20.75C6.5 21.7165 7.2835 22.5 8.25 22.5Z" fill="black"></path><path d="M4.84 3.94L4.64 6.39C4.6 6.86 4.97 7.25 5.44 7.25H20.75C21.17 7.25 21.52 6.93 21.55 6.51C21.68 4.74 20.33 3.3 18.56 3.3H6.27C6.17 2.86 5.97 2.44 5.66 2.09C5.16 1.56 4.46 1.25 3.74 1.25H2C1.59 1.25 1.25 1.59 1.25 2C1.25 2.41 1.59 2.75 2 2.75H3.74C4.05 2.75 4.34 2.88 4.55 3.1C4.76 3.33 4.86 3.63 4.84 3.94Z" fill="black"></path><path d="M20.5101 8.75H5.17005C4.75005 8.75 4.41005 9.07 4.37005 9.48L4.01005 13.83C3.87005 15.54 5.21005 17 6.92005 17H18.0401C19.5401 17 20.8601 15.77 20.9701 14.27L21.3001 9.6C21.3401 9.14 20.9801 8.75 20.5101 8.75Z" fill="black"></path></svg><p><span>\u0422\u043E\u0432\u0430\u0440\u044B \u043C\u043E\u0436\u043D\u043E \u0431\u0443\u0434\u0435\u0442 \u0437\u0430\u0431\u0440\u0430\u0442\u044C \u0432 \u043C\u0430\u0433\u0430\u0437\u0438\u043D\u0435</span> \u041F\u043E \u0430\u0434\u0440\u0435\u0441\u0443: DeLonghi, \u0428\u0430\u0439\u0445\u0430\u043D\u0442\u0430\u0445\u0443\u0440\u0441\u043A\u0438\u0439 \u0440\u0430\u0439\u043E\u043D, \u041C\u0430\u043B\u0430\u044F \u043A\u043E\u043B\u044C\u0446\u0435\u0432\u0430\u044F \u0434\u043E\u0440\u043E\u0433\u0430, 59 </p></div></div><div class="gray-cover"><h5 class="mb-3">\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043F\u043E\u0441\u043E\u0431 \u043E\u043F\u043B\u0430\u0442\u044B</h5><div class="d-flex column-gap-5"><div class="form-check p-0 m-0"><input class="form-check-input" type="radio" name="payment" id="payment1"><label class="form-check-label" for="payment1"> Click </label></div><div class="form-check p-0 m-0"><input class="form-check-input" type="radio" name="payment" id="payment2"><label class="form-check-label" for="payment2"> Payme </label></div><div class="form-check p-0 m-0"><input class="form-check-input" type="radio" name="payment" id="payment3"><label class="form-check-label" for="payment3"> \u041D\u0430\u043B\u0438\u0447\u043D\u044B\u0435 </label></div></div></div><div class="gray-cover"><h5 class="mb-3">\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043F\u043E\u0441\u043E\u0431 \u043E\u043F\u043B\u0430\u0442\u044B</h5><textarea name="" placeholder="\u0412\u0432\u0435\u0434\u0438\u0442\u0435"></textarea></div></div></div></div><div class="col-5"><h2>\u0412\u0430\u0448 \u0437\u0430\u043A\u0430\u0437</h2><div class="onmalika-cart-list"><ul><!--[-->`);
        ssrRenderList(unref(cartStore).items, (item) => {
          _push(`<li><div class="card mb-3"><div class="row g-0 align-items-center"><div class="col-md-3"><div class="gray-cover m-0">`);
          if (item && item.product && item.product.image && item.product.image.url) {
            _push(`<img${ssrRenderAttr("src", baseurl + item.product.image.url)} class="card-img-top" alt="...">`);
          } else {
            _push(`<img src="http://placehold.co/250x250" class="card-img-top" alt="...">`);
          }
          _push(`</div></div><div class="col-md-9"><div class="card-body"><h5 class="card-title">${ssrInterpolate(item.product.name)}</h5><p class="card-text">${ssrInterpolate(item.quantity)} * ${ssrInterpolate(getPriceInSelectedCurrency(item.product))}</p></div></div></div></div></li>`);
        });
        _push(`<!--]--></ul></div><div class="onmalika-price-total"><div class="d-flex justify-content-between mb-3"><p>\u0421\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0438:</p> <span>50 000 \u0441\u0443\u043C</span></div><div class="d-flex justify-content-between"><p>\u041E\u0431\u0449\u0430\u044F \u0441\u0443\u043C\u043C\u0430:</p> <span>${ssrInterpolate(unref(totalPrice))}</span></div></div><button class="dark-cover w-100 justify-content-center" type="button">\u041E\u0444\u043E\u0440\u043C\u0438\u0442\u044C \u0437\u0430\u043A\u0430\u0437</button></div></div></div>`);
      } else {
        _push(`<div><h3>\u041F\u043E\u043A\u0430 \u0447\u0442\u043E \u0437\u0434\u0435\u0441\u044C \u043F\u0443\u0441\u0442\u043E, \u0437\u0430\u043A\u0438\u043D\u044C\u0442\u0435 \u0441\u0443\u0434\u0430 \u0447\u0442\u043E \u0442\u043E :)</h3></div>`);
      }
      _push(`</div></section></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/checkout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=checkout-c9c6944c.mjs.map
