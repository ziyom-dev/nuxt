import { _ as _export_sfc, h as useCookie, a as useJsonPlaceholderData, g as __nuxt_component_0$4 } from '../server.mjs';
import { _ as __nuxt_component_1 } from './DashboardList-9ea80a24.mjs';
import { withAsyncContext, withCtx, createTextVNode, unref, openBlock, createBlock, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'vue-router';
import 'lodash';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const token_access = useCookie("token_access");
    const { data: order_list } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/user/orders/", {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token_access.value}`
      }
    })), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$4;
      const _component_UserComponentsDashboardList = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-7f357c8a><section class="bg-primary padding-y-sm" data-v-7f357c8a><div class="container" data-v-7f357c8a><ol class="breadcrumb ondark mb-0" data-v-7f357c8a><li class="breadcrumb-item" data-v-7f357c8a>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0413\u043B\u0430\u0432\u043D\u0430\u044F`);
          } else {
            return [
              createTextVNode("\u0413\u043B\u0430\u0432\u043D\u0430\u044F")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item" data-v-7f357c8a>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/user" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u041A\u0430\u0431\u0438\u043D\u0435\u0442`);
          } else {
            return [
              createTextVNode("\u041A\u0430\u0431\u0438\u043D\u0435\u0442")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item active" aria-current="page" data-v-7f357c8a>\u0418\u0437\u0431\u0440\u0430\u043D\u043D\u044B\u0435</li></ol></div></section><section class="padding-y" data-v-7f357c8a><div class="container" data-v-7f357c8a><div class="row" data-v-7f357c8a>`);
      _push(ssrRenderComponent(_component_UserComponentsDashboardList, null, null, _parent));
      _push(`<div class="col-9" data-v-7f357c8a><h1 data-v-7f357c8a>\u0417\u0430\u043A\u0430\u0437\u044B</h1><div class="row mb-3 order-head" data-v-7f357c8a><div class="col-2" data-v-7f357c8a>\u041D\u043E\u043C\u0435\u0440 \u0417\u0430\u043A\u0430\u0437\u0430</div><div class="col-2" data-v-7f357c8a>\u0421\u0442\u0430\u0442\u0443\u0441</div><div class="col-3" data-v-7f357c8a>\u0412\u0440\u0435\u043C\u044F</div><div class="col-3" data-v-7f357c8a>\u0421\u0443\u043C\u043C\u0430</div><div class="col-2" data-v-7f357c8a>\u041F\u043E\u0434\u0440\u043E\u0431\u043D\u0435\u0435</div></div><!--[-->`);
      ssrRenderList(unref(order_list), (order) => {
        _push(`<div class="order-list" data-v-7f357c8a><div class="row" data-v-7f357c8a><div class="col-2" data-v-7f357c8a><div class="order-item" data-v-7f357c8a> #${ssrInterpolate(order.id)}</div></div><div class="col-2" data-v-7f357c8a><div class="order-item" data-v-7f357c8a> \u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E </div></div><div class="col-3" data-v-7f357c8a><div class="order-item" data-v-7f357c8a>${ssrInterpolate(order.created_at)}</div></div><div class="col-3" data-v-7f357c8a><div class="order-item" data-v-7f357c8a>${ssrInterpolate(order.total_price)}$ </div></div><div class="col-2" data-v-7f357c8a><div class="order-item" data-v-7f357c8a>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: "/user/orders/" + order.id
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` \u041A \u0437\u0430\u043A\u0430\u0437\u0443 <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" data-v-7f357c8a${_scopeId}><path d="M2.5 8H13.5" stroke="#2DA5F3" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-7f357c8a${_scopeId}></path><path d="M9 3.5L13.5 8L9 12.5" stroke="#2DA5F3" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-7f357c8a${_scopeId}></path></svg>`);
            } else {
              return [
                createTextVNode(" \u041A \u0437\u0430\u043A\u0430\u0437\u0443 "),
                (openBlock(), createBlock("svg", {
                  xmlns: "http://www.w3.org/2000/svg",
                  width: "16",
                  height: "16",
                  viewBox: "0 0 16 16",
                  fill: "none"
                }, [
                  createVNode("path", {
                    d: "M2.5 8H13.5",
                    stroke: "#2DA5F3",
                    "stroke-width": "1.5",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                  }),
                  createVNode("path", {
                    d: "M9 3.5L13.5 8L9 12.5",
                    stroke: "#2DA5F3",
                    "stroke-width": "1.5",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                  })
                ]))
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div></div></div>`);
      });
      _push(`<!--]--></div></div></div></section></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/orders/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-7f357c8a"]]);

export { index as default };
//# sourceMappingURL=index-0498a4bf.mjs.map
