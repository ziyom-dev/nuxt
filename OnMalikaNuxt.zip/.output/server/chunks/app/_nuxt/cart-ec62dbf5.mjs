import { _ as _export_sfc, b as useRouter, d as useCartStore, e as useAuthStore, f as useCurrencyStore, g as __nuxt_component_0$4 } from '../server.mjs';
import { computed, withCtx, createTextVNode, unref, createVNode, useSSRContext } from 'vue';
import { u as useSeoMeta } from './index-6fec30d9.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'vue-router';
import 'lodash';
import 'unhead';
import '@unhead/shared';

const baseurl = "http://64.23.130.79:8000";
const _sfc_main = {
  __name: "cart",
  __ssrInlineRender: true,
  setup(__props) {
    useRouter();
    const cartStore = useCartStore();
    useAuthStore();
    const totalPrice = computed(() => {
      return cartStore.items.reduce((total, item) => {
        return total + item.quantity * item.product.price;
      }, 0);
    });
    const currencyStore = useCurrencyStore();
    const getPriceInSelectedCurrency = (product) => {
      const selectedCurrency = currencyStore.selectedCurrency;
      const priceInfo = product.prices_in_currencies[selectedCurrency];
      if (!priceInfo) {
        return "\u0426\u0435\u043D\u0430 \u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u0430";
      }
      return `${priceInfo.price} ${priceInfo.symbol}`;
    };
    useSeoMeta({
      title: "\u041A\u043E\u0440\u0437\u0438\u043D\u0430",
      ogTitle: "\u041A\u043E\u0440\u0437\u0438\u043D\u0430"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$4;
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-85c3a425><section class="bg-primary py-5" data-v-85c3a425><div class="container" data-v-85c3a425><ol class="breadcrumb ondark mb-0" data-v-85c3a425><li class="breadcrumb-item" data-v-85c3a425>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0413\u043B\u0430\u0432\u043D\u0430\u044F`);
          } else {
            return [
              createTextVNode("\u0413\u043B\u0430\u0432\u043D\u0430\u044F")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="breadcrumb-item active" aria-current="page" data-v-85c3a425>\u041A\u043E\u0440\u0437\u0438\u043D\u0430</li></ol></div></section><section class="padding-y" data-v-85c3a425><div class="container" data-v-85c3a425>`);
      if (unref(cartStore).items.length > 0) {
        _push(`<div data-v-85c3a425><div class="row" data-v-85c3a425><div class="col-9" data-v-85c3a425><div class="big-cart-block" data-v-85c3a425><div class="cart-title" data-v-85c3a425><h1 class="m-0" data-v-85c3a425> \u041A\u043E\u0440\u0437\u0438\u043D\u0430</h1></div><div class="cart-info-list" data-v-85c3a425><div class="row" data-v-85c3a425><div class="col-5" data-v-85c3a425> \u0422\u043E\u0432\u0430\u0440\u044B </div><div class="col-3" data-v-85c3a425> \u0426\u0435\u043D\u044B </div><div class="col-2" data-v-85c3a425> \u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E </div><div class="col-2" data-v-85c3a425> \u041E\u0431\u0449\u0430\u044F \u0441\u0443\u043C\u043C\u0430 </div></div></div><div class="cart-products" data-v-85c3a425><!--[-->`);
        ssrRenderList(unref(cartStore).items, (item) => {
          _push(`<div class="row align-items-center" data-v-85c3a425><div class="col-5" data-v-85c3a425><div class="cart-product-info" data-v-85c3a425><button type="button" class="remove-button" data-v-85c3a425><i class="far fa-times-circle" data-v-85c3a425></i></button>`);
          if (item && item.product && item.product.image && item.product.image.url) {
            _push(`<img${ssrRenderAttr("src", baseurl + item.product.image.url)} class="card-img-top" alt="..." data-v-85c3a425>`);
          } else {
            _push(`<img src="http://placehold.co/250x250" class="card-img-top" alt="..." data-v-85c3a425>`);
          }
          _push(`<p data-v-85c3a425>${ssrInterpolate(item.product.name)}</p></div></div><div class="col-3" data-v-85c3a425>${ssrInterpolate(getPriceInSelectedCurrency(item.product))}</div><div class="col-2" data-v-85c3a425><div class="input-group input-spinner" data-v-85c3a425><button type="button" class="btn btn-icon btn-light" data-v-85c3a425><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="#999" viewBox="0 0 24 24" data-v-85c3a425><path d="M19 13H5v-2h14v2z" data-v-85c3a425></path></svg></button><input${ssrRenderAttr("value", item.quantity)} disabled class="form-control text-center" placeholder="" data-v-85c3a425><button type="button" class="btn btn-icon btn-light" data-v-85c3a425><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="#999" viewBox="0 0 24 24" data-v-85c3a425><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" data-v-85c3a425></path></svg></button></div></div><div class="col-2" data-v-85c3a425><span data-v-85c3a425>${ssrInterpolate(item.quantity * item.product.price)} UZS</span></div></div>`);
        });
        _push(`<!--]--></div></div>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          class: "to-shop-link",
          to: "/shop"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<i class="fal fa-arrow-left" data-v-85c3a425${_scopeId}></i> \u0412 \u043C\u0430\u0433\u0430\u0437\u0438\u043D `);
            } else {
              return [
                createVNode("i", { class: "fal fa-arrow-left" }),
                createTextVNode(" \u0412 \u043C\u0430\u0433\u0430\u0437\u0438\u043D ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="col-3" data-v-85c3a425><div class="products-block-checkout" data-v-85c3a425><p data-v-85c3a425>\u041E\u0431\u0449\u0430\u044F \u0441\u0443\u043C\u043C\u0430</p><div class="total-price" data-v-85c3a425><p data-v-85c3a425>\u0412\u0441\u0435\u0433\u043E</p><span data-v-85c3a425>${ssrInterpolate(unref(totalPrice))} $</span></div><button type="button" class="btn-orange-cart" data-v-85c3a425> \u041F\u0435\u0440\u0435\u0439\u0442\u0438 \u043A \u043E\u0444\u043E\u0440\u043C\u043B\u0435\u043D\u0438\u044E \u0437\u0430\u043A\u0430\u0437\u0430 <i class="fal fa-arrow-right" data-v-85c3a425></i></button></div></div></div></div>`);
      } else {
        _push(`<div data-v-85c3a425><h3 data-v-85c3a425>\u041F\u043E\u043A\u0430 \u0447\u0442\u043E \u0437\u0434\u0435\u0441\u044C \u043F\u0443\u0441\u0442\u043E, \u0437\u0430\u043A\u0438\u043D\u044C\u0442\u0435 \u0441\u0443\u0434\u0430 \u0447\u0442\u043E \u0442\u043E :)</h3></div>`);
      }
      _push(`</div></section></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/cart.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const cart = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-85c3a425"]]);

export { cart as default };
//# sourceMappingURL=cart-ec62dbf5.mjs.map
