const _id__vue_vue_type_style_index_0_scoped_279feee3_lang = ".fas.fa-star[data-v-279feee3]{color:#fa8232}.table>:not(caption)>*>*[data-v-279feee3]{background-color:var(--bs-table-bg);background-image:linear-gradient(var(--bs-table-accent-bg),var(--bs-table-accent-bg));border-bottom-width:1px;padding:.5rem}.rating[data-v-279feee3]{-moz-column-gap:6px;column-gap:6px;display:flex}.rating .small-text[data-v-279feee3]{color:#000;font-weight:900}.rating .stars[data-v-279feee3]{-moz-column-gap:4px;column-gap:4px;display:flex}.main-image[data-v-279feee3]{height:450px;-o-object-fit:cover;object-fit:cover}.info-paragraphs[data-v-279feee3]{color:#191c1f;font-size:14px;font-weight:600}.info-paragraphs span[data-v-279feee3]{color:#5f6c72;font-weight:400}.cart-block[data-v-279feee3]{-moz-column-gap:10px;column-gap:10px;display:flex}";

const _id_Styles_e5cb8543 = [_id__vue_vue_type_style_index_0_scoped_279feee3_lang, _id__vue_vue_type_style_index_0_scoped_279feee3_lang];

export { _id_Styles_e5cb8543 as default };
//# sourceMappingURL=_id_-styles.e5cb8543.mjs.map
