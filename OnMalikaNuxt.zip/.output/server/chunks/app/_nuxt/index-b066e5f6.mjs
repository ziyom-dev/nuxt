import { a as useJsonPlaceholderData, g as __nuxt_component_0$4, i as __nuxt_component_0$1 } from '../server.mjs';
import { withAsyncContext, ref, unref, useSSRContext, mergeProps, withCtx, createVNode, toDisplayString } from 'vue';
import { ssrRenderList, ssrRenderComponent, ssrInterpolate, ssrRenderAttrs, ssrRenderClass, ssrRenderAttr } from 'vue/server-renderer';
import { _ as __nuxt_component_1 } from './Card-9f638715.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'vue-router';
import 'lodash';

const _sfc_main$2 = {
  __name: "MainBrands",
  __ssrInlineRender: true,
  props: {
    brand_info: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const { brand_info } = props;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "col mb-4" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/brands/" + unref(brand_info).slug,
        class: "brand-main"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h4${_scopeId}>${ssrInterpolate(unref(brand_info).name)}</h4>`);
          } else {
            return [
              createVNode("h4", null, toDisplayString(unref(brand_info).name), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Brand/MainBrands.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "IndexCategoryTabs",
  __ssrInlineRender: true,
  props: {
    category_list: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const { category_list } = props;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_MiniCard = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "category-tablist" }, _attrs))}><div class="row"><div class="col-6"><ul class="nav nav-pills onmalika-index-categories mb-3" id="pills-tab" role="tablist"><!--[-->`);
      ssrRenderList(unref(category_list), (cat, index) => {
        _push(`<li class="nav-item" role="presentation"><button class="${ssrRenderClass([{ "active": index == 0 }, "nav-link btn-success btn"])}"${ssrRenderAttr("id", `pills-category-tab${index}`)} data-bs-toggle="pill"${ssrRenderAttr("data-bs-target", `#pills-category${index}`)} type="button" role="tab"${ssrRenderAttr("aria-controls", `pills-category${index}`)} aria-selected="true">${ssrInterpolate(cat.name)}</button></li>`);
      });
      _push(`<!--]--></ul></div></div><div class="tab-content" id="pills-tabContent"><!--[-->`);
      ssrRenderList(unref(category_list), (cat, index) => {
        _push(`<div class="${ssrRenderClass([{ "active show": index == 0 }, "tab-pane fade"])}"${ssrRenderAttr("id", `pills-category${index}`)} role="tabpanel"${ssrRenderAttr("aria-labelledby", `pills-category-tab${index}`)}><div class="grid-parent"><!--[-->`);
        ssrRenderList(cat.products.results, (product, number) => {
          _push(`<div class="${ssrRenderClass("grid-" + number)}">`);
          _push(ssrRenderComponent(_component_MiniCard, { product_info: product }, null, _parent));
          _push(`</div>`);
        });
        _push(`<!--]--></div></div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/IndexCategoryTabs.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$1;
const getBrandId = "lg";
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { data: products } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/products/?limit=8")), __temp = await __temp, __restore(), __temp);
    const { data: brands } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/brands/?limit=7")), __temp = await __temp, __restore(), __temp);
    const { data: getChosenBrand } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/brands/" + getBrandId)), __temp = await __temp, __restore(), __temp);
    const { data: getChosenBrandProducts } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/products/?brand_slug=" + getBrandId + "&limit=8")), __temp = await __temp, __restore(), __temp);
    const getCategoryId = ref(99);
    const categories = ref([]);
    const { data: getChosenCategory } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/categories/?parent=" + getCategoryId.value)), __temp = await __temp, __restore(), __temp);
    if (getChosenCategory.value && getChosenCategory.value.results) {
      for (const category of getChosenCategory.value.results) {
        const { data: getChosenCategoryProducts } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData(`/products/?category=${category.id}&limit=7`)), __temp = await __temp, __restore(), __temp);
        if (getChosenCategoryProducts.value) {
          category.products = getChosenCategoryProducts.value;
        }
      }
      categories.value = getChosenCategory.value.results;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BrandMainBrands = __nuxt_component_0;
      const _component_Card = __nuxt_component_1;
      const _component_IndexCategoryTabs = __nuxt_component_2;
      _push(`<!--[--><section class="padding-y brand-section"><div class="container"><h2>\u041F\u043E\u043F\u0443\u043B\u044F\u0440\u043D\u044B\u0435 \u0431\u0440\u044D\u043D\u0434\u044B</h2><div class="row row-cols-5"><!--[-->`);
      ssrRenderList(unref(brands).results, (brand) => {
        _push(ssrRenderComponent(_component_BrandMainBrands, {
          key: brand.id,
          brand_info: brand
        }, null, _parent));
      });
      _push(`<!--]--></div></div></section><section><div class="container"><div class="row justify-content-between"><div class="col-3"><h2>\u041D\u043E\u0432\u0438\u043D\u043A\u0438</h2></div><div class="col-2"> Controls </div></div><div class="row"><!--[-->`);
      ssrRenderList(unref(products).results, (product) => {
        _push(`<div class="col-lg-3 col-md-6 col-sm-6">`);
        _push(ssrRenderComponent(_component_Card, { product_info: product }, null, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div></div></section><section><img src="https://placehold.co/1920x500?text=\u0411\u0430\u043D\u043D\u0435\u0440" class="w-100" alt=""></section><section class="padding-y"><div class="container"><h2> \u0422\u043E\u0432\u0430\u0440\u044B \u0431\u0440\u044D\u043D\u0434\u0430 ${ssrInterpolate(unref(getChosenBrand).name)}</h2><div class="row row-cols-4"><!--[-->`);
      ssrRenderList(unref(getChosenBrandProducts).results, (product) => {
        _push(`<div class="col">`);
        _push(ssrRenderComponent(_component_Card, { product_info: product }, null, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div></div></section><section><div class="container"><h2>\u041F\u043E\u043F\u0443\u043B\u044F\u0440\u043D\u044B\u0435 \u0442\u043E\u0432\u0430\u0440\u044B</h2>`);
      _push(ssrRenderComponent(_component_IndexCategoryTabs, { category_list: unref(categories) }, null, _parent));
      _push(`</div></section><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-b066e5f6.mjs.map
