const index_vue_vue_type_style_index_0_scoped_7f357c8a_lang = ".order-head[data-v-7f357c8a]{background-color:#e4e7e9;color:#000;padding:10px 0}.order-list a[data-v-7f357c8a]{color:#2da5f3;text-decoration:none}.order-list .order-item[data-v-7f357c8a]{padding:10px 0}";

const indexStyles_0d6b65fd = [index_vue_vue_type_style_index_0_scoped_7f357c8a_lang, index_vue_vue_type_style_index_0_scoped_7f357c8a_lang];

export { indexStyles_0d6b65fd as default };
//# sourceMappingURL=index-styles.0d6b65fd.mjs.map
