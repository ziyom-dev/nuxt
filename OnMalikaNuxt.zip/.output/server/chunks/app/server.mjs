import { hasInjectionContext, inject, ref, defineComponent, h, Suspense, nextTick, Transition, useSSRContext, getCurrentInstance, computed, resolveComponent, reactive, provide, shallowReactive, withAsyncContext, onUnmounted, mergeProps, withCtx, createTextVNode, unref, toDisplayString, createVNode, openBlock, createBlock, createCommentVNode, createApp, toRef, onServerPrefetch, watch, effectScope, isRef, isReactive, toRaw, onErrorCaptured, resolveDynamicComponent, shallowRef, isReadonly, getCurrentScope, onScopeDispose, defineAsyncComponent, markRaw, toRefs, isShallow } from 'vue';
import { i as useRuntimeConfig$1, w as withQuery, o as hasProtocol, p as parseURL, q as isScriptProtocol, j as joinURL, l as createError$1, r as parse, t as getRequestHeader, v as defu, $ as $fetch, x as sanitizeStatusCode, y as destr, z as isEqual, s as setCookie, A as getCookie, C as deleteCookie, D as parseQuery, E as hash, F as createHooks, G as getRequestHeaders, H as withTrailingSlash, I as withoutTrailingSlash } from '../nitro/node-server.mjs';
import { RouterView, createMemoryHistory, createRouter, START_LOCATION, useRoute as useRoute$1 } from 'vue-router';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrRenderList, ssrInterpolate, ssrRenderAttr, ssrRenderClass, ssrIncludeBooleanAttr, ssrRenderSuspense, ssrRenderVNode } from 'vue/server-renderer';
import pkg from 'lodash';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';

function createContext$1(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als && currentInstance === void 0) {
      const instance = als.getStore();
      if (instance !== void 0) {
        return instance;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance, callback) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return als ? als.run(instance, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance, callback) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers$1.add(onLeave);
      try {
        const r = als ? als.run(instance, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers$1.delete(onLeave);
      }
    }
  };
}
function createNamespace$1(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext$1({ ...defaultOpts, ...opts });
      }
      contexts[key];
      return contexts[key];
    }
  };
}
const _globalThis$1 = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey$1 = "__unctx__";
const defaultNamespace = _globalThis$1[globalKey$1] || (_globalThis$1[globalKey$1] = createNamespace$1());
const getContext = (key, opts = {}) => defaultNamespace.get(key, opts);
const asyncHandlersKey$1 = "__unctx_async_handlers__";
const asyncHandlers$1 = _globalThis$1[asyncHandlersKey$1] || (_globalThis$1[asyncHandlersKey$1] = /* @__PURE__ */ new Set());

const appConfig = useRuntimeConfig$1().app;
const baseURL = () => appConfig.baseURL;
const nuxtAppCtx = /* @__PURE__ */ getContext("nuxt-app", {
  asyncContext: false
});
const NuxtPluginIndicator = "__nuxt_plugin";
function createNuxtApp(options) {
  let hydratingCount = 0;
  const nuxtApp = {
    provide: void 0,
    globalName: "nuxt",
    versions: {
      get nuxt() {
        return "3.7.0";
      },
      get vue() {
        return nuxtApp.vueApp.version;
      }
    },
    payload: reactive({
      data: {},
      state: {},
      _errors: {},
      ...{ serverRendered: true }
    }),
    static: {
      data: {}
    },
    runWithContext: (fn) => callWithNuxt(nuxtApp, fn),
    isHydrating: false,
    deferHydration() {
      if (!nuxtApp.isHydrating) {
        return () => {
        };
      }
      hydratingCount++;
      let called = false;
      return () => {
        if (called) {
          return;
        }
        called = true;
        hydratingCount--;
        if (hydratingCount === 0) {
          nuxtApp.isHydrating = false;
          return nuxtApp.callHook("app:suspense:resolve");
        }
      };
    },
    _asyncDataPromises: {},
    _asyncData: {},
    _payloadRevivers: {},
    ...options
  };
  nuxtApp.hooks = createHooks();
  nuxtApp.hook = nuxtApp.hooks.hook;
  {
    async function contextCaller(hooks, args) {
      for (const hook of hooks) {
        await nuxtApp.runWithContext(() => hook(...args));
      }
    }
    nuxtApp.hooks.callHook = (name, ...args) => nuxtApp.hooks.callHookWith(contextCaller, name, ...args);
  }
  nuxtApp.callHook = nuxtApp.hooks.callHook;
  nuxtApp.provide = (name, value) => {
    const $name = "$" + name;
    defineGetter(nuxtApp, $name, value);
    defineGetter(nuxtApp.vueApp.config.globalProperties, $name, value);
  };
  defineGetter(nuxtApp.vueApp, "$nuxt", nuxtApp);
  defineGetter(nuxtApp.vueApp.config.globalProperties, "$nuxt", nuxtApp);
  {
    if (nuxtApp.ssrContext) {
      nuxtApp.ssrContext.nuxt = nuxtApp;
      nuxtApp.ssrContext._payloadReducers = {};
      nuxtApp.payload.path = nuxtApp.ssrContext.url;
    }
    nuxtApp.ssrContext = nuxtApp.ssrContext || {};
    if (nuxtApp.ssrContext.payload) {
      Object.assign(nuxtApp.payload, nuxtApp.ssrContext.payload);
    }
    nuxtApp.ssrContext.payload = nuxtApp.payload;
    nuxtApp.ssrContext.config = {
      public: options.ssrContext.runtimeConfig.public,
      app: options.ssrContext.runtimeConfig.app
    };
  }
  const runtimeConfig = options.ssrContext.runtimeConfig;
  nuxtApp.provide("config", runtimeConfig);
  return nuxtApp;
}
async function applyPlugin(nuxtApp, plugin2) {
  if (plugin2.hooks) {
    nuxtApp.hooks.addHooks(plugin2.hooks);
  }
  if (typeof plugin2 === "function") {
    const { provide: provide2 } = await nuxtApp.runWithContext(() => plugin2(nuxtApp)) || {};
    if (provide2 && typeof provide2 === "object") {
      for (const key in provide2) {
        nuxtApp.provide(key, provide2[key]);
      }
    }
  }
}
async function applyPlugins(nuxtApp, plugins2) {
  var _a, _b;
  const parallels = [];
  const errors = [];
  for (const plugin2 of plugins2) {
    if (((_a = nuxtApp.ssrContext) == null ? void 0 : _a.islandContext) && ((_b = plugin2.env) == null ? void 0 : _b.islands) === false) {
      continue;
    }
    const promise = applyPlugin(nuxtApp, plugin2);
    if (plugin2.parallel) {
      parallels.push(promise.catch((e) => errors.push(e)));
    } else {
      await promise;
    }
  }
  await Promise.all(parallels);
  if (errors.length) {
    throw errors[0];
  }
}
/*! @__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function defineNuxtPlugin(plugin2) {
  if (typeof plugin2 === "function") {
    return plugin2;
  }
  delete plugin2.name;
  return Object.assign(plugin2.setup || (() => {
  }), plugin2, { [NuxtPluginIndicator]: true });
}
function callWithNuxt(nuxt, setup, args) {
  const fn = () => args ? setup(...args) : setup();
  {
    return nuxt.vueApp.runWithContext(() => nuxtAppCtx.callAsync(nuxt, fn));
  }
}
/*! @__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function useNuxtApp() {
  var _a;
  let nuxtAppInstance;
  if (hasInjectionContext()) {
    nuxtAppInstance = (_a = getCurrentInstance()) == null ? void 0 : _a.appContext.app.$nuxt;
  }
  nuxtAppInstance = nuxtAppInstance || nuxtAppCtx.tryUse();
  if (!nuxtAppInstance) {
    {
      throw new Error("[nuxt] instance unavailable");
    }
  }
  return nuxtAppInstance;
}
/*! @__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function useRuntimeConfig() {
  return (/* @__PURE__ */ useNuxtApp()).$config;
}
function defineGetter(obj, key, val) {
  Object.defineProperty(obj, key, { get: () => val });
}
function createContext(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    }
  }
  const _getCurrentInstance = () => {
    if (als && currentInstance === void 0) {
      const instance = als.getStore();
      if (instance !== void 0) {
        return instance;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance, callback) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return als ? als.run(instance, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance, callback) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers.add(onLeave);
      try {
        const r = als ? als.run(instance, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers.delete(onLeave);
      }
    }
  };
}
function createNamespace(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext({ ...defaultOpts, ...opts });
      }
      contexts[key];
      return contexts[key];
    }
  };
}
const _globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey = "__unctx__";
_globalThis[globalKey] || (_globalThis[globalKey] = createNamespace());
const asyncHandlersKey = "__unctx_async_handlers__";
const asyncHandlers = _globalThis[asyncHandlersKey] || (_globalThis[asyncHandlersKey] = /* @__PURE__ */ new Set());
function executeAsync(function_) {
  const restores = [];
  for (const leaveHandler of asyncHandlers) {
    const restore2 = leaveHandler();
    if (restore2) {
      restores.push(restore2);
    }
  }
  const restore = () => {
    for (const restore2 of restores) {
      restore2();
    }
  };
  let awaitable = function_();
  if (awaitable && typeof awaitable === "object" && "catch" in awaitable) {
    awaitable = awaitable.catch((error) => {
      restore();
      throw error;
    });
  }
  return [awaitable, restore];
}
const useStateKeyPrefix = "$s";
function useState(...args) {
  const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
  if (typeof args[0] !== "string") {
    args.unshift(autoKey);
  }
  const [_key, init] = args;
  if (!_key || typeof _key !== "string") {
    throw new TypeError("[nuxt] [useState] key must be a string: " + _key);
  }
  if (init !== void 0 && typeof init !== "function") {
    throw new Error("[nuxt] [useState] init must be a function: " + init);
  }
  const key = useStateKeyPrefix + _key;
  const nuxt = /* @__PURE__ */ useNuxtApp();
  const state = toRef(nuxt.payload.state, key);
  if (state.value === void 0 && init) {
    const initialValue = init();
    if (isRef(initialValue)) {
      nuxt.payload.state[key] = initialValue;
      return initialValue;
    }
    state.value = initialValue;
  }
  return state;
}
const LayoutMetaSymbol = Symbol("layout-meta");
const PageRouteSymbol = Symbol("route");
const useRouter = () => {
  var _a;
  return (_a = /* @__PURE__ */ useNuxtApp()) == null ? void 0 : _a.$router;
};
const useRoute = () => {
  if (hasInjectionContext()) {
    return inject(PageRouteSymbol, (/* @__PURE__ */ useNuxtApp())._route);
  }
  return (/* @__PURE__ */ useNuxtApp())._route;
};
/*! @__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function defineNuxtRouteMiddleware(middleware) {
  return middleware;
}
const isProcessingMiddleware = () => {
  try {
    if ((/* @__PURE__ */ useNuxtApp())._processingMiddleware) {
      return true;
    }
  } catch {
    return true;
  }
  return false;
};
const navigateTo = (to, options) => {
  if (!to) {
    to = "/";
  }
  const toPath = typeof to === "string" ? to : withQuery(to.path || "/", to.query || {}) + (to.hash || "");
  if (options == null ? void 0 : options.open) {
    return Promise.resolve();
  }
  const isExternal = (options == null ? void 0 : options.external) || hasProtocol(toPath, { acceptRelative: true });
  if (isExternal) {
    if (!(options == null ? void 0 : options.external)) {
      throw new Error("Navigating to an external URL is not allowed by default. Use `navigateTo(url, { external: true })`.");
    }
    const protocol = parseURL(toPath).protocol;
    if (protocol && isScriptProtocol(protocol)) {
      throw new Error(`Cannot navigate to a URL with '${protocol}' protocol.`);
    }
  }
  const inMiddleware = isProcessingMiddleware();
  const router = useRouter();
  const nuxtApp = /* @__PURE__ */ useNuxtApp();
  {
    if (nuxtApp.ssrContext) {
      const fullPath = typeof to === "string" || isExternal ? toPath : router.resolve(to).fullPath || "/";
      const location2 = isExternal ? toPath : joinURL((/* @__PURE__ */ useRuntimeConfig()).app.baseURL, fullPath);
      async function redirect(response) {
        await nuxtApp.callHook("app:redirected");
        const encodedLoc = location2.replace(/"/g, "%22");
        nuxtApp.ssrContext._renderResponse = {
          statusCode: sanitizeStatusCode((options == null ? void 0 : options.redirectCode) || 302, 302),
          body: `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`,
          headers: { location: location2 }
        };
        return response;
      }
      if (!isExternal && inMiddleware) {
        router.afterEach((final) => final.fullPath === fullPath ? redirect(false) : void 0);
        return to;
      }
      return redirect(!inMiddleware ? void 0 : (
        /* abort route navigation */
        false
      ));
    }
  }
  if (isExternal) {
    if (options == null ? void 0 : options.replace) {
      location.replace(toPath);
    } else {
      location.href = toPath;
    }
    if (inMiddleware) {
      if (!nuxtApp.isHydrating) {
        return false;
      }
      return new Promise(() => {
      });
    }
    return Promise.resolve();
  }
  return (options == null ? void 0 : options.replace) ? router.replace(to) : router.push(to);
};
const useError = () => toRef((/* @__PURE__ */ useNuxtApp()).payload, "error");
const showError = (_err) => {
  const err = createError(_err);
  try {
    const nuxtApp = /* @__PURE__ */ useNuxtApp();
    const error = useError();
    if (false)
      ;
    error.value = error.value || err;
  } catch {
    throw err;
  }
  return err;
};
const isNuxtError = (err) => !!(err && typeof err === "object" && "__nuxt_error" in err);
const createError = (err) => {
  const _err = createError$1(err);
  _err.__nuxt_error = true;
  return _err;
};
const __nuxt_page_meta$4 = {
  middleware: "auth"
};
const __nuxt_page_meta$3 = {
  middleware: "auth"
};
const __nuxt_page_meta$2 = {
  middleware: "auth"
};
const __nuxt_page_meta$1 = {
  middleware: "auth"
};
const __nuxt_page_meta = {
  middleware: "auth"
};
const _routes = [
  {
    name: "about",
    path: "/about",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/about-3e693acc.mjs').then((m) => m.default || m)
  },
  {
    name: "brands-slug",
    path: "/brands/:slug()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_slug_-40ebc8d8.mjs').then((m) => m.default || m)
  },
  {
    name: "cart",
    path: "/cart",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/cart-ec62dbf5.mjs').then((m) => m.default || m)
  },
  {
    name: "checkout",
    path: "/checkout",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/checkout-c9c6944c.mjs').then((m) => m.default || m)
  },
  {
    name: "contacts",
    path: "/contacts",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/contacts-a2fc30ae.mjs').then((m) => m.default || m)
  },
  {
    name: "index",
    path: "/",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-b066e5f6.mjs').then((m) => m.default || m)
  },
  {
    name: "news-id",
    path: "/news/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-928cae65.mjs').then((m) => m.default || m)
  },
  {
    name: "news",
    path: "/news",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-2a06fedf.mjs').then((m) => m.default || m)
  },
  {
    name: "search",
    path: "/search",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/search-3bfa9fe1.mjs').then((m) => m.default || m)
  },
  {
    name: "shop-category-subCategory-id",
    path: "/shop/:category()/:subCategory()/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-9d9bc159.mjs').then((m) => m.default || m)
  },
  {
    name: "shop-category-subCategory",
    path: "/shop/:category()/:subCategory()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-9ebde1b2.mjs').then((m) => m.default || m)
  },
  {
    name: "shop-category",
    path: "/shop/:category()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-7c0154fd.mjs').then((m) => m.default || m)
  },
  {
    name: "shop",
    path: "/shop",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-623cadae.mjs').then((m) => m.default || m)
  },
  {
    name: "success",
    path: "/success",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/success-b0826d4b.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$4 == null ? void 0 : __nuxt_page_meta$4.name) ?? "user-favorite",
    path: (__nuxt_page_meta$4 == null ? void 0 : __nuxt_page_meta$4.path) ?? "/user/favorite",
    meta: __nuxt_page_meta$4 || {},
    alias: (__nuxt_page_meta$4 == null ? void 0 : __nuxt_page_meta$4.alias) || [],
    redirect: (__nuxt_page_meta$4 == null ? void 0 : __nuxt_page_meta$4.redirect) || void 0,
    component: () => import('./_nuxt/favorite-f4c82d1c.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$3 == null ? void 0 : __nuxt_page_meta$3.name) ?? "user",
    path: (__nuxt_page_meta$3 == null ? void 0 : __nuxt_page_meta$3.path) ?? "/user",
    meta: __nuxt_page_meta$3 || {},
    alias: (__nuxt_page_meta$3 == null ? void 0 : __nuxt_page_meta$3.alias) || [],
    redirect: (__nuxt_page_meta$3 == null ? void 0 : __nuxt_page_meta$3.redirect) || void 0,
    component: () => import('./_nuxt/index-9b105706.mjs').then((m) => m.default || m)
  },
  {
    name: "user-login",
    path: "/user/login",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/login-44b2b26f.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$2 == null ? void 0 : __nuxt_page_meta$2.name) ?? "user-orders-id",
    path: (__nuxt_page_meta$2 == null ? void 0 : __nuxt_page_meta$2.path) ?? "/user/orders/:id()",
    meta: __nuxt_page_meta$2 || {},
    alias: (__nuxt_page_meta$2 == null ? void 0 : __nuxt_page_meta$2.alias) || [],
    redirect: (__nuxt_page_meta$2 == null ? void 0 : __nuxt_page_meta$2.redirect) || void 0,
    component: () => import('./_nuxt/_id_-667b8edf.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$1 == null ? void 0 : __nuxt_page_meta$1.name) ?? "user-orders",
    path: (__nuxt_page_meta$1 == null ? void 0 : __nuxt_page_meta$1.path) ?? "/user/orders",
    meta: __nuxt_page_meta$1 || {},
    alias: (__nuxt_page_meta$1 == null ? void 0 : __nuxt_page_meta$1.alias) || [],
    redirect: (__nuxt_page_meta$1 == null ? void 0 : __nuxt_page_meta$1.redirect) || void 0,
    component: () => import('./_nuxt/index-0498a4bf.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta == null ? void 0 : __nuxt_page_meta.name) ?? "user-settings",
    path: (__nuxt_page_meta == null ? void 0 : __nuxt_page_meta.path) ?? "/user/settings",
    meta: __nuxt_page_meta || {},
    alias: (__nuxt_page_meta == null ? void 0 : __nuxt_page_meta.alias) || [],
    redirect: (__nuxt_page_meta == null ? void 0 : __nuxt_page_meta.redirect) || void 0,
    component: () => import('./_nuxt/settings-c811d30f.mjs').then((m) => m.default || m)
  }
];
const appPageTransition = { "name": "page", "mode": "out-in" };
const appLayoutTransition = false;
const appKeepalive = false;
const routerOptions0 = {
  scrollBehavior(to, from, savedPosition) {
    var _a;
    const nuxtApp = /* @__PURE__ */ useNuxtApp();
    const behavior = ((_a = useRouter().options) == null ? void 0 : _a.scrollBehaviorType) ?? "auto";
    let position = savedPosition || void 0;
    const routeAllowsScrollToTop = typeof to.meta.scrollToTop === "function" ? to.meta.scrollToTop(to, from) : to.meta.scrollToTop;
    if (!position && from && to && routeAllowsScrollToTop !== false && _isDifferentRoute(from, to)) {
      position = { left: 0, top: 0 };
    }
    if (to.path === from.path) {
      if (from.hash && !to.hash) {
        return { left: 0, top: 0 };
      }
      if (to.hash) {
        return { el: to.hash, top: _getHashElementScrollMarginTop(to.hash), behavior };
      }
    }
    const hasTransition = (route) => !!(route.meta.pageTransition ?? appPageTransition);
    const hookToWait = hasTransition(from) && hasTransition(to) ? "page:transition:finish" : "page:finish";
    return new Promise((resolve) => {
      nuxtApp.hooks.hookOnce(hookToWait, async () => {
        await nextTick();
        if (to.hash) {
          position = { el: to.hash, top: _getHashElementScrollMarginTop(to.hash), behavior };
        }
        resolve(position);
      });
    });
  }
};
function _getHashElementScrollMarginTop(selector) {
  try {
    const elem = document.querySelector(selector);
    if (elem) {
      return parseFloat(getComputedStyle(elem).scrollMarginTop);
    }
  } catch {
  }
  return 0;
}
function _isDifferentRoute(from, to) {
  const samePageComponent = to.matched.every((comp, index) => {
    var _a, _b, _c;
    return ((_a = comp.components) == null ? void 0 : _a.default) === ((_c = (_b = from.matched[index]) == null ? void 0 : _b.components) == null ? void 0 : _c.default);
  });
  if (!samePageComponent) {
    return true;
  }
  if (samePageComponent && JSON.stringify(from.params) !== JSON.stringify(to.params)) {
    return true;
  }
  return false;
}
const configRouterOptions = {};
const routerOptions = {
  ...configRouterOptions,
  ...routerOptions0
};
const validate = /* @__PURE__ */ defineNuxtRouteMiddleware(async (to) => {
  var _a;
  let __temp, __restore;
  if (!((_a = to.meta) == null ? void 0 : _a.validate)) {
    return;
  }
  useRouter();
  const result = ([__temp, __restore] = executeAsync(() => Promise.resolve(to.meta.validate(to))), __temp = await __temp, __restore(), __temp);
  if (result === true) {
    return;
  }
  {
    return result;
  }
});
const globalMiddleware = [
  validate
];
const namedMiddleware = {
  auth: () => import('./_nuxt/auth-3b88b2f4.mjs')
};
const plugin$1 = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt:router",
  enforce: "pre",
  async setup(nuxtApp) {
    var _a, _b;
    let __temp, __restore;
    let routerBase = (/* @__PURE__ */ useRuntimeConfig()).app.baseURL;
    if (routerOptions.hashMode && !routerBase.includes("#")) {
      routerBase += "#";
    }
    const history = ((_a = routerOptions.history) == null ? void 0 : _a.call(routerOptions, routerBase)) ?? createMemoryHistory(routerBase);
    const routes = ((_b = routerOptions.routes) == null ? void 0 : _b.call(routerOptions, _routes)) ?? _routes;
    let startPosition;
    const initialURL = nuxtApp.ssrContext.url;
    const router = createRouter({
      ...routerOptions,
      scrollBehavior: (to, from, savedPosition) => {
        var _a2;
        if (from === START_LOCATION) {
          startPosition = savedPosition;
          return;
        }
        router.options.scrollBehavior = routerOptions.scrollBehavior;
        return (_a2 = routerOptions.scrollBehavior) == null ? void 0 : _a2.call(routerOptions, to, START_LOCATION, startPosition || savedPosition);
      },
      history,
      routes
    });
    nuxtApp.vueApp.use(router);
    const previousRoute = shallowRef(router.currentRoute.value);
    router.afterEach((_to, from) => {
      previousRoute.value = from;
    });
    Object.defineProperty(nuxtApp.vueApp.config.globalProperties, "previousRoute", {
      get: () => previousRoute.value
    });
    const _route = shallowRef(router.resolve(initialURL));
    const syncCurrentRoute = () => {
      _route.value = router.currentRoute.value;
    };
    nuxtApp.hook("page:finish", syncCurrentRoute);
    router.afterEach((to, from) => {
      var _a2, _b2, _c, _d;
      if (((_b2 = (_a2 = to.matched[0]) == null ? void 0 : _a2.components) == null ? void 0 : _b2.default) === ((_d = (_c = from.matched[0]) == null ? void 0 : _c.components) == null ? void 0 : _d.default)) {
        syncCurrentRoute();
      }
    });
    const route = {};
    for (const key in _route.value) {
      Object.defineProperty(route, key, {
        get: () => _route.value[key]
      });
    }
    nuxtApp._route = shallowReactive(route);
    nuxtApp._middleware = nuxtApp._middleware || {
      global: [],
      named: {}
    };
    useError();
    try {
      if (true) {
        ;
        [__temp, __restore] = executeAsync(() => router.push(initialURL)), await __temp, __restore();
        ;
      }
      ;
      [__temp, __restore] = executeAsync(() => router.isReady()), await __temp, __restore();
      ;
    } catch (error2) {
      [__temp, __restore] = executeAsync(() => nuxtApp.runWithContext(() => showError(error2))), await __temp, __restore();
    }
    const initialLayout = useState("_layout");
    router.beforeEach(async (to, from) => {
      var _a2, _b2;
      to.meta = reactive(to.meta);
      if (nuxtApp.isHydrating && initialLayout.value && !isReadonly(to.meta.layout)) {
        to.meta.layout = initialLayout.value;
      }
      nuxtApp._processingMiddleware = true;
      if (!((_a2 = nuxtApp.ssrContext) == null ? void 0 : _a2.islandContext)) {
        const middlewareEntries = /* @__PURE__ */ new Set([...globalMiddleware, ...nuxtApp._middleware.global]);
        for (const component of to.matched) {
          const componentMiddleware = component.meta.middleware;
          if (!componentMiddleware) {
            continue;
          }
          if (Array.isArray(componentMiddleware)) {
            for (const entry2 of componentMiddleware) {
              middlewareEntries.add(entry2);
            }
          } else {
            middlewareEntries.add(componentMiddleware);
          }
        }
        for (const entry2 of middlewareEntries) {
          const middleware = typeof entry2 === "string" ? nuxtApp._middleware.named[entry2] || await ((_b2 = namedMiddleware[entry2]) == null ? void 0 : _b2.call(namedMiddleware).then((r) => r.default || r)) : entry2;
          if (!middleware) {
            throw new Error(`Unknown route middleware: '${entry2}'.`);
          }
          const result = await nuxtApp.runWithContext(() => middleware(to, from));
          {
            if (result === false || result instanceof Error) {
              const error2 = result || createError$1({
                statusCode: 404,
                statusMessage: `Page Not Found: ${initialURL}`
              });
              await nuxtApp.runWithContext(() => showError(error2));
              return false;
            }
          }
          if (result || result === false) {
            return result;
          }
        }
      }
    });
    router.onError(() => {
      delete nuxtApp._processingMiddleware;
    });
    router.afterEach(async (to, _from, failure) => {
      var _a2;
      delete nuxtApp._processingMiddleware;
      if ((failure == null ? void 0 : failure.type) === 4) {
        return;
      }
      if (to.matched.length === 0 && !((_a2 = nuxtApp.ssrContext) == null ? void 0 : _a2.islandContext)) {
        await nuxtApp.runWithContext(() => showError(createError$1({
          statusCode: 404,
          fatal: false,
          statusMessage: `Page not found: ${to.fullPath}`
        })));
      } else if (to.redirectedFrom && to.fullPath !== initialURL) {
        await nuxtApp.runWithContext(() => navigateTo(to.fullPath || "/"));
      }
    });
    nuxtApp.hooks.hookOnce("app:created", async () => {
      try {
        await router.replace({
          ...router.resolve(initialURL),
          name: void 0,
          // #4920, #4982
          force: true
        });
        router.options.scrollBehavior = routerOptions.scrollBehavior;
      } catch (error2) {
        await nuxtApp.runWithContext(() => showError(error2));
      }
    });
    return { provide: { router } };
  }
});
const isVue2 = false;
/*!
 * pinia v2.1.6
 * (c) 2023 Eduardo San Martin Morote
 * @license MIT
 */
let activePinia;
const setActivePinia = (pinia) => activePinia = pinia;
const piniaSymbol = (
  /* istanbul ignore next */
  Symbol()
);
function isPlainObject(o) {
  return o && typeof o === "object" && Object.prototype.toString.call(o) === "[object Object]" && typeof o.toJSON !== "function";
}
var MutationType;
(function(MutationType2) {
  MutationType2["direct"] = "direct";
  MutationType2["patchObject"] = "patch object";
  MutationType2["patchFunction"] = "patch function";
})(MutationType || (MutationType = {}));
function createPinia() {
  const scope = effectScope(true);
  const state = scope.run(() => ref({}));
  let _p = [];
  let toBeInstalled = [];
  const pinia = markRaw({
    install(app) {
      setActivePinia(pinia);
      {
        pinia._a = app;
        app.provide(piniaSymbol, pinia);
        app.config.globalProperties.$pinia = pinia;
        toBeInstalled.forEach((plugin2) => _p.push(plugin2));
        toBeInstalled = [];
      }
    },
    use(plugin2) {
      if (!this._a && !isVue2) {
        toBeInstalled.push(plugin2);
      } else {
        _p.push(plugin2);
      }
      return this;
    },
    _p,
    // it's actually undefined here
    // @ts-expect-error
    _a: null,
    _e: scope,
    _s: /* @__PURE__ */ new Map(),
    state
  });
  return pinia;
}
const noop = () => {
};
function addSubscription(subscriptions, callback, detached, onCleanup = noop) {
  subscriptions.push(callback);
  const removeSubscription = () => {
    const idx = subscriptions.indexOf(callback);
    if (idx > -1) {
      subscriptions.splice(idx, 1);
      onCleanup();
    }
  };
  if (!detached && getCurrentScope()) {
    onScopeDispose(removeSubscription);
  }
  return removeSubscription;
}
function triggerSubscriptions(subscriptions, ...args) {
  subscriptions.slice().forEach((callback) => {
    callback(...args);
  });
}
const fallbackRunWithContext = (fn) => fn();
function mergeReactiveObjects(target, patchToApply) {
  if (target instanceof Map && patchToApply instanceof Map) {
    patchToApply.forEach((value, key) => target.set(key, value));
  }
  if (target instanceof Set && patchToApply instanceof Set) {
    patchToApply.forEach(target.add, target);
  }
  for (const key in patchToApply) {
    if (!patchToApply.hasOwnProperty(key))
      continue;
    const subPatch = patchToApply[key];
    const targetValue = target[key];
    if (isPlainObject(targetValue) && isPlainObject(subPatch) && target.hasOwnProperty(key) && !isRef(subPatch) && !isReactive(subPatch)) {
      target[key] = mergeReactiveObjects(targetValue, subPatch);
    } else {
      target[key] = subPatch;
    }
  }
  return target;
}
const skipHydrateSymbol = (
  /* istanbul ignore next */
  Symbol()
);
function shouldHydrate(obj) {
  return !isPlainObject(obj) || !obj.hasOwnProperty(skipHydrateSymbol);
}
const { assign } = Object;
function isComputed(o) {
  return !!(isRef(o) && o.effect);
}
function createOptionsStore(id, options, pinia, hot) {
  const { state, actions, getters } = options;
  const initialState = pinia.state.value[id];
  let store;
  function setup() {
    if (!initialState && (!("production" !== "production") )) {
      {
        pinia.state.value[id] = state ? state() : {};
      }
    }
    const localState = toRefs(pinia.state.value[id]);
    return assign(localState, actions, Object.keys(getters || {}).reduce((computedGetters, name) => {
      computedGetters[name] = markRaw(computed(() => {
        setActivePinia(pinia);
        const store2 = pinia._s.get(id);
        return getters[name].call(store2, store2);
      }));
      return computedGetters;
    }, {}));
  }
  store = createSetupStore(id, setup, options, pinia, hot, true);
  return store;
}
function createSetupStore($id, setup, options = {}, pinia, hot, isOptionsStore) {
  let scope;
  const optionsForPlugin = assign({ actions: {} }, options);
  const $subscribeOptions = {
    deep: true
    // flush: 'post',
  };
  let isListening;
  let isSyncListening;
  let subscriptions = [];
  let actionSubscriptions = [];
  let debuggerEvents;
  const initialState = pinia.state.value[$id];
  if (!isOptionsStore && !initialState && (!("production" !== "production") )) {
    {
      pinia.state.value[$id] = {};
    }
  }
  ref({});
  let activeListener;
  function $patch(partialStateOrMutator) {
    let subscriptionMutation;
    isListening = isSyncListening = false;
    if (typeof partialStateOrMutator === "function") {
      partialStateOrMutator(pinia.state.value[$id]);
      subscriptionMutation = {
        type: MutationType.patchFunction,
        storeId: $id,
        events: debuggerEvents
      };
    } else {
      mergeReactiveObjects(pinia.state.value[$id], partialStateOrMutator);
      subscriptionMutation = {
        type: MutationType.patchObject,
        payload: partialStateOrMutator,
        storeId: $id,
        events: debuggerEvents
      };
    }
    const myListenerId = activeListener = Symbol();
    nextTick().then(() => {
      if (activeListener === myListenerId) {
        isListening = true;
      }
    });
    isSyncListening = true;
    triggerSubscriptions(subscriptions, subscriptionMutation, pinia.state.value[$id]);
  }
  const $reset = isOptionsStore ? function $reset2() {
    const { state } = options;
    const newState = state ? state() : {};
    this.$patch(($state) => {
      assign($state, newState);
    });
  } : (
    /* istanbul ignore next */
    noop
  );
  function $dispose() {
    scope.stop();
    subscriptions = [];
    actionSubscriptions = [];
    pinia._s.delete($id);
  }
  function wrapAction(name, action) {
    return function() {
      setActivePinia(pinia);
      const args = Array.from(arguments);
      const afterCallbackList = [];
      const onErrorCallbackList = [];
      function after(callback) {
        afterCallbackList.push(callback);
      }
      function onError(callback) {
        onErrorCallbackList.push(callback);
      }
      triggerSubscriptions(actionSubscriptions, {
        args,
        name,
        store,
        after,
        onError
      });
      let ret;
      try {
        ret = action.apply(this && this.$id === $id ? this : store, args);
      } catch (error) {
        triggerSubscriptions(onErrorCallbackList, error);
        throw error;
      }
      if (ret instanceof Promise) {
        return ret.then((value) => {
          triggerSubscriptions(afterCallbackList, value);
          return value;
        }).catch((error) => {
          triggerSubscriptions(onErrorCallbackList, error);
          return Promise.reject(error);
        });
      }
      triggerSubscriptions(afterCallbackList, ret);
      return ret;
    };
  }
  const partialStore = {
    _p: pinia,
    // _s: scope,
    $id,
    $onAction: addSubscription.bind(null, actionSubscriptions),
    $patch,
    $reset,
    $subscribe(callback, options2 = {}) {
      const removeSubscription = addSubscription(subscriptions, callback, options2.detached, () => stopWatcher());
      const stopWatcher = scope.run(() => watch(() => pinia.state.value[$id], (state) => {
        if (options2.flush === "sync" ? isSyncListening : isListening) {
          callback({
            storeId: $id,
            type: MutationType.direct,
            events: debuggerEvents
          }, state);
        }
      }, assign({}, $subscribeOptions, options2)));
      return removeSubscription;
    },
    $dispose
  };
  const store = reactive(partialStore);
  pinia._s.set($id, store);
  const runWithContext = pinia._a && pinia._a.runWithContext || fallbackRunWithContext;
  const setupStore = pinia._e.run(() => {
    scope = effectScope();
    return runWithContext(() => scope.run(setup));
  });
  for (const key in setupStore) {
    const prop = setupStore[key];
    if (isRef(prop) && !isComputed(prop) || isReactive(prop)) {
      if (!isOptionsStore) {
        if (initialState && shouldHydrate(prop)) {
          if (isRef(prop)) {
            prop.value = initialState[key];
          } else {
            mergeReactiveObjects(prop, initialState[key]);
          }
        }
        {
          pinia.state.value[$id][key] = prop;
        }
      }
    } else if (typeof prop === "function") {
      const actionValue = wrapAction(key, prop);
      {
        setupStore[key] = actionValue;
      }
      optionsForPlugin.actions[key] = prop;
    } else ;
  }
  {
    assign(store, setupStore);
    assign(toRaw(store), setupStore);
  }
  Object.defineProperty(store, "$state", {
    get: () => pinia.state.value[$id],
    set: (state) => {
      $patch(($state) => {
        assign($state, state);
      });
    }
  });
  pinia._p.forEach((extender) => {
    {
      assign(store, scope.run(() => extender({
        store,
        app: pinia._a,
        pinia,
        options: optionsForPlugin
      })));
    }
  });
  if (initialState && isOptionsStore && options.hydrate) {
    options.hydrate(store.$state, initialState);
  }
  isListening = true;
  isSyncListening = true;
  return store;
}
function defineStore(idOrOptions, setup, setupOptions) {
  let id;
  let options;
  const isSetupStore = typeof setup === "function";
  if (typeof idOrOptions === "string") {
    id = idOrOptions;
    options = isSetupStore ? setupOptions : setup;
  } else {
    options = idOrOptions;
    id = idOrOptions.id;
  }
  function useStore(pinia, hot) {
    const hasContext = hasInjectionContext();
    pinia = // in test mode, ignore the argument provided as we can always retrieve a
    // pinia instance with getActivePinia()
    (pinia) || (hasContext ? inject(piniaSymbol, null) : null);
    if (pinia)
      setActivePinia(pinia);
    pinia = activePinia;
    if (!pinia._s.has(id)) {
      if (isSetupStore) {
        createSetupStore(id, setup, options, pinia);
      } else {
        createOptionsStore(id, options, pinia);
      }
    }
    const store = pinia._s.get(id);
    return store;
  }
  useStore.$id = id;
  return useStore;
}
const getDefault = () => null;
function useAsyncData(...args) {
  const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
  if (typeof args[0] !== "string") {
    args.unshift(autoKey);
  }
  let [key, handler, options = {}] = args;
  if (typeof key !== "string") {
    throw new TypeError("[nuxt] [asyncData] key must be a string.");
  }
  if (typeof handler !== "function") {
    throw new TypeError("[nuxt] [asyncData] handler must be a function.");
  }
  options.server = options.server ?? true;
  options.default = options.default ?? getDefault;
  options.lazy = options.lazy ?? false;
  options.immediate = options.immediate ?? true;
  const nuxt = /* @__PURE__ */ useNuxtApp();
  const getCachedData = () => nuxt.isHydrating ? nuxt.payload.data[key] : nuxt.static.data[key];
  const hasCachedData = () => getCachedData() !== void 0;
  if (!nuxt._asyncData[key] || !options.immediate) {
    nuxt._asyncData[key] = {
      data: ref(getCachedData() ?? options.default()),
      pending: ref(!hasCachedData()),
      error: toRef(nuxt.payload._errors, key),
      status: ref("idle")
    };
  }
  const asyncData = { ...nuxt._asyncData[key] };
  asyncData.refresh = asyncData.execute = (opts = {}) => {
    if (nuxt._asyncDataPromises[key]) {
      if (opts.dedupe === false) {
        return nuxt._asyncDataPromises[key];
      }
      nuxt._asyncDataPromises[key].cancelled = true;
    }
    if ((opts._initial || nuxt.isHydrating && opts._initial !== false) && hasCachedData()) {
      return getCachedData();
    }
    asyncData.pending.value = true;
    asyncData.status.value = "pending";
    const promise = new Promise(
      (resolve, reject) => {
        try {
          resolve(handler(nuxt));
        } catch (err) {
          reject(err);
        }
      }
    ).then((_result) => {
      if (promise.cancelled) {
        return nuxt._asyncDataPromises[key];
      }
      let result = _result;
      if (options.transform) {
        result = options.transform(_result);
      }
      if (options.pick) {
        result = pick(result, options.pick);
      }
      asyncData.data.value = result;
      asyncData.error.value = null;
      asyncData.status.value = "success";
    }).catch((error) => {
      if (promise.cancelled) {
        return nuxt._asyncDataPromises[key];
      }
      asyncData.error.value = error;
      asyncData.data.value = unref(options.default());
      asyncData.status.value = "error";
    }).finally(() => {
      if (promise.cancelled) {
        return;
      }
      asyncData.pending.value = false;
      nuxt.payload.data[key] = asyncData.data.value;
      if (asyncData.error.value) {
        nuxt.payload._errors[key] = createError(asyncData.error.value);
      }
      delete nuxt._asyncDataPromises[key];
    });
    nuxt._asyncDataPromises[key] = promise;
    return nuxt._asyncDataPromises[key];
  };
  const initialFetch = () => asyncData.refresh({ _initial: true });
  const fetchOnServer = options.server !== false && nuxt.payload.serverRendered;
  if (fetchOnServer && options.immediate) {
    const promise = initialFetch();
    if (getCurrentInstance()) {
      onServerPrefetch(() => promise);
    } else {
      nuxt.hook("app:created", () => promise);
    }
  }
  const asyncDataPromise = Promise.resolve(nuxt._asyncDataPromises[key]).then(() => asyncData);
  Object.assign(asyncDataPromise, asyncData);
  return asyncDataPromise;
}
function pick(obj, keys) {
  const newObj = {};
  for (const key of keys) {
    newObj[key] = obj[key];
  }
  return newObj;
}
function useRequestHeaders(include) {
  var _a;
  const event = (_a = (/* @__PURE__ */ useNuxtApp()).ssrContext) == null ? void 0 : _a.event;
  const headers = event ? getRequestHeaders(event) : {};
  if (!include) {
    return headers;
  }
  return Object.fromEntries(include.map((key) => key.toLowerCase()).filter((key) => headers[key]).map((key) => [key, headers[key]]));
}
function useRequestEvent(nuxtApp = /* @__PURE__ */ useNuxtApp()) {
  var _a;
  return (_a = nuxtApp.ssrContext) == null ? void 0 : _a.event;
}
const CookieDefaults = {
  path: "/",
  watch: true,
  decode: (val) => destr(decodeURIComponent(val)),
  encode: (val) => encodeURIComponent(typeof val === "string" ? val : JSON.stringify(val))
};
function useCookie(name, _opts) {
  var _a;
  const opts = { ...CookieDefaults, ..._opts };
  const cookies = readRawCookies(opts) || {};
  const cookie = ref(cookies[name] ?? ((_a = opts.default) == null ? void 0 : _a.call(opts)));
  {
    const nuxtApp = /* @__PURE__ */ useNuxtApp();
    const writeFinalCookieValue = () => {
      if (!isEqual(cookie.value, cookies[name])) {
        writeServerCookie(useRequestEvent(nuxtApp), name, cookie.value, opts);
      }
    };
    const unhook = nuxtApp.hooks.hookOnce("app:rendered", writeFinalCookieValue);
    nuxtApp.hooks.hookOnce("app:error", () => {
      unhook();
      return writeFinalCookieValue();
    });
  }
  return cookie;
}
function readRawCookies(opts = {}) {
  {
    return parse(getRequestHeader(useRequestEvent(), "cookie") || "", opts);
  }
}
function writeServerCookie(event, name, value, opts = {}) {
  if (event) {
    if (value !== null && value !== void 0) {
      return setCookie(event, name, value, opts);
    }
    if (getCookie(event, name) !== void 0) {
      return deleteCookie(event, name, opts);
    }
  }
}
function definePayloadReducer(name, reduce) {
  {
    (/* @__PURE__ */ useNuxtApp()).ssrContext._payloadReducers[name] = reduce;
  }
}
const firstNonUndefined = (...args) => args.find((arg) => arg !== void 0);
const DEFAULT_EXTERNAL_REL_ATTRIBUTE = "noopener noreferrer";
/*! @__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function defineNuxtLink(options) {
  const componentName = options.componentName || "NuxtLink";
  const resolveTrailingSlashBehavior = (to, resolve) => {
    if (!to || options.trailingSlash !== "append" && options.trailingSlash !== "remove") {
      return to;
    }
    const normalizeTrailingSlash = options.trailingSlash === "append" ? withTrailingSlash : withoutTrailingSlash;
    if (typeof to === "string") {
      return normalizeTrailingSlash(to, true);
    }
    const path = "path" in to ? to.path : resolve(to).path;
    return {
      ...to,
      name: void 0,
      // named routes would otherwise always override trailing slash behavior
      path: normalizeTrailingSlash(path, true)
    };
  };
  return /* @__PURE__ */ defineComponent({
    name: componentName,
    props: {
      // Routing
      to: {
        type: [String, Object],
        default: void 0,
        required: false
      },
      href: {
        type: [String, Object],
        default: void 0,
        required: false
      },
      // Attributes
      target: {
        type: String,
        default: void 0,
        required: false
      },
      rel: {
        type: String,
        default: void 0,
        required: false
      },
      noRel: {
        type: Boolean,
        default: void 0,
        required: false
      },
      // Prefetching
      prefetch: {
        type: Boolean,
        default: void 0,
        required: false
      },
      noPrefetch: {
        type: Boolean,
        default: void 0,
        required: false
      },
      // Styling
      activeClass: {
        type: String,
        default: void 0,
        required: false
      },
      exactActiveClass: {
        type: String,
        default: void 0,
        required: false
      },
      prefetchedClass: {
        type: String,
        default: void 0,
        required: false
      },
      // Vue Router's `<RouterLink>` additional props
      replace: {
        type: Boolean,
        default: void 0,
        required: false
      },
      ariaCurrentValue: {
        type: String,
        default: void 0,
        required: false
      },
      // Edge cases handling
      external: {
        type: Boolean,
        default: void 0,
        required: false
      },
      // Slot API
      custom: {
        type: Boolean,
        default: void 0,
        required: false
      }
    },
    setup(props, { slots }) {
      const router = useRouter();
      const to = computed(() => {
        const path = props.to || props.href || "";
        return resolveTrailingSlashBehavior(path, router.resolve);
      });
      const isExternal = computed(() => {
        if (props.external) {
          return true;
        }
        if (props.target && props.target !== "_self") {
          return true;
        }
        if (typeof to.value === "object") {
          return false;
        }
        return to.value === "" || hasProtocol(to.value, { acceptRelative: true });
      });
      const prefetched = ref(false);
      const el = void 0;
      const elRef = void 0;
      return () => {
        var _a, _b;
        if (!isExternal.value) {
          const routerLinkProps = {
            ref: elRef,
            to: to.value,
            activeClass: props.activeClass || options.activeClass,
            exactActiveClass: props.exactActiveClass || options.exactActiveClass,
            replace: props.replace,
            ariaCurrentValue: props.ariaCurrentValue,
            custom: props.custom
          };
          if (!props.custom) {
            if (prefetched.value) {
              routerLinkProps.class = props.prefetchedClass || options.prefetchedClass;
            }
            routerLinkProps.rel = props.rel;
          }
          return h(
            resolveComponent("RouterLink"),
            routerLinkProps,
            slots.default
          );
        }
        const href = typeof to.value === "object" ? ((_a = router.resolve(to.value)) == null ? void 0 : _a.href) ?? null : to.value || null;
        const target = props.target || null;
        const rel = props.noRel ? null : firstNonUndefined(props.rel, options.externalRelAttribute, href ? DEFAULT_EXTERNAL_REL_ATTRIBUTE : "") || null;
        const navigate = () => navigateTo(href, { replace: props.replace });
        if (props.custom) {
          if (!slots.default) {
            return null;
          }
          return slots.default({
            href,
            navigate,
            get route() {
              if (!href) {
                return void 0;
              }
              const url = parseURL(href);
              return {
                path: url.pathname,
                fullPath: url.pathname,
                get query() {
                  return parseQuery(url.search);
                },
                hash: url.hash,
                // stub properties for compat with vue-router
                params: {},
                name: void 0,
                matched: [],
                redirectedFrom: void 0,
                meta: {},
                href
              };
            },
            rel,
            target,
            isExternal: isExternal.value,
            isActive: false,
            isExactActive: false
          });
        }
        return h("a", { ref: el, href, rel, target }, (_b = slots.default) == null ? void 0 : _b.call(slots));
      };
    }
  });
}
const __nuxt_component_0$4 = /* @__PURE__ */ defineNuxtLink({ componentName: "NuxtLink" });
const plugin = /* @__PURE__ */ defineNuxtPlugin((nuxtApp) => {
  const pinia = createPinia();
  nuxtApp.vueApp.use(pinia);
  setActivePinia(pinia);
  {
    nuxtApp.payload.pinia = pinia.state.value;
  }
  return {
    provide: {
      pinia
    }
  };
});
const reducers = {
  NuxtError: (data) => isNuxtError(data) && data.toJSON(),
  EmptyShallowRef: (data) => isRef(data) && isShallow(data) && !data.value && (typeof data.value === "bigint" ? "0n" : JSON.stringify(data.value) || "_"),
  EmptyRef: (data) => isRef(data) && !data.value && (typeof data.value === "bigint" ? "0n" : JSON.stringify(data.value) || "_"),
  ShallowRef: (data) => isRef(data) && isShallow(data) && data.value,
  ShallowReactive: (data) => isReactive(data) && isShallow(data) && toRaw(data),
  Ref: (data) => isRef(data) && data.value,
  Reactive: (data) => isReactive(data) && toRaw(data)
};
const revive_payload_server_eJ33V7gbc6 = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt:revive-payload:server",
  setup() {
    for (const reducer in reducers) {
      definePayloadReducer(reducer, reducers[reducer]);
    }
  }
});
const components_plugin_KR1HBZs4kY = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt:global-components"
});
const unhead_KgADcZ0jPj = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt:head",
  setup(nuxtApp) {
    const head = nuxtApp.ssrContext.head;
    nuxtApp.vueApp.use(head);
  }
});
function isFormData(obj) {
  return typeof FormData !== "undefined" && obj instanceof FormData;
}
async function formDataToObject(formData) {
  const obj = {
    __type: "form-data"
  };
  for (const [key, value] of formData.entries()) {
    if (value instanceof Blob) {
      obj[key] = {
        __type: "blob",
        ...await serializeBlob(value),
        name: value.name
      };
    } else {
      obj[key] = value;
    }
  }
  return obj;
}
async function serializeBlob(blob) {
  const arrayBuffer = await blob.arrayBuffer();
  const bytes = new Uint8Array(arrayBuffer);
  const binary = bytes.reduce((acc, byte) => acc + String.fromCharCode(byte), "");
  const base64 = btoa(binary);
  return {
    data: base64,
    type: blob.type,
    size: blob.size
  };
}
function toValue(r) {
  return typeof r === "function" ? r() : unref(r);
}
function headersToObject(headers = {}) {
  if (headers instanceof Headers)
    return Object.fromEntries([...headers.entries()]);
  if (Array.isArray(headers))
    return Object.fromEntries(headers);
  return headers;
}
async function serializeMaybeEncodedBody(value) {
  if (isFormData(value))
    return await formDataToObject(value);
  return value;
}
function resolvePath(path, params) {
  if (params) {
    return Object.entries(params).reduce(
      (path2, [name, value]) => path2.replace(`{${name}}`, encodeURIComponent(String(toValue(value)))),
      path
    );
  }
  return path;
}
function _useApiData(endpointId, path, opts = {}) {
  const { apiParty } = (/* @__PURE__ */ useRuntimeConfig()).public;
  const {
    server,
    lazy,
    default: defaultFn,
    transform,
    pick: pick2,
    watch: watch2,
    immediate,
    pathParams,
    query,
    headers,
    method,
    body,
    client = false,
    cache = true,
    ...fetchOptions
  } = opts;
  const _path = computed(() => resolvePath(toValue(path), toValue(pathParams)));
  if (client && !apiParty.allowClient)
    throw new Error('Client-side API requests are disabled. Set "allowClient: true" in the module options to enable them.');
  const endpoints = apiParty.endpoints || {};
  const endpoint = endpoints[endpointId];
  const _fetchOptions = reactive(fetchOptions);
  const _endpointFetchOptions = reactive({
    path: _path,
    query,
    headers: computed(() => ({
      ...headersToObject(toValue(headers)),
      ...endpoint.cookies && useRequestHeaders(["cookie"])
    })),
    method,
    body
  });
  const _asyncDataOptions = {
    server,
    lazy,
    default: defaultFn,
    transform,
    pick: pick2,
    watch: watch2 === false ? [] : [
      _endpointFetchOptions,
      ...watch2 || []
    ],
    immediate
  };
  let controller;
  const key = computed(() => `$party${hash([
    endpointId,
    _path.value,
    toValue(query),
    toValue(method),
    ...isFormData(toValue(body)) ? [] : [toValue(body)]
  ])}`);
  return useAsyncData(
    key.value,
    async (nuxt) => {
      var _a;
      (_a = controller == null ? void 0 : controller.abort) == null ? void 0 : _a.call(controller);
      if ((nuxt.isHydrating || cache) && key.value in nuxt.payload.data)
        return nuxt.payload.data[key.value];
      controller = new AbortController();
      let result;
      try {
        if (client) {
          result = await globalThis.$fetch(_path.value, {
            ..._fetchOptions,
            baseURL: endpoint.url,
            method: _endpointFetchOptions.method,
            query: {
              ...endpoint.query,
              ..._endpointFetchOptions.query
            },
            headers: {
              ...endpoint.token && { Authorization: `Bearer ${endpoint.token}` },
              ...endpoint.headers,
              ..._endpointFetchOptions.headers
            },
            body: _endpointFetchOptions.body
          });
        } else {
          result = await globalThis.$fetch(
            `/api/__api_party/${endpointId}`,
            {
              ..._fetchOptions,
              signal: controller.signal,
              method: "POST",
              body: {
                ..._endpointFetchOptions,
                body: await serializeMaybeEncodedBody(_endpointFetchOptions.body)
              }
            }
          );
        }
      } catch (error) {
        if (key.value in nuxt.payload.data)
          delete nuxt.payload.data[key.value];
        throw error;
      }
      if (cache)
        nuxt.payload.data[key.value] = result;
      return result;
    },
    _asyncDataOptions
  );
}
const useJsonPlaceholderData = (...args) => _useApiData("jsonPlaceholder", ...args);
const useAuthStore = defineStore("auth", {
  state: () => ({
    isAuthenticated: false,
    user: null
  }),
  actions: {
    login(user) {
      this.isAuthenticated = true;
      this.user = user;
    },
    logout() {
      this.isAuthenticated = false;
      this.user = null;
    },
    removeFavoriteProduct(productId) {
      if (this.user) {
        this.user.favorite_products = this.user.favorite_products.filter((product) => product.id !== productId);
      }
    }
  }
});
const check_bZQzmrCirX = /* @__PURE__ */ defineNuxtPlugin(async (nuxtApp) => {
  let __temp, __restore;
  const authStore = useAuthStore();
  const token_access = useCookie("token_access");
  const token_refresh = useCookie("token_refresh");
  if (token_access.value) {
    try {
      const getUser = ([__temp, __restore] = executeAsync(() => useJsonPlaceholderData("/user/", {
        headers: {
          Authorization: `Bearer ${token_access.value}`
        }
      })), __temp = await __temp, __restore(), __temp);
      if (getUser.error.value && getUser.error.value.statusCode != 200) {
        const getNewAccess = ([__temp, __restore] = executeAsync(() => useJsonPlaceholderData("/token/refresh/", {
          method: "POST",
          body: {
            refresh: token_refresh.value
          }
        })), __temp = await __temp, __restore(), __temp);
        token_access.value = getNewAccess.data.value.access;
        if (getNewAccess.status.value === "success") {
          const getNewData = ([__temp, __restore] = executeAsync(() => useJsonPlaceholderData("/user/", {
            headers: {
              Authorization: `Bearer ${token_access.value}`
            }
          })), __temp = await __temp, __restore(), __temp);
          authStore.login(getNewData.data.value);
        } else {
          authStore.isAuthenticated = false;
          authStore.logout();
        }
      } else {
        authStore.login(getUser.data.value);
      }
    } catch (error) {
      if (error instanceof TypeError && error.message.includes("access")) {
        token_access.value = void 0;
        token_refresh.value = void 0;
      }
      authStore.logout();
      authStore.isAuthenticated = false;
    }
  } else {
    authStore.isAuthenticated = false;
    authStore.logout();
  }
});
const route_guard_q2LZ00fWG1 = /* @__PURE__ */ defineNuxtPlugin((nuxtApp) => {
  const authStore = useAuthStore();
  const token_access = useCookie("token_access");
  const router = useRouter();
  router.beforeEach((to, from, next) => {
    if (!token_access.value) {
      authStore.logout();
      if (to.path === "/user") {
        next("/user/login");
      } else {
        next();
      }
    } else {
      next();
    }
  });
});
const plugins = [
  plugin$1,
  plugin,
  revive_payload_server_eJ33V7gbc6,
  components_plugin_KR1HBZs4kY,
  unhead_KgADcZ0jPj,
  check_bZQzmrCirX,
  route_guard_q2LZ00fWG1
];
const _wrapIf = (component, props, slots) => {
  props = props === true ? {} : props;
  return { default: () => {
    var _a;
    return props ? h(component, props, slots) : (_a = slots.default) == null ? void 0 : _a.call(slots);
  } };
};
const layouts = {
  default: () => import('./_nuxt/default-46c7b34c.mjs').then((m) => m.default || m)
};
const LayoutLoader = /* @__PURE__ */ defineComponent({
  name: "LayoutLoader",
  inheritAttrs: false,
  props: {
    name: String,
    layoutProps: Object
  },
  async setup(props, context) {
    const LayoutComponent = await layouts[props.name]().then((r) => r.default || r);
    return () => h(LayoutComponent, props.layoutProps, context.slots);
  }
});
const __nuxt_component_0$3 = /* @__PURE__ */ defineComponent({
  name: "NuxtLayout",
  inheritAttrs: false,
  props: {
    name: {
      type: [String, Boolean, Object],
      default: null
    }
  },
  setup(props, context) {
    const nuxtApp = /* @__PURE__ */ useNuxtApp();
    const injectedRoute = inject(PageRouteSymbol);
    const route = injectedRoute === useRoute() ? useRoute$1() : injectedRoute;
    const layout = computed(() => unref(props.name) ?? route.meta.layout ?? "default");
    const layoutRef = ref();
    context.expose({ layoutRef });
    const done = nuxtApp.deferHydration();
    return () => {
      const hasLayout = layout.value && layout.value in layouts;
      const transitionProps = route.meta.layoutTransition ?? appLayoutTransition;
      return _wrapIf(Transition, hasLayout && transitionProps, {
        default: () => h(Suspense, { suspensible: true, onResolve: () => {
          nextTick(done);
        } }, {
          default: () => h(
            // @ts-expect-error seems to be an issue in vue types
            LayoutProvider,
            {
              layoutProps: mergeProps(context.attrs, { ref: layoutRef }),
              key: layout.value,
              name: layout.value,
              shouldProvide: !props.name,
              hasTransition: !!transitionProps
            },
            context.slots
          )
        })
      }).default();
    };
  }
});
const LayoutProvider = /* @__PURE__ */ defineComponent({
  name: "NuxtLayoutProvider",
  inheritAttrs: false,
  props: {
    name: {
      type: [String, Boolean]
    },
    layoutProps: {
      type: Object
    },
    hasTransition: {
      type: Boolean
    },
    shouldProvide: {
      type: Boolean
    }
  },
  setup(props, context) {
    const name = props.name;
    if (props.shouldProvide) {
      provide(LayoutMetaSymbol, {
        isCurrent: (route) => name === (route.meta.layout ?? "default")
      });
    }
    return () => {
      var _a, _b;
      if (!name || typeof name === "string" && !(name in layouts)) {
        return (_b = (_a = context.slots).default) == null ? void 0 : _b.call(_a);
      }
      return h(
        // @ts-expect-error seems to be an issue in vue types
        LayoutLoader,
        { key: name, layoutProps: props.layoutProps, name },
        context.slots
      );
    };
  }
});
const interpolatePath = (route, match) => {
  return match.path.replace(/(:\w+)\([^)]+\)/g, "$1").replace(/(:\w+)[?+*]/g, "$1").replace(/:\w+/g, (r) => {
    var _a;
    return ((_a = route.params[r.slice(1)]) == null ? void 0 : _a.toString()) || "";
  });
};
const generateRouteKey = (routeProps, override) => {
  const matchedRoute = routeProps.route.matched.find((m) => {
    var _a;
    return ((_a = m.components) == null ? void 0 : _a.default) === routeProps.Component.type;
  });
  const source = override ?? (matchedRoute == null ? void 0 : matchedRoute.meta.key) ?? (matchedRoute && interpolatePath(routeProps.route, matchedRoute));
  return typeof source === "function" ? source(routeProps.route) : source;
};
const wrapInKeepAlive = (props, children) => {
  return { default: () => children };
};
const RouteProvider = /* @__PURE__ */ defineComponent({
  name: "RouteProvider",
  props: {
    vnode: {
      type: Object,
      required: true
    },
    route: {
      type: Object,
      required: true
    },
    vnodeRef: Object,
    renderKey: String,
    trackRootNodes: Boolean
  },
  setup(props) {
    const previousKey = props.renderKey;
    const previousRoute = props.route;
    const route = {};
    for (const key in props.route) {
      Object.defineProperty(route, key, {
        get: () => previousKey === props.renderKey ? props.route[key] : previousRoute[key]
      });
    }
    provide(PageRouteSymbol, shallowReactive(route));
    return () => {
      return h(props.vnode, { ref: props.vnodeRef });
    };
  }
});
const __nuxt_component_1$1 = /* @__PURE__ */ defineComponent({
  name: "NuxtPage",
  inheritAttrs: false,
  props: {
    name: {
      type: String
    },
    transition: {
      type: [Boolean, Object],
      default: void 0
    },
    keepalive: {
      type: [Boolean, Object],
      default: void 0
    },
    route: {
      type: Object
    },
    pageKey: {
      type: [Function, String],
      default: null
    }
  },
  setup(props, { attrs, expose }) {
    const nuxtApp = /* @__PURE__ */ useNuxtApp();
    const pageRef = ref();
    inject(PageRouteSymbol, null);
    expose({ pageRef });
    inject(LayoutMetaSymbol, null);
    let vnode;
    const done = nuxtApp.deferHydration();
    return () => {
      return h(RouterView, { name: props.name, route: props.route, ...attrs }, {
        default: (routeProps) => {
          if (!routeProps.Component) {
            return;
          }
          const key = generateRouteKey(routeProps, props.pageKey);
          const hasTransition = !!(props.transition ?? routeProps.route.meta.pageTransition ?? appPageTransition);
          const transitionProps = hasTransition && _mergeTransitionProps([
            props.transition,
            routeProps.route.meta.pageTransition,
            appPageTransition,
            { onAfterLeave: () => {
              nuxtApp.callHook("page:transition:finish", routeProps.Component);
            } }
          ].filter(Boolean));
          vnode = _wrapIf(
            Transition,
            hasTransition && transitionProps,
            wrapInKeepAlive(
              props.keepalive ?? routeProps.route.meta.keepalive ?? appKeepalive,
              h(Suspense, {
                suspensible: true,
                onPending: () => nuxtApp.callHook("page:start", routeProps.Component),
                onResolve: () => {
                  nextTick(() => nuxtApp.callHook("page:finish", routeProps.Component).finally(done));
                }
              }, {
                // @ts-expect-error seems to be an issue in vue types
                default: () => h(RouteProvider, {
                  key,
                  vnode: routeProps.Component,
                  route: routeProps.route,
                  renderKey: key,
                  trackRootNodes: hasTransition,
                  vnodeRef: pageRef
                })
              })
            )
          ).default();
          return vnode;
        }
      });
    };
  }
});
function _toArray(val) {
  return Array.isArray(val) ? val : val ? [val] : [];
}
function _mergeTransitionProps(routeProps) {
  const _props = routeProps.map((prop) => ({
    ...prop,
    onAfterLeave: _toArray(prop.onAfterLeave)
  }));
  return defu(..._props);
}
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const _sfc_main$7 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLayout = __nuxt_component_0$3;
  const _component_NuxtPage = __nuxt_component_1$1;
  _push(ssrRenderComponent(_component_NuxtLayout, _attrs, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_NuxtPage, null, null, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_NuxtPage)
        ];
      }
    }),
    _: 1
  }, _parent));
}
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/nuxt/dist/pages/runtime/app.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const AppComponent = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["ssrRender", _sfc_ssrRender]]);
const useCartStore = defineStore("cart", {
  state: () => ({
    items: []
  }),
  actions: {
    loadCart() {
      const savedCart = sessionStorage.getItem("cart");
      if (savedCart) {
        try {
          this.items = JSON.parse(savedCart);
        } catch (e) {
          this.items = [];
        }
      } else {
        this.items = [];
      }
    },
    addToCart(newProduct, quantityToAdd) {
      const existingProductIndex = this.items.findIndex((item) => item.product.id === newProduct.id);
      if (existingProductIndex !== -1) {
        this.items[existingProductIndex].quantity += quantityToAdd;
      } else {
        this.items.push({
          product: newProduct,
          quantity: quantityToAdd
        });
      }
      sessionStorage.setItem("cart", JSON.stringify(this.items));
    },
    increaseQuantity(productId) {
      const index = this.items.findIndex((item) => item.product.id === productId);
      if (index !== -1) {
        this.items[index].quantity++;
        sessionStorage.setItem("cart", JSON.stringify(this.items));
      }
    },
    decreaseQuantity(productId) {
      const index = this.items.findIndex((item) => item.product.id === productId);
      if (index !== -1 && this.items[index].quantity > 1) {
        this.items[index].quantity--;
        sessionStorage.setItem("cart", JSON.stringify(this.items));
      }
    },
    removeFromCart(productId) {
      this.items = this.items.filter((item) => item.product.id !== productId);
      sessionStorage.setItem("cart", JSON.stringify(this.items));
    },
    clearCart() {
      this.items = [];
      sessionStorage.setItem("cart", JSON.stringify(this.items));
    }
  }
});
const _sfc_main$6 = {
  __name: "HeaderUser",
  __ssrInlineRender: true,
  setup(__props) {
    const router = useRouter();
    const CartStore = useCartStore();
    useAuthStore();
    useCookie("token_access");
    useCookie("token_refresh");
    const totalUniqueItemsInCart = computed(() => CartStore.items.length);
    const goToFavorites = async (event) => {
      await router.push("/user/favorite");
      location.reload();
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "onmalika-header-bottom-user-navigation" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "onmalika-header-bottom-user-links",
        to: "/user"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"${_scopeId}><path d="M12 12C14.7614 12 17 9.76142 17 7C17 4.23858 14.7614 2 12 2C9.23858 2 7 4.23858 7 7C7 9.76142 9.23858 12 12 12Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M20.5901 22C20.5901 18.13 16.7402 15 12.0002 15C7.26015 15 3.41016 18.13 3.41016 22" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                width: "24",
                height: "24",
                viewBox: "0 0 24 24",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg"
              }, [
                createVNode("path", {
                  d: "M12 12C14.7614 12 17 9.76142 17 7C17 4.23858 14.7614 2 12 2C9.23858 2 7 4.23858 7 7C7 9.76142 9.23858 12 12 12Z",
                  stroke: "white",
                  "stroke-width": "1.5",
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round"
                }),
                createVNode("path", {
                  d: "M20.5901 22C20.5901 18.13 16.7402 15 12.0002 15C7.26015 15 3.41016 18.13 3.41016 22",
                  stroke: "white",
                  "stroke-width": "1.5",
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "#",
        class: "position-relative onmalika-header-bottom-user-links",
        "data-bs-toggle": "modal",
        "data-bs-target": "#cardModal"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"${_scopeId}><path d="M2 2H3.74001C4.82001 2 5.67 2.93 5.58 4L4.75 13.96C4.61 15.59 5.89999 16.99 7.53999 16.99H18.19C19.63 16.99 20.89 15.81 21 14.38L21.54 6.88C21.66 5.22 20.4 3.87 18.73 3.87H5.82001" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M16.25 22C16.9404 22 17.5 21.4404 17.5 20.75C17.5 20.0596 16.9404 19.5 16.25 19.5C15.5596 19.5 15 20.0596 15 20.75C15 21.4404 15.5596 22 16.25 22Z" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M8.25 22C8.94036 22 9.5 21.4404 9.5 20.75C9.5 20.0596 8.94036 19.5 8.25 19.5C7.55964 19.5 7 20.0596 7 20.75C7 21.4404 7.55964 22 8.25 22Z" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M9 8H21" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path></svg>`);
            if (unref(totalUniqueItemsInCart) > 0) {
              _push2(`<sub${_scopeId}>${ssrInterpolate(unref(totalUniqueItemsInCart))}</sub>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              (openBlock(), createBlock("svg", {
                width: "24",
                height: "24",
                viewBox: "0 0 24 24",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg"
              }, [
                createVNode("path", {
                  d: "M2 2H3.74001C4.82001 2 5.67 2.93 5.58 4L4.75 13.96C4.61 15.59 5.89999 16.99 7.53999 16.99H18.19C19.63 16.99 20.89 15.81 21 14.38L21.54 6.88C21.66 5.22 20.4 3.87 18.73 3.87H5.82001",
                  stroke: "white",
                  "stroke-width": "1.5",
                  "stroke-miterlimit": "10",
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round"
                }),
                createVNode("path", {
                  d: "M16.25 22C16.9404 22 17.5 21.4404 17.5 20.75C17.5 20.0596 16.9404 19.5 16.25 19.5C15.5596 19.5 15 20.0596 15 20.75C15 21.4404 15.5596 22 16.25 22Z",
                  stroke: "white",
                  "stroke-width": "1.5",
                  "stroke-miterlimit": "10",
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round"
                }),
                createVNode("path", {
                  d: "M8.25 22C8.94036 22 9.5 21.4404 9.5 20.75C9.5 20.0596 8.94036 19.5 8.25 19.5C7.55964 19.5 7 20.0596 7 20.75C7 21.4404 7.55964 22 8.25 22Z",
                  stroke: "white",
                  "stroke-width": "1.5",
                  "stroke-miterlimit": "10",
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round"
                }),
                createVNode("path", {
                  d: "M9 8H21",
                  stroke: "white",
                  "stroke-width": "1.5",
                  "stroke-miterlimit": "10",
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round"
                })
              ])),
              unref(totalUniqueItemsInCart) > 0 ? (openBlock(), createBlock("sub", { key: 0 }, toDisplayString(unref(totalUniqueItemsInCart)), 1)) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "onmalika-header-bottom-user-links",
        onClick: goToFavorites,
        to: "/user/favorite"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"${_scopeId}><path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.69C2 5.6 4.49 3.1 7.56 3.1C9.38 3.1 10.99 3.98 12 5.34C13.01 3.98 14.63 3.1 16.44 3.1C19.51 3.1 22 5.6 22 8.69C22 15.69 15.52 19.82 12.62 20.81Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                width: "24",
                height: "24",
                viewBox: "0 0 24 24",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg"
              }, [
                createVNode("path", {
                  d: "M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.69C2 5.6 4.49 3.1 7.56 3.1C9.38 3.1 10.99 3.98 12 5.34C13.01 3.98 14.63 3.1 16.44 3.1C19.51 3.1 22 5.6 22 8.69C22 15.69 15.52 19.82 12.62 20.81Z",
                  stroke: "white",
                  "stroke-width": "1.5",
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MainLayout/HeaderUser.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$6;
const _imports_1 = "" + __publicAssetsURL("img/instagram.svg");
const _imports_2 = "" + __publicAssetsURL("img/facebook.svg");
const _imports_3 = "" + __publicAssetsURL("img/telegram.svg");
const _imports_0 = "" + __publicAssetsURL("img/Logo.svg");
const _imports_4 = "" + __publicAssetsURL("img/search-normal.svg");
const useCurrencyStore = defineStore("currency", {
  state: () => ({
    selectedCurrency: "UZS"
    // начальное значение
  }),
  actions: {
    setSelectedCurrency(currency) {
      this.selectedCurrency = currency;
    }
  }
});
const _sfc_main$5 = {
  __name: "Header",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { data: category } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/categories/")), __temp = await __temp, __restore(), __temp);
    computed(() => category.value);
    const hierarchicalCategories = ref([]);
    const categoryBlockRef = ref(null);
    const toggleButtonRef = ref(null);
    const isShown = ref(true);
    const handleClickOutside = (event) => {
      if (categoryBlockRef.value && !categoryBlockRef.value.contains(event.target) && toggleButtonRef.value && !toggleButtonRef.value.contains(event.target)) {
        isShown.value = true;
      }
    };
    const close = () => {
      isShown.value = true;
    };
    onUnmounted(() => {
      window.removeEventListener("click", handleClickOutside);
    });
    const { data: currency } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/currency/")), __temp = await __temp, __restore(), __temp);
    useCurrencyStore();
    const uzsIndex = currency.value.findIndex((cur) => cur.code === "UZS");
    const currentIndex = ref(uzsIndex !== -1 ? uzsIndex : 0);
    const currencyStyles = computed(() => {
      return currency.value.map((_, index) => {
        if (index === currentIndex.value) {
          return {
            transform: "translateY(0)",
            transition: "transform 0.5s",
            position: "absolute",
            left: "0",
            bottom: "0",
            display: "flex",
            top: "0",
            right: 0,
            zIndex: 2
            // Убедитесь, что текущий элемент находится над другими элементами
          };
        } else if (index < currentIndex.value) {
          return {
            transform: "translateY(-100%)",
            transition: "transform 0.5s",
            position: "absolute",
            left: "0",
            bottom: "0",
            display: "flex",
            top: "0",
            right: 0,
            zIndex: 1
          };
        } else {
          return {
            transform: "translateY(100%)",
            transition: "transform 0.5s",
            position: "absolute",
            left: "0",
            bottom: "0",
            display: "flex",
            top: "0",
            right: 0,
            zIndex: 1
          };
        }
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$4;
      const _component_MainLayoutHeaderUser = __nuxt_component_1;
      _push(`<header${ssrRenderAttrs(mergeProps({ class: "onmalika-header" }, _attrs))}><div class="container"><div class="onmalika-header-top d-flex justify-content-between"><ul class="navbar-nav onmalika-header-top-nav"><li class="nav-item">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "nav-link",
        "aria-current": "page",
        to: "/about"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`О нас`);
          } else {
            return [
              createTextVNode("О нас")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="nav-item">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "nav-link",
        "aria-current": "page",
        to: "/contacts"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Контакты`);
          } else {
            return [
              createTextVNode("Контакты")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li></ul><div class="onmalika-header-top-currency d-flex"><div class="d-flex align-items-center column-gap-3"><p>Показывать цены на сайте:</p><div class="onmalika-header-top-currency-toggle" style="${ssrRenderStyle({ "position": "relative", "height": "30px" })}"><!--[-->`);
      ssrRenderList(unref(currency), (cur, index) => {
        _push(`<span style="${ssrRenderStyle(unref(currencyStyles)[index])}">${ssrInterpolate(cur.code)}</span>`);
      });
      _push(`<!--]--></div></div><div class="onmalika-header-top-social d-flex"><a href="https://instagram.com/onmalika.uz" target="_blank"><img${ssrRenderAttr("src", _imports_1)} alt=""></a><a href="https://www.facebook.com/onmalika.uz" target="_blank"><img${ssrRenderAttr("src", _imports_2)} alt=""></a><a href="https://t.me/onmalika" target="_blank"><img${ssrRenderAttr("src", _imports_3)} alt=""></a></div></div></div></div><hr><div class="container"><nav class="navbar navbar-expand-lg onmalika-header-bottom justify-content-between"><div class="onmalika-header-bottom-menu d-flex"><a class="navbar-brand" href="/"><img${ssrRenderAttr("src", _imports_0)} alt=""></a><button type="button" class="${ssrRenderClass([{ "active": !unref(isShown) }, "btn dark-cover btn-elemetn-in"])}"> Каталог <svg class="${ssrRenderClass({ "d-none": !unref(isShown) })}" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 7H21" stroke="white" stroke-width="1.5" stroke-linecap="round"></path><path d="M3 12H21" stroke="white" stroke-width="1.5" stroke-linecap="round"></path><path d="M3 17H21" stroke="white" stroke-width="1.5" stroke-linecap="round"></path></svg><svg class="${ssrRenderClass({ "d-none": unref(isShown) })}" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5 19L19 5" stroke="black" fill="currentcolor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M19 19L5 5" stroke="black" fill="currentcolor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></button><button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarSupportedContent"><ul class="navbar-nav me-auto mb-2 mb-lg-0"><li class="nav-item">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "nav-link",
        "aria-current": "page",
        to: "/about"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`О нас`);
          } else {
            return [
              createTextVNode("О нас")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="nav-item">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "nav-link",
        "aria-current": "page",
        to: "/contacts"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Контакты`);
          } else {
            return [
              createTextVNode("Контакты")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li></ul></div></div><div class="onmalika-header-bottom-user"><button type="button" data-bs-toggle="modal" data-bs-target="#searchModal" class="btn dark-cover"><img${ssrRenderAttr("src", _imports_4)} alt=""></button><div class="dark-cover onmalika-header-bottom-user-nav"><a class="onmalika-header-bottom-tel" href="tel:+998951031111"><b>+998 95 103 11 11</b></a>`);
      _push(ssrRenderComponent(_component_MainLayoutHeaderUser, null, null, _parent));
      _push(`</div></div></nav></div><div class="${ssrRenderClass([{ "d-block": !unref(isShown) }, "onmalika-category"])}"><div class="container"><div class="onmalika-category-block"><div class="row justify-content-between"><div class="col-3"><ul class="nav onmalika-category-block-list nav-pills mb-3" id="pills-tab" role="tablist"><!--[-->`);
      ssrRenderList(unref(hierarchicalCategories), (cat, index) => {
        _push(`<li class="nav-item" role="presentation"><button class="${ssrRenderClass([{ "active": index == 0 }, "nav-link"])}"${ssrRenderAttr("id", "pills-tab-" + index)} data-bs-toggle="pill"${ssrRenderAttr("data-bs-target", "#pills-content-" + index)} type="button" role="tab"${ssrRenderAttr("aria-controls", "pills-content-" + index)} aria-selected="true"><span><svg width="100%" height="24" class="icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.9199 22C17.4199 22 21.9199 17.5 21.9199 12C21.9199 6.5 17.4199 2 11.9199 2C6.41992 2 1.91992 6.5 1.91992 12C1.91992 17.5 6.41992 22 11.9199 22Z" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M7.91992 12H15.9199" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg> ${ssrInterpolate(cat.name)}</span><svg width="100%" height="14" class="arrow-icon" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5.19727 11.62L9.0006 7.81667C9.44977 7.36751 9.44977 6.63251 9.0006 6.18334L5.19727 2.38" stroke="black" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path></svg></button></li>`);
      });
      _push(`<!--]--></ul></div><div class="col-8"><div class="tab-content onmalika-category-block-subcats" id="pills-tabContent"><!--[-->`);
      ssrRenderList(unref(hierarchicalCategories), (cat, index) => {
        _push(`<div class="${ssrRenderClass([{ "show active": index == 0 }, "tab-pane fade"])}"${ssrRenderAttr("id", "pills-content-" + index)}><ul class="cols-four list-menu"><!--[-->`);
        ssrRenderList(cat.subcategories, (subcat, index2) => {
          _push(`<li class="mb-3">`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            onClick: close,
            to: `/shop/${subcat.parent.slug}/${subcat.slug}`
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(subcat.name)}`);
              } else {
                return [
                  createTextVNode(toDisplayString(subcat.name), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</li>`);
        });
        _push(`<!--]--></ul></div>`);
      });
      _push(`<!--]--></div></div></div></div></div></div></header>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MainLayout/Header.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_0$2 = _sfc_main$5;
const baseurl$2 = "http://64.23.130.79:8000";
const _sfc_main$4 = {
  __name: "MiniCard",
  __ssrInlineRender: true,
  props: {
    product_info: {
      type: Object,
      required: true
    },
    userFav: {
      type: Boolean,
      required: false
    }
  },
  setup(__props) {
    const props = __props;
    const authStore = useAuthStore();
    useCartStore();
    const { product_info } = props;
    const token_access = useCookie("token_access");
    const checkAuth = async () => {
      if (authStore.isAuthenticated) {
        await useJsonPlaceholderData("/user/favorites/", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token_access.value}`
          },
          body: {
            user: authStore.user.id,
            product_id: product_info.id
          }
        });
        alert("Добавлено в избранные");
      } else {
        alert("Вы не авторизованы");
      }
    };
    const currencyStore = useCurrencyStore();
    const getPriceText = () => {
      const currency = currencyStore.selectedCurrency;
      const priceInfo = product_info.prices_in_currencies[currency];
      if (!priceInfo) {
        return "Цена не указана";
      }
      return `${priceInfo.price} ${priceInfo.symbol}`;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "card onmalika-card h-100 mini-card" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/shop/" + unref(product_info).category.parent.slug + "/" + unref(product_info).category.slug + "/" + unref(product_info).slug
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="onmalika-card-badges"${_scopeId}><span class="badge onmalika-card-badges-new" style="${ssrRenderStyle({ "background-color": "#80EE98" })}"${_scopeId}>new</span><span class="badge onmalika-card-badges-new" style="${ssrRenderStyle({ "background-color": "#FF4A4A" })}"${_scopeId}>-20%</span></div>`);
            if (!__props.userFav) {
              _push2(`<button class="onmalika-card-favorite"${_scopeId}><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"${_scopeId}><path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path></svg></button>`);
            } else {
              _push2(`<!---->`);
            }
            if (unref(product_info) && unref(product_info).image && unref(product_info).image.url) {
              _push2(`<img${ssrRenderAttr("src", baseurl$2 + unref(product_info).image.url)} class="card-img-top" alt="..."${_scopeId}>`);
            } else {
              _push2(`<img src="https://placehold.co/250x250" class="w-100" alt=""${_scopeId}>`);
            }
          } else {
            return [
              createVNode("div", { class: "onmalika-card-badges" }, [
                createVNode("span", {
                  class: "badge onmalika-card-badges-new",
                  style: { "background-color": "#80EE98" }
                }, "new"),
                createVNode("span", {
                  class: "badge onmalika-card-badges-new",
                  style: { "background-color": "#FF4A4A" }
                }, "-20%")
              ]),
              !__props.userFav ? (openBlock(), createBlock("button", {
                key: 0,
                class: "onmalika-card-favorite",
                onClick: checkAuth
              }, [
                (openBlock(), createBlock("svg", {
                  width: "24",
                  height: "24",
                  viewBox: "0 0 24 24",
                  fill: "none",
                  xmlns: "http://www.w3.org/2000/svg"
                }, [
                  createVNode("path", {
                    d: "M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z",
                    stroke: "black",
                    "stroke-width": "1.5",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                  })
                ]))
              ])) : createCommentVNode("", true),
              unref(product_info) && unref(product_info).image && unref(product_info).image.url ? (openBlock(), createBlock("img", {
                key: 1,
                src: baseurl$2 + unref(product_info).image.url,
                class: "card-img-top",
                alt: "..."
              }, null, 8, ["src"])) : (openBlock(), createBlock("img", {
                key: 2,
                src: "https://placehold.co/250x250",
                class: "w-100",
                alt: ""
              }))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="card-body onmalika-card-body"><h5 class="onmalika-card-title">${ssrInterpolate(unref(product_info).name)}</h5><div class="onmalika-card-stock"><div class="stock in-stock"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 22C17.5 22 22 17.5 22 12C22 6.5 17.5 2 12 2C6.5 2 2 6.5 2 12C2 17.5 6.5 22 12 22Z" stroke="#46AC36" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M7.75 11.9999L10.58 14.8299L16.25 9.16992" stroke="#46AC36" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg><p> Есть в наличии</p></div></div><div class="onmalika-card-price"><span class="${ssrRenderClass({ "active": unref(product_info).sales_price })}">${ssrInterpolate(getPriceText())}</span><p class="${ssrRenderClass({ "d-none": !unref(product_info).sales_price })}">${ssrInterpolate(unref(product_info).sales_price)}</p></div><div class="onmalika-card-body-orderbtn"><button type="button" class="btn dark-cover justify-content-center"> В корзину</button><div class="onmalika-card-body-orderbtn-rating"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.5639 4.3011L15.1502 7.49508C15.364 7.93681 15.9378 8.35588 16.4216 8.44649L19.2905 8.92219C21.1244 9.22799 21.5519 10.5645 20.2356 11.901L17.9967 14.1549C17.6254 14.5286 17.4116 15.2649 17.5354 15.7972L18.1767 18.5834C18.683 20.7807 17.5129 21.6415 15.589 20.4862L12.9001 18.8779C12.4163 18.5834 11.6062 18.5834 11.1224 18.8779L8.43351 20.4862C6.50963 21.6302 5.33955 20.7807 5.84583 18.5834L6.48712 15.7972C6.58838 15.2535 6.37462 14.5173 6.00334 14.1436L3.76444 11.8896C2.4481 10.5645 2.87563 9.22799 4.7095 8.91086L7.57845 8.43516C8.06223 8.35588 8.63602 7.92548 8.84979 7.48376L10.4361 4.28977C11.3025 2.56819 12.6975 2.56819 13.5639 4.3011Z" fill="#FFB800"></path></svg><p> 5.0</p></div></div></div></div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MiniCard.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_0$1 = _sfc_main$4;
const baseurl$1 = "http://64.23.130.79:8000";
const _sfc_main$3 = {
  __name: "InputSearch",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { debounce } = pkg;
    const { data: products } = ([__temp, __restore] = withAsyncContext(() => useJsonPlaceholderData("/products/?limit=3")), __temp = await __temp, __restore(), __temp);
    const searchQuery = ref("");
    const searchResults = ref([]);
    useRouter();
    ref(null);
    const debouncedFetchSearchResults = debounce(async (query) => {
      if (!query)
        return;
      try {
        const response = await useJsonPlaceholderData(`/products/?search=${query}&limit=6`);
        searchResults.value = response.data.value;
      } catch (error) {
        searchResults.value = [];
      }
    }, 700);
    const highlightSearchQuery = (text) => {
      if (!searchQuery.value)
        return text;
      const words = searchQuery.value.trim().split(/\s+/).map(escapeRegExp);
      const regex = new RegExp(`(${words.join("|")})`, "gi");
      return text.replace(regex, (matched) => `<span style="color: red;">${matched}</span>`);
    };
    function escapeRegExp(string) {
      return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    }
    watch(searchQuery, (newValue) => {
      if (newValue && newValue.length >= 2) {
        debouncedFetchSearchResults(newValue);
      } else {
        searchResults.value = [];
        if (newValue === "") {
          debouncedFetchSearchResults.cancel();
        }
      }
    });
    const currencyStore = useCurrencyStore();
    const getPriceText = (product) => {
      const selectedCurrency = currencyStore.selectedCurrency;
      const priceInfo = product.prices_in_currencies[selectedCurrency];
      if (!priceInfo) {
        return "Цена не указана";
      }
      return `${priceInfo.price} ${priceInfo.symbol}`;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$4;
      const _component_MiniCard = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))}><div class="modal-search-input"><form><div class="input-group"><span class="input-group-text" id="basic-addon1"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.5 21C16.7467 21 21 16.7467 21 11.5C21 6.25329 16.7467 2 11.5 2C6.25329 2 2 6.25329 2 11.5C2 16.7467 6.25329 21 11.5 21Z" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M22 22L20 20" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></span><input autocomplete="off" type="text" class="form-control" placeholder="Найдите свой товар!"${ssrRenderAttr("value", unref(searchQuery))} id="search" aria-describedby="search"></div><button type="button" class="btn dark-cover">Поиск</button></form><button type="button" class="dark-cover close" data-bs-dismiss="modal"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.33301 12.6667L12.6663 3.33333" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M12.6663 12.6667L3.33301 3.33333" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></button></div>`);
      if (unref(searchResults) && unref(searchResults).results && unref(searchResults).results.length > 0) {
        _push(`<div class="row"><!--[-->`);
        ssrRenderList(unref(searchResults).results, (item) => {
          _push(`<div class="col-2 mb-4"><div class="card onmalika-card h-100 mini-card"><div class="onmalika-card-badges"><span class="badge onmalika-card-badges-new">new</span><span class="badge onmalika-card-badges-sales">-20%</span></div>`);
          if (!_ctx.userFav) {
            _push(`<button class="onmalika-card-favorite"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></button>`);
          } else {
            _push(`<!---->`);
          }
          _push(ssrRenderComponent(_component_NuxtLink, {
            "data-bs-dismiss": "modal",
            to: "/shop/" + item.category.parent.slug + "/" + item.category.slug + "/" + item.slug
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                if (item && item.image && item.image.url) {
                  _push2(`<img${ssrRenderAttr("src", baseurl$1 + item.image.url)} class="card-img-top" alt="..."${_scopeId}>`);
                } else {
                  _push2(`<img src="https://placehold.co/250x250" class="w-100" alt=""${_scopeId}>`);
                }
              } else {
                return [
                  item && item.image && item.image.url ? (openBlock(), createBlock("img", {
                    key: 0,
                    src: baseurl$1 + item.image.url,
                    class: "card-img-top",
                    alt: "..."
                  }, null, 8, ["src"])) : (openBlock(), createBlock("img", {
                    key: 1,
                    src: "https://placehold.co/250x250",
                    class: "w-100",
                    alt: ""
                  }))
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`<div class="card-body onmalika-card-body"><h5 class="onmalika-card-title">${highlightSearchQuery(item.name)}</h5><div class="onmalika-card-stock"><div class="stock in-stock"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 22C17.5 22 22 17.5 22 12C22 6.5 17.5 2 12 2C6.5 2 2 6.5 2 12C2 17.5 6.5 22 12 22Z" stroke="#46AC36" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M7.75 11.9999L10.58 14.8299L16.25 9.16992" stroke="#46AC36" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg><p> Есть в наличии</p></div></div><div class="onmalika-card-price"><span class="${ssrRenderClass({ "active": item.sales_price })}">${ssrInterpolate(getPriceText(item))}</span><p class="${ssrRenderClass({ "d-none": !item.sales_price })}">${ssrInterpolate(item.sales_price)}</p></div><div class="onmalika-card-body-orderbtn"><button type="button" class="btn dark-cover w-50 justify-content-center"> В корзину</button><p><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.5639 4.3011L15.1502 7.49508C15.364 7.93681 15.9378 8.35588 16.4216 8.44649L19.2905 8.92219C21.1244 9.22799 21.5519 10.5645 20.2356 11.901L17.9967 14.1549C17.6254 14.5286 17.4116 15.2649 17.5354 15.7972L18.1767 18.5834C18.683 20.7807 17.5129 21.6415 15.589 20.4862L12.9001 18.8779C12.4163 18.5834 11.6062 18.5834 11.1224 18.8779L8.43351 20.4862C6.50963 21.6302 5.33955 20.7807 5.84583 18.5834L6.48712 15.7972C6.58838 15.2535 6.37462 14.5173 6.00334 14.1436L3.76444 11.8896C2.4481 10.5645 2.87563 9.22799 4.7095 8.91086L7.57845 8.43516C8.06223 8.35588 8.63602 7.92548 8.84979 7.48376L10.4361 4.28977C11.3025 2.56819 12.6975 2.56819 13.5639 4.3011Z" fill="#FFB800"></path></svg> 5.0 </p></div></div></div></div>`);
        });
        _push(`<!--]--><div class="col-4">`);
        if (unref(searchResults) && unref(searchResults).results && unref(searchResults).results.length == 6) {
          _push(`<button type="button" data-bs-dismiss="modal" class="btn light-cover w-100">Посмотреть все результаты</button>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div>`);
      } else if (unref(searchQuery) && unref(searchResults) && unref(searchResults).results && !unref(searchResults).results.length) {
        _push(`<div><div class="modal-search-input-noresult d-flex column-gap-3 align-items-center"><svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20 15V23.3333" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M19.9997 35.6833H9.89973C4.11639 35.6833 1.69973 31.55 4.49973 26.5L9.69973 17.1333L14.5997 8.33333C17.5664 2.98333 22.4331 2.98333 25.3997 8.33333L30.2997 17.15L35.4997 26.5167C38.2997 31.5667 35.8664 35.7 30.0997 35.7H19.9997V35.6833Z" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M19.9902 28.3333H20.0052" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg><p>по вашему запросу ничего не найденно <span>Попробуйте заново</span></p></div></div>`);
      } else {
        _push(`<div class="row modal-search-results"><div class="col-2"><h6 class="modal-search-results-title">Часто ищут</h6><ul><li><a href=""> Кондиционеры</a></li><li><a href=""> Кондиционеры</a></li></ul></div><div class="col-8"><h6 class="modal-search-results-title">популярные товары</h6><div class="row row-cols-4"><!--[-->`);
        ssrRenderList(unref(products).results, (product) => {
          _push(`<div class="col">`);
          _push(ssrRenderComponent(_component_MiniCard, {
            "data-bs-dismiss": "modal",
            product_info: product
          }, null, _parent));
          _push(`</div>`);
        });
        _push(`<!--]--></div></div></div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Search/InputSearch.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$3;
const baseurl = "http://64.23.130.79:8000";
const _sfc_main$2 = {
  __name: "Footer",
  __ssrInlineRender: true,
  setup(__props) {
    useRouter();
    const cartStore = useCartStore();
    const currencyStore = useCurrencyStore();
    const getPriceInSelectedCurrency = (product) => {
      const selectedCurrency = currencyStore.selectedCurrency;
      const priceInfo = product.prices_in_currencies[selectedCurrency];
      if (!priceInfo) {
        return "Цена не указана";
      }
      return `${priceInfo.price} ${priceInfo.symbol}`;
    };
    const totalUniqueItemsInCart = computed(() => cartStore.items.length);
    const totalPrice = computed(() => {
      return cartStore.items.reduce((total, item) => {
        return total + item.quantity * item.product.price;
      }, 0);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SearchInputSearch = __nuxt_component_0;
      _push(`<!--[--><footer class="onmalika-footer"><div class="container"><div class="onmalika-footer-top"><div class="row"><div class="col-4"><div class="onmalika-footer-top-logo"><a href="/"><img${ssrRenderAttr("src", _imports_0)} alt=""></a><a href="tel:+998997897898"><span>+998 99 789 78 98</span></a><div class="onmalika-footer-top-logo-social"><a href="https://instagram.com/onmalika.uz" target="_blank"><img${ssrRenderAttr("src", _imports_1)} alt=""></a><a href="https://www.facebook.com/onmalika.uz" target="_blank"><img${ssrRenderAttr("src", _imports_2)} alt=""></a><a href="https://t.me/onmalika" target="_blank"><img${ssrRenderAttr("src", _imports_3)} alt=""></a></div></div></div><div class="col-8"><div class="onmalika-footer-top-links"><div class="onmalika-footer-top-links-category"><p class="onmalika-footer-top-links-title">категории</p><ul><li><a href="">Блендер (погружной и стационарный)</a></li><li><a href="">Мясорубка</a></li></ul></div><div class="onmalika-footer-top-links-pages"><p class="onmalika-footer-top-links-title">Покупателям</p><ul><li><a href="">О нас</a></li><li><a href="">Новости</a></li></ul></div></div></div></div></div><div class="onmalika-footer-bottom"><p>© On Malika, 2024</p><a href="">Сделано в...</a></div></div></footer><div class="modal fade onmalika-search-modal" id="searchModal" tabindex="-1" aria-labelledby="searchModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-body">`);
      _push(ssrRenderComponent(_component_SearchInputSearch, null, null, _parent));
      _push(`</div></div></div></div><div class="modal fade onmalika-cart-modal" id="cardModal" tabindex="-1" aria-labelledby="cardModalLabel" aria-hidden="true"><div class="modal-dialog modal-dialog-scrollable"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="exampleModalLabel">Корзина <span>${ssrInterpolate(unref(totalUniqueItemsInCart))}</span></h5><button type="button" class="dark-cover" data-bs-dismiss="modal" aria-label="Close"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.33301 12.6667L12.6663 3.33333" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M12.6663 12.6667L3.33301 3.33333" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></button></div>`);
      if (unref(cartStore).items.length > 0) {
        _push(`<div class="modal-body"><button type="button"${ssrIncludeBooleanAttr(unref(cartStore).items.length == 0) ? " disabled" : ""} class="clean-cart">Очистить корзину </button><ul><!--[-->`);
        ssrRenderList(unref(cartStore).items, (item) => {
          _push(`<li class="card onmalika-card-cart mb-3"><button class="remove-product" type="button"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.3335 11.6667L11.6668 2.33333" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M11.6668 11.6667L2.3335 2.33333" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></button><div class="row g-0"><div class="col-md-4">`);
          if (item && item.product && item.product.image && item.product.image.url) {
            _push(`<img${ssrRenderAttr("src", baseurl + item.product.image.url)} class="card-img-top" alt="...">`);
          } else {
            _push(`<img src="http://placehold.co/250x250" class="card-img-top" alt="...">`);
          }
          _push(`</div><div class="col-md-8"><div class="card-body"><h5 class="onmalika-card-cart-title">${ssrInterpolate(item.product.name)}</h5><p class="onmalika-card-cart-price">${ssrInterpolate(getPriceInSelectedCurrency(item.product))}</p><div class="product-counter"><button type="button">-</button><input${ssrRenderAttr("value", item.quantity)} disabled class="text-center" placeholder=""><button type="button">+</button></div></div></div></div></li>`);
        });
        _push(`<!--]--></ul></div>`);
      } else {
        _push(`<div class="modal-body"><div class="modal-empty"><h4>корзина пуста</h4><p>Воспользуйтесь поиском или каталогом, чтобы найти товары</p></div></div>`);
      }
      _push(`<div class="modal-footer"><div class="total-price"><p>Итого:</p><h4>${ssrInterpolate(unref(totalPrice))}</h4></div><button class="${ssrRenderClass([{ "disabled": unref(cartStore).items.length == 0 }, "btn dark-cover btn-elemetn-in"])}"${ssrIncludeBooleanAttr(unref(cartStore).items.length == 0) ? " disabled" : ""} data-bs-dismiss="modal" type="button"> Оформить заказ </button></div></div></div></div><div class="modal fade onmalika-reviews-modal" id="reviewsModal" tabindex="-1" aria-labelledby="reviewsModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><h1 class="modal-title fs-5" id="exampleModalLabel">Оставить отзыв</h1><button type="button" class="dark-cover" data-bs-dismiss="modal" aria-label="Close"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.33301 12.6667L12.6663 3.33333" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M12.6663 12.6667L3.33301 3.33333" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></button></div><div class="modal-body"><button type="button" class="clean-cart">Вернуться к отзывам</button><form class="modal-form"><div class="modal-leave-rating"><p>Оцените товар</p><div class="modal-leave-rating-stars"><svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M28.4752 7.89133L32.0005 14.9891C32.4755 15.9707 33.7506 16.9019 34.8257 17.1033L41.2011 18.1604C45.2764 18.84 46.2264 21.81 43.3012 24.7799L38.3259 29.7886C37.5009 30.6192 37.0258 32.2552 37.3008 33.4382L38.7259 39.6298C39.851 44.5127 37.2508 46.4255 32.9755 43.8583L27.0001 40.2842C25.9251 39.6298 24.1249 39.6298 23.0499 40.2842L17.0745 43.8583C12.7992 46.4004 10.199 44.5127 11.3241 39.6298L12.7492 33.4382C12.9742 32.2301 12.4991 30.594 11.6741 29.7635L6.69875 24.7548C3.77355 21.81 4.72362 18.84 8.79889 18.1352L15.1743 17.0781C16.2494 16.9019 17.5245 15.9455 17.9995 14.9639L21.5248 7.86616C23.4499 4.04043 26.5501 4.04043 28.4752 7.89133Z" fill="#7B7B7B"></path></svg><svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M28.4752 7.89133L32.0005 14.9891C32.4755 15.9707 33.7506 16.9019 34.8257 17.1033L41.2011 18.1604C45.2764 18.84 46.2264 21.81 43.3012 24.7799L38.3259 29.7886C37.5009 30.6192 37.0258 32.2552 37.3008 33.4382L38.7259 39.6298C39.851 44.5127 37.2508 46.4255 32.9755 43.8583L27.0001 40.2842C25.9251 39.6298 24.1249 39.6298 23.0499 40.2842L17.0745 43.8583C12.7992 46.4004 10.199 44.5127 11.3241 39.6298L12.7492 33.4382C12.9742 32.2301 12.4991 30.594 11.6741 29.7635L6.69875 24.7548C3.77355 21.81 4.72362 18.84 8.79889 18.1352L15.1743 17.0781C16.2494 16.9019 17.5245 15.9455 17.9995 14.9639L21.5248 7.86616C23.4499 4.04043 26.5501 4.04043 28.4752 7.89133Z" fill="#7B7B7B"></path></svg><svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M28.4752 7.89133L32.0005 14.9891C32.4755 15.9707 33.7506 16.9019 34.8257 17.1033L41.2011 18.1604C45.2764 18.84 46.2264 21.81 43.3012 24.7799L38.3259 29.7886C37.5009 30.6192 37.0258 32.2552 37.3008 33.4382L38.7259 39.6298C39.851 44.5127 37.2508 46.4255 32.9755 43.8583L27.0001 40.2842C25.9251 39.6298 24.1249 39.6298 23.0499 40.2842L17.0745 43.8583C12.7992 46.4004 10.199 44.5127 11.3241 39.6298L12.7492 33.4382C12.9742 32.2301 12.4991 30.594 11.6741 29.7635L6.69875 24.7548C3.77355 21.81 4.72362 18.84 8.79889 18.1352L15.1743 17.0781C16.2494 16.9019 17.5245 15.9455 17.9995 14.9639L21.5248 7.86616C23.4499 4.04043 26.5501 4.04043 28.4752 7.89133Z" fill="#7B7B7B"></path></svg><svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M28.4752 7.89133L32.0005 14.9891C32.4755 15.9707 33.7506 16.9019 34.8257 17.1033L41.2011 18.1604C45.2764 18.84 46.2264 21.81 43.3012 24.7799L38.3259 29.7886C37.5009 30.6192 37.0258 32.2552 37.3008 33.4382L38.7259 39.6298C39.851 44.5127 37.2508 46.4255 32.9755 43.8583L27.0001 40.2842C25.9251 39.6298 24.1249 39.6298 23.0499 40.2842L17.0745 43.8583C12.7992 46.4004 10.199 44.5127 11.3241 39.6298L12.7492 33.4382C12.9742 32.2301 12.4991 30.594 11.6741 29.7635L6.69875 24.7548C3.77355 21.81 4.72362 18.84 8.79889 18.1352L15.1743 17.0781C16.2494 16.9019 17.5245 15.9455 17.9995 14.9639L21.5248 7.86616C23.4499 4.04043 26.5501 4.04043 28.4752 7.89133Z" fill="#7B7B7B"></path></svg><svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M28.4752 7.89133L32.0005 14.9891C32.4755 15.9707 33.7506 16.9019 34.8257 17.1033L41.2011 18.1604C45.2764 18.84 46.2264 21.81 43.3012 24.7799L38.3259 29.7886C37.5009 30.6192 37.0258 32.2552 37.3008 33.4382L38.7259 39.6298C39.851 44.5127 37.2508 46.4255 32.9755 43.8583L27.0001 40.2842C25.9251 39.6298 24.1249 39.6298 23.0499 40.2842L17.0745 43.8583C12.7992 46.4004 10.199 44.5127 11.3241 39.6298L12.7492 33.4382C12.9742 32.2301 12.4991 30.594 11.6741 29.7635L6.69875 24.7548C3.77355 21.81 4.72362 18.84 8.79889 18.1352L15.1743 17.0781C16.2494 16.9019 17.5245 15.9455 17.9995 14.9639L21.5248 7.86616C23.4499 4.04043 26.5501 4.04043 28.4752 7.89133Z" fill="#7B7B7B"></path></svg></div></div><textarea placeholder="Введите комментарий"></textarea></form></div><div class="modal-footer"><button type="button" class="dark-cover w-100 justify-content-center">Отправить</button></div></div></div></div><!--]-->`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MainLayout/Footer.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "error",
  __ssrInlineRender: true,
  props: ["error"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_MainLayoutHeader = __nuxt_component_0$2;
      const _component_NuxtLink = __nuxt_component_0$4;
      const _component_MainLayoutFooter = __nuxt_component_2;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_MainLayoutHeader, null, null, _parent));
      _push(`<section class="padding-y"><div class="container"><div class="row justify-content-center"><div class="col-5"></div></div><div class="row justify-content-center"><div class="col-5 text-center"><h1 class="text-center mb-4">${ssrInterpolate(__props.error.statusCode)}, ${ssrInterpolate(__props.error.message)}</h1>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "btn btn-primary"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` На главную `);
          } else {
            return [
              createTextVNode(" На главную ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></section>`);
      _push(ssrRenderComponent(_component_MainLayoutFooter, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("error.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const ErrorComponent = _sfc_main$1;
const _sfc_main = {
  __name: "nuxt-root",
  __ssrInlineRender: true,
  setup(__props) {
    const IslandRenderer = /* @__PURE__ */ defineAsyncComponent(() => import('./_nuxt/island-renderer-bf79bdef.mjs').then((r) => r.default || r));
    const nuxtApp = /* @__PURE__ */ useNuxtApp();
    nuxtApp.deferHydration();
    nuxtApp.ssrContext.url;
    const SingleRenderer = false;
    provide(PageRouteSymbol, useRoute());
    nuxtApp.hooks.callHookWith((hooks) => hooks.map((hook) => hook()), "vue:setup");
    const error = useError();
    onErrorCaptured((err, target, info) => {
      nuxtApp.hooks.callHook("vue:error", err, target, info).catch((hookError) => /* @__PURE__ */ console.error("[nuxt] Error in `vue:error` hook", hookError));
      {
        const p = nuxtApp.runWithContext(() => showError(err));
        onServerPrefetch(() => p);
        return false;
      }
    });
    const islandContext = nuxtApp.ssrContext.islandContext;
    return (_ctx, _push, _parent, _attrs) => {
      ssrRenderSuspense(_push, {
        default: () => {
          if (unref(error)) {
            _push(ssrRenderComponent(unref(ErrorComponent), { error: unref(error) }, null, _parent));
          } else if (unref(islandContext)) {
            _push(ssrRenderComponent(unref(IslandRenderer), { context: unref(islandContext) }, null, _parent));
          } else if (unref(SingleRenderer)) {
            ssrRenderVNode(_push, createVNode(resolveDynamicComponent(unref(SingleRenderer)), null, null), _parent);
          } else {
            _push(ssrRenderComponent(unref(AppComponent), null, null, _parent));
          }
        },
        _: 1
      });
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/nuxt/dist/app/components/nuxt-root.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const RootComponent = _sfc_main;
if (!globalThis.$fetch) {
  globalThis.$fetch = $fetch.create({
    baseURL: baseURL()
  });
}
let entry;
{
  entry = async function createNuxtAppServer(ssrContext) {
    const vueApp = createApp(RootComponent);
    const nuxt = createNuxtApp({ vueApp, ssrContext });
    try {
      await applyPlugins(nuxt, plugins);
      await nuxt.hooks.callHook("app:created", vueApp);
    } catch (err) {
      await nuxt.hooks.callHook("app:error", err);
      nuxt.payload.error = nuxt.payload.error || err;
    }
    if (ssrContext == null ? void 0 : ssrContext._renderResponse) {
      throw new Error("skipping render");
    }
    return vueApp;
  };
}
const entry$1 = (ctx) => entry(ctx);

export { _export_sfc as _, useJsonPlaceholderData as a, useRouter as b, createError as c, useCartStore as d, entry$1 as default, useAuthStore as e, useCurrencyStore as f, __nuxt_component_0$4 as g, useCookie as h, __nuxt_component_0$1 as i, defineNuxtRouteMiddleware as j, executeAsync as k, __nuxt_component_0$2 as l, __nuxt_component_1$1 as m, navigateTo as n, __nuxt_component_2 as o, useRoute as u };
//# sourceMappingURL=server.mjs.map
