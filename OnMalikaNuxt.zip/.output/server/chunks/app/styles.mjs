const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.20da8e13.mjs').then(interopDefault),
  "pages/cart.vue": () => import('./_nuxt/cart-styles.c2600da6.mjs').then(interopDefault),
  "pages/checkout.vue": () => import('./_nuxt/checkout-styles.e046ca9a.mjs').then(interopDefault),
  "pages/index.vue": () => import('./_nuxt/index-styles.2d8bff20.mjs').then(interopDefault),
  "pages/shop/[category]/[subCategory]/[id].vue": () => import('./_nuxt/_id_-styles.e5cb8543.mjs').then(interopDefault),
  "pages/shop/[category]/[subCategory]/index.vue": () => import('./_nuxt/index-styles.c078f1c7.mjs').then(interopDefault),
  "pages/user/orders/index.vue": () => import('./_nuxt/index-styles.0d6b65fd.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
