import { d as defineEventHandler, s as setCookie } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';

const logout = defineEventHandler((event) => {
  setCookie(event, "token_access", "", { maxAge: 0, path: "/" });
  setCookie(event, "token_refresh", "", { maxAge: 0, path: "/" });
  return { message: "Logged out" };
});

export { logout as default };
//# sourceMappingURL=logout.mjs.map
